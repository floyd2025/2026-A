#!/usr/bin/env python3
"""CUMCM A题问题2：变物性、温湿耦合圆柱药材有限体积求解器。

模型
----
rho(C) cp(C) dT/dt = (1/r) d/dr [r k(C) dT/dr]
dC/dt              = (1/r) d/dr [r D(C,T) dC/dr]

空间采用节点型守恒有限体积法，时间采用后向欧拉；每个时间步用
Picard 迭代同时更新温度、含水率及全部物性。温度单位在输出中为摄氏度，
D(C,T) 经验式中的温度按题意转换为开尔文。

本文件只负责数值求解和校验，不写 Excel。最终工作簿由 artifact-tool 脚本生成。
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Iterable

import numpy as np

from question1_fvm_backward_euler import (
    BoundaryData,
    Geometry,
    build_geometry,
    read_boundary_data,
    relative_residual,
    solve_tridiagonal,
    tridiagonal_matvec,
)


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent


def project_path(value: str | Path) -> Path:
    """Resolve relative command-line paths from the delivery package root."""
    path = Path(value).expanduser()
    return path if path.is_absolute() else PROJECT_DIR / path


REPORT_TIMES_S = np.arange(1800.0, 10800.0 + 1.0, 1800.0)
REPORT_RADII_M = np.array([0.0, 0.005, 0.010, 0.015, 0.020])
OUTPUT_RADII_M = np.linspace(0.0, 0.020, 21)


@dataclass(frozen=True)
class Q2Parameters:
    radius_m: float = 0.02
    heat_transfer_w_m2_k: float = 25.0
    mass_transfer_m_s: float = 8.0e-7
    initial_temperature_c: float = 28.0
    initial_moisture_kg_kg: float = 2.55
    end_time_s: float = 10800.0
    intervals: int = 80
    time_step_s: float = 1.0
    picard_update_tolerance: float = 1.0e-9
    picard_residual_tolerance: float = 1.0e-10
    picard_max_iterations: int = 50
    picard_relaxation: float = 1.0


@dataclass
class Q2Solution:
    times_s: np.ndarray
    radius_nodes_m: np.ndarray
    temperature_c: np.ndarray
    moisture_kg_kg: np.ndarray
    diagnostics: dict


def density_kg_m3(moisture: np.ndarray) -> np.ndarray:
    return 650.0 + 128.0 * moisture


def heat_capacity_j_kg_k(moisture: np.ndarray) -> np.ndarray:
    return 1450.0 + 2736.0 * moisture / (moisture + 1.0)


def thermal_conductivity_w_m_k(moisture: np.ndarray) -> np.ndarray:
    return 0.21 + 0.38 * moisture / (moisture + 1.0)


def moisture_diffusivity_m2_s(
    moisture: np.ndarray, temperature_c: np.ndarray
) -> np.ndarray:
    temperature_k = temperature_c + 273.15
    if np.any(~np.isfinite(moisture)) or np.any(moisture <= 0.0):
        raise FloatingPointError("D(C,T)要求含水率为有限正数")
    if np.any(~np.isfinite(temperature_k)) or np.any(temperature_k <= 0.0):
        raise FloatingPointError("D(C,T)要求绝对温度为有限正数")
    diffusivity = (
        2.4e-3 * np.exp(-0.45 / moisture) * np.exp(-3850.0 / temperature_k)
    )
    if np.any(~np.isfinite(diffusivity)) or np.any(diffusivity <= 0.0):
        raise FloatingPointError("扩散系数出现非有限值或非正值")
    return diffusivity


def _validate_properties(moisture: np.ndarray, temperature_c: np.ndarray) -> None:
    arrays = (
        density_kg_m3(moisture),
        heat_capacity_j_kg_k(moisture),
        thermal_conductivity_w_m_k(moisture),
        moisture_diffusivity_m2_s(moisture, temperature_c),
    )
    if any(np.any(~np.isfinite(x)) or np.any(x <= 0.0) for x in arrays):
        raise FloatingPointError("变物性经验式产生了非正或非有限物性")


def _harmonic_faces(node_values: np.ndarray) -> np.ndarray:
    denominator = node_values[:-1] + node_values[1:]
    if np.any(denominator <= 0.0):
        raise FloatingPointError("调和平均的分母必须为正")
    return 2.0 * node_values[:-1] * node_values[1:] / denominator


def _assemble_tridiagonal(
    geometry: Geometry,
    capacity: np.ndarray,
    node_transport: np.ndarray,
    surface_transfer: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """组装守恒有限体积三对角矩阵。"""
    n = len(capacity)
    face_transport = _harmonic_faces(node_transport)
    conductance = face_transport * geometry.internal_face_areas_m / geometry.dr_m
    lower = np.zeros(n)
    diagonal = capacity.copy()
    upper = np.zeros(n)

    diagonal[0] += conductance[0]
    upper[0] = -conductance[0]
    for i in range(1, n - 1):
        lower[i] = -conductance[i - 1]
        diagonal[i] += conductance[i - 1] + conductance[i]
        upper[i] = -conductance[i]
    lower[-1] = -conductance[-1]
    diagonal[-1] += conductance[-1] + surface_transfer * geometry.surface_area_m
    return lower, diagonal, upper


def _heat_system(
    geometry: Geometry,
    params: Q2Parameters,
    old_temperature_c: np.ndarray,
    moisture_for_properties: np.ndarray,
    ambient_temperature_c: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    volumetric_capacity = (
        density_kg_m3(moisture_for_properties)
        * heat_capacity_j_kg_k(moisture_for_properties)
    )
    capacity = volumetric_capacity * geometry.cell_volumes_m2 / params.time_step_s
    conductivity = thermal_conductivity_w_m_k(moisture_for_properties)
    lower, diagonal, upper = _assemble_tridiagonal(
        geometry, capacity, conductivity, params.heat_transfer_w_m2_k
    )
    rhs = capacity * old_temperature_c
    rhs[-1] += (
        params.heat_transfer_w_m2_k
        * geometry.surface_area_m
        * ambient_temperature_c
    )
    return lower, diagonal, upper, rhs, volumetric_capacity


def _moisture_system(
    geometry: Geometry,
    params: Q2Parameters,
    old_moisture: np.ndarray,
    moisture_for_properties: np.ndarray,
    temperature_for_properties_c: np.ndarray,
    ambient_moisture: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    capacity = geometry.cell_volumes_m2 / params.time_step_s
    diffusivity = moisture_diffusivity_m2_s(
        moisture_for_properties, temperature_for_properties_c
    )
    lower, diagonal, upper = _assemble_tridiagonal(
        geometry, capacity, diffusivity, params.mass_transfer_m_s
    )
    rhs = capacity * old_moisture
    rhs[-1] += params.mass_transfer_m_s * geometry.surface_area_m * ambient_moisture
    return lower, diagonal, upper, rhs, diffusivity


def _normalized_update(
    candidate_temperature: np.ndarray,
    guess_temperature: np.ndarray,
    candidate_moisture: np.ndarray,
    guess_moisture: np.ndarray,
) -> float:
    temp_scale = max(float(np.max(np.abs(candidate_temperature))), 1.0)
    moisture_scale = max(float(np.max(np.abs(candidate_moisture))), 1.0)
    return max(
        float(np.max(np.abs(candidate_temperature - guess_temperature))) / temp_scale,
        float(np.max(np.abs(candidate_moisture - guess_moisture))) / moisture_scale,
    )


def solve_case(boundary: BoundaryData, params: Q2Parameters) -> Q2Solution:
    if params.time_step_s <= 0.0:
        raise ValueError("时间步长必须为正")
    if not (0.0 < params.picard_relaxation <= 1.0):
        raise ValueError("Picard松弛因子必须位于(0,1]")
    steps_float = params.end_time_s / params.time_step_s
    steps = int(round(steps_float))
    if not math.isclose(steps_float, steps, rel_tol=0.0, abs_tol=1.0e-10):
        raise ValueError("end_time_s必须是time_step_s的整数倍")

    geometry = build_geometry(params.radius_m, params.intervals)
    times = np.linspace(0.0, params.end_time_s, steps + 1)
    node_count = params.intervals + 1
    temperature = np.empty((steps + 1, node_count), dtype=float)
    moisture = np.empty((steps + 1, node_count), dtype=float)
    temperature[0] = params.initial_temperature_c
    moisture[0] = params.initial_moisture_kg_kg

    max_heat_linear_residual = 0.0
    max_moisture_linear_residual = 0.0
    max_heat_nonlinear_residual = 0.0
    max_moisture_nonlinear_residual = 0.0
    max_picard_update_encountered = 0.0
    max_final_picard_update = 0.0
    max_heat_balance_residual = 0.0
    max_moisture_balance_residual = 0.0
    max_heat_balance_absolute_residual = 0.0
    max_moisture_balance_absolute_residual = 0.0
    picard_iterations: list[int] = []

    for step in range(steps):
        next_time = times[step + 1]
        ambient_temperature = float(boundary.temperature(next_time))
        ambient_moisture = float(boundary.moisture(next_time))
        old_temperature = temperature[step]
        old_moisture = moisture[step]
        guess_temperature = old_temperature.copy()
        guess_moisture = old_moisture.copy()
        converged = False

        for iteration in range(1, params.picard_max_iterations + 1):
            lower_t, diag_t, upper_t, rhs_t, _ = _heat_system(
                geometry,
                params,
                old_temperature,
                guess_moisture,
                ambient_temperature,
            )
            candidate_temperature = solve_tridiagonal(
                lower_t, diag_t, upper_t, rhs_t
            )
            heat_linear_residual = relative_residual(
                tridiagonal_matvec(
                    lower_t, diag_t, upper_t, candidate_temperature
                )
                - rhs_t,
                rhs_t,
            )
            max_heat_linear_residual = max(
                max_heat_linear_residual, heat_linear_residual
            )

            lower_c, diag_c, upper_c, rhs_c, _ = _moisture_system(
                geometry,
                params,
                old_moisture,
                guess_moisture,
                candidate_temperature,
                ambient_moisture,
            )
            candidate_moisture = solve_tridiagonal(
                lower_c, diag_c, upper_c, rhs_c
            )
            moisture_linear_residual = relative_residual(
                tridiagonal_matvec(
                    lower_c, diag_c, upper_c, candidate_moisture
                )
                - rhs_c,
                rhs_c,
            )
            max_moisture_linear_residual = max(
                max_moisture_linear_residual, moisture_linear_residual
            )

            if (
                np.any(~np.isfinite(candidate_temperature))
                or np.any(~np.isfinite(candidate_moisture))
                or np.any(candidate_moisture <= 0.0)
            ):
                raise FloatingPointError(
                    f"t={next_time:g} s时耦合Picard迭代产生非法状态"
                )
            _validate_properties(candidate_moisture, candidate_temperature)

            update = _normalized_update(
                candidate_temperature,
                guess_temperature,
                candidate_moisture,
                guess_moisture,
            )
            max_picard_update_encountered = max(
                max_picard_update_encountered, update
            )

            # 用候选解重新装配，检验真正的耦合非线性方程残差。
            lower_tr, diag_tr, upper_tr, rhs_tr, _ = _heat_system(
                geometry,
                params,
                old_temperature,
                candidate_moisture,
                ambient_temperature,
            )
            heat_nonlinear_residual = relative_residual(
                tridiagonal_matvec(
                    lower_tr, diag_tr, upper_tr, candidate_temperature
                )
                - rhs_tr,
                rhs_tr,
            )
            lower_cr, diag_cr, upper_cr, rhs_cr, _ = _moisture_system(
                geometry,
                params,
                old_moisture,
                candidate_moisture,
                candidate_temperature,
                ambient_moisture,
            )
            moisture_nonlinear_residual = relative_residual(
                tridiagonal_matvec(
                    lower_cr, diag_cr, upper_cr, candidate_moisture
                )
                - rhs_cr,
                rhs_cr,
            )

            if (
                update <= params.picard_update_tolerance
                and heat_nonlinear_residual <= params.picard_residual_tolerance
                and moisture_nonlinear_residual
                <= params.picard_residual_tolerance
            ):
                temperature[step + 1] = candidate_temperature
                moisture[step + 1] = candidate_moisture
                max_heat_nonlinear_residual = max(
                    max_heat_nonlinear_residual, heat_nonlinear_residual
                )
                max_moisture_nonlinear_residual = max(
                    max_moisture_nonlinear_residual,
                    moisture_nonlinear_residual,
                )
                max_final_picard_update = max(max_final_picard_update, update)
                picard_iterations.append(iteration)
                converged = True
                break

            omega = params.picard_relaxation
            guess_temperature = (
                omega * candidate_temperature
                + (1.0 - omega) * guess_temperature
            )
            guess_moisture = (
                omega * candidate_moisture + (1.0 - omega) * guess_moisture
            )

        if not converged:
            raise RuntimeError(
                f"t={next_time:g} s时耦合Picard迭代未在"
                f"{params.picard_max_iterations}次内收敛；"
                f"update={update:.3e}, heat_res={heat_nonlinear_residual:.3e}, "
                f"moisture_res={moisture_nonlinear_residual:.3e}"
            )

        final_moisture = moisture[step + 1]
        final_temperature = temperature[step + 1]
        volumetric_capacity = (
            density_kg_m3(final_moisture)
            * heat_capacity_j_kg_k(final_moisture)
        )
        heat_cell_changes = (
            volumetric_capacity
            * geometry.cell_volumes_m2
            * (final_temperature - old_temperature)
        )
        heat_change = float(np.sum(heat_cell_changes))
        heat_boundary = float(
            params.time_step_s
            * params.heat_transfer_w_m2_k
            * geometry.surface_area_m
            * (ambient_temperature - final_temperature[-1])
        )
        heat_balance_absolute_residual = abs(heat_change - heat_boundary)
        # 以全域“总活动量”归一化，避免在净边界通量过零时把舍入误差
        # 放大成没有物理意义的巨大相对误差。
        heat_balance_scale = max(
            float(np.sum(np.abs(heat_cell_changes))) + abs(heat_boundary),
            1.0e-30,
        )
        max_heat_balance_absolute_residual = max(
            max_heat_balance_absolute_residual, heat_balance_absolute_residual
        )
        max_heat_balance_residual = max(
            max_heat_balance_residual,
            heat_balance_absolute_residual / heat_balance_scale,
        )

        moisture_cell_changes = geometry.cell_volumes_m2 * (
            final_moisture - old_moisture
        )
        moisture_change = float(np.sum(moisture_cell_changes))
        moisture_boundary = float(
            params.time_step_s
            * params.mass_transfer_m_s
            * geometry.surface_area_m
            * (ambient_moisture - final_moisture[-1])
        )
        moisture_balance_absolute_residual = abs(
            moisture_change - moisture_boundary
        )
        moisture_balance_scale = max(
            float(np.sum(np.abs(moisture_cell_changes)))
            + abs(moisture_boundary),
            1.0e-30,
        )
        max_moisture_balance_absolute_residual = max(
            max_moisture_balance_absolute_residual,
            moisture_balance_absolute_residual,
        )
        max_moisture_balance_residual = max(
            max_moisture_balance_residual,
            moisture_balance_absolute_residual / moisture_balance_scale,
        )

    rho_all = density_kg_m3(moisture)
    cp_all = heat_capacity_j_kg_k(moisture)
    k_all = thermal_conductivity_w_m_k(moisture)
    d_all = moisture_diffusivity_m2_s(moisture, temperature)
    diagnostics = {
        "parameters": asdict(params),
        "intervals": params.intervals,
        "nodes": node_count,
        "dr_m": geometry.dr_m,
        "dt_s": params.time_step_s,
        "max_temperature_linear_relative_residual": max_heat_linear_residual,
        "max_moisture_linear_relative_residual": max_moisture_linear_residual,
        "max_temperature_nonlinear_relative_residual": max_heat_nonlinear_residual,
        "max_moisture_nonlinear_relative_residual": max_moisture_nonlinear_residual,
        "max_picard_relative_update_encountered": max_picard_update_encountered,
        "max_final_picard_relative_update": max_final_picard_update,
        "picard_iterations_max": int(max(picard_iterations)),
        "picard_iterations_mean": float(np.mean(picard_iterations)),
        "max_heat_balance_relative_residual": max_heat_balance_residual,
        "max_moisture_balance_relative_residual": max_moisture_balance_residual,
        "max_heat_balance_absolute_residual_j_per_m": max_heat_balance_absolute_residual,
        "max_moisture_balance_absolute_residual_m2_kg_per_kg": max_moisture_balance_absolute_residual,
        "temperature_min_c": float(np.min(temperature)),
        "temperature_max_c": float(np.max(temperature)),
        "moisture_min_kg_kg": float(np.min(moisture)),
        "moisture_max_kg_kg": float(np.max(moisture)),
        "density_min_kg_m3": float(np.min(rho_all)),
        "density_max_kg_m3": float(np.max(rho_all)),
        "heat_capacity_min_j_kg_k": float(np.min(cp_all)),
        "heat_capacity_max_j_kg_k": float(np.max(cp_all)),
        "conductivity_min_w_m_k": float(np.min(k_all)),
        "conductivity_max_w_m_k": float(np.max(k_all)),
        "diffusivity_min_m2_s": float(np.min(d_all)),
        "diffusivity_max_m2_s": float(np.max(d_all)),
        "temperature_radial_order_violations": int(
            np.sum(np.diff(temperature, axis=1) < -1.0e-9)
        ),
        "moisture_radial_order_violations": int(
            np.sum(np.diff(moisture, axis=1) > 1.0e-9)
        ),
    }
    return Q2Solution(
        times,
        geometry.radius_nodes_m,
        temperature,
        moisture,
        diagnostics,
    )


def sample_field(
    solution: Q2Solution,
    field: np.ndarray,
    target_times_s: Iterable[float],
    target_radii_m: Iterable[float],
) -> np.ndarray:
    target_times = np.asarray(list(target_times_s), dtype=float)
    target_radii = np.asarray(list(target_radii_m), dtype=float)
    radial_samples = np.vstack(
        [np.interp(target_radii, solution.radius_nodes_m, row) for row in field]
    )
    output = np.empty((len(target_times), len(target_radii)), dtype=float)
    for j in range(len(target_radii)):
        output[:, j] = np.interp(
            target_times, solution.times_s, radial_samples[:, j]
        )
    return output


def compare_solutions(
    reference: Q2Solution,
    candidate: Q2Solution,
    report_times_s: np.ndarray = REPORT_TIMES_S,
    report_radii_m: np.ndarray = REPORT_RADII_M,
) -> dict:
    common_times = reference.times_s
    ref_t = sample_field(
        reference,
        reference.temperature_c,
        common_times,
        OUTPUT_RADII_M,
    )
    can_t = sample_field(
        candidate,
        candidate.temperature_c,
        common_times,
        OUTPUT_RADII_M,
    )
    ref_c = sample_field(
        reference,
        reference.moisture_kg_kg,
        common_times,
        OUTPUT_RADII_M,
    )
    can_c = sample_field(
        candidate,
        candidate.moisture_kg_kg,
        common_times,
        OUTPUT_RADII_M,
    )
    report_ref_t = sample_field(
        reference, reference.temperature_c, report_times_s, report_radii_m
    )
    report_can_t = sample_field(
        candidate, candidate.temperature_c, report_times_s, report_radii_m
    )
    report_ref_c = sample_field(
        reference, reference.moisture_kg_kg, report_times_s, report_radii_m
    )
    report_can_c = sample_field(
        candidate, candidate.moisture_kg_kg, report_times_s, report_radii_m
    )
    return {
        "full_output_max_abs_temperature_c": float(np.max(np.abs(ref_t - can_t))),
        "full_output_max_abs_moisture_kg_kg": float(np.max(np.abs(ref_c - can_c))),
        "report_table_max_abs_temperature_c": float(
            np.max(np.abs(report_ref_t - report_can_t))
        ),
        "report_table_max_abs_moisture_kg_kg": float(
            np.max(np.abs(report_ref_c - report_can_c))
        ),
        "report_table_four_decimal_equal_temperature": bool(
            np.array_equal(np.round(report_ref_t, 4), np.round(report_can_t, 4))
        ),
        "report_table_four_decimal_equal_moisture": bool(
            np.array_equal(np.round(report_ref_c, 4), np.round(report_can_c, 4))
        ),
    }


def run_validation(
    boundary: BoundaryData,
    main: Q2Solution,
    params: Q2Parameters,
) -> tuple[dict, dict[str, Q2Solution]]:
    cases = {
        "coarse_space_40_intervals_dt1": replace(params, intervals=40),
        "fine_space_160_intervals_dt1": replace(params, intervals=160),
        "fine_time_80_intervals_dt0_5": replace(params, time_step_s=0.5),
    }
    solutions: dict[str, Q2Solution] = {}
    for name, case_params in cases.items():
        solutions[name] = solve_case(boundary, case_params)

    validation = {
        "main_diagnostics": main.diagnostics,
        "coarse_40_vs_main_80": compare_solutions(main, solutions["coarse_space_40_intervals_dt1"]),
        "main_80_vs_fine_160": compare_solutions(solutions["fine_space_160_intervals_dt1"], main),
        "dt1_vs_dt0_5": compare_solutions(solutions["fine_time_80_intervals_dt0_5"], main),
        "auxiliary_diagnostics": {
            name: solution.diagnostics for name, solution in solutions.items()
        },
        "acceptance_criteria": {
            "linear_relative_residual": 1.0e-10,
            "nonlinear_relative_residual": 1.0e-10,
            "discrete_balance_relative_residual": 1.0e-8,
            "positive_moisture_and_properties": True,
            "refinement_interpretation": "比较误差必须随网格/时间步加密下降；后向欧拉无条件稳定不等于离散误差已收敛。",
        },
    }
    return validation, solutions


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="问题2变物性耦合有限体积求解器")
    parser.add_argument(
        "--input",
        type=project_path,
        default=PROJECT_DIR / "附件1.xlsx",
        help="附件1.xlsx路径；相对路径以交付包根目录为基准",
    )
    parser.add_argument(
        "--output-dir",
        type=project_path,
        default=PROJECT_DIR / "数值数据",
        help="数值数据输出目录；相对路径以交付包根目录为基准",
    )
    parser.add_argument("--intervals", type=int, default=80, help="径向区间数")
    parser.add_argument("--dt", type=float, default=1.0, help="固定时间步长/s")
    parser.add_argument("--end-time", type=float, default=10800.0, help="终止时间/s")
    parser.add_argument("--skip-validation", action="store_true", help="跳过加密检验")
    return parser.parse_args()


def _write_csv(path: Path, header: list[str], rows: np.ndarray) -> None:
    np.savetxt(
        path,
        rows,
        delimiter=",",
        header=",".join(header),
        comments="",
        fmt="%.12g",
    )


def _write_solution_package(
    output_dir: Path,
    boundary: BoundaryData,
    solution: Q2Solution,
    validation: dict | None,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    output_temperature = sample_field(
        solution, solution.temperature_c, solution.times_s, OUTPUT_RADII_M
    )
    output_moisture = sample_field(
        solution, solution.moisture_kg_kg, solution.times_s, OUTPUT_RADII_M
    )
    radius_headers = [f"r_{r * 100:.1f}_cm" for r in OUTPUT_RADII_M]
    _write_csv(
        output_dir / "result2_temperature.csv",
        ["time_s", *radius_headers],
        np.column_stack([solution.times_s, output_temperature]),
    )
    _write_csv(
        output_dir / "result2_moisture.csv",
        ["time_s", *radius_headers],
        np.column_stack([solution.times_s, output_moisture]),
    )

    report_t = sample_field(
        solution, solution.temperature_c, REPORT_TIMES_S, REPORT_RADII_M
    )
    report_c = sample_field(
        solution, solution.moisture_kg_kg, REPORT_TIMES_S, REPORT_RADII_M
    )
    report_headers = ["time_s", *[f"r_{r * 100:.1f}_cm" for r in REPORT_RADII_M]]
    _write_csv(
        output_dir / "table3_temperature.csv",
        report_headers,
        np.column_stack([REPORT_TIMES_S, report_t]),
    )
    _write_csv(
        output_dir / "table4_moisture.csv",
        report_headers,
        np.column_stack([REPORT_TIMES_S, report_c]),
    )

    profile_times = np.arange(0.0, 10800.0 + 1.0, 1800.0)
    profile_t = sample_field(
        solution, solution.temperature_c, profile_times, OUTPUT_RADII_M
    )
    profile_c = sample_field(
        solution, solution.moisture_kg_kg, profile_times, OUTPUT_RADII_M
    )
    long_rows_t = []
    long_rows_c = []
    for it, time_s in enumerate(profile_times):
        for ir, radius_m in enumerate(OUTPUT_RADII_M):
            long_rows_t.append([time_s, radius_m * 100.0, profile_t[it, ir]])
            long_rows_c.append([time_s, radius_m * 100.0, profile_c[it, ir]])
    _write_csv(
        output_dir / "figure_temperature_profiles.csv",
        ["time_s", "radius_cm", "temperature_c"],
        np.asarray(long_rows_t),
    )
    _write_csv(
        output_dir / "figure_moisture_profiles.csv",
        ["time_s", "radius_cm", "moisture_kg_kg"],
        np.asarray(long_rows_c),
    )

    center_surface = np.column_stack(
        [
            solution.times_s,
            solution.temperature_c[:, 0],
            solution.temperature_c[:, -1],
            solution.moisture_kg_kg[:, 0],
            solution.moisture_kg_kg[:, -1],
            boundary.temperature(solution.times_s),
            boundary.moisture(solution.times_s),
        ]
    )
    _write_csv(
        output_dir / "figure_center_surface.csv",
        [
            "time_s",
            "temperature_center_c",
            "temperature_surface_c",
            "moisture_center_kg_kg",
            "moisture_surface_kg_kg",
            "ambient_temperature_c",
            "ambient_moisture_kg_kg",
        ],
        center_surface,
    )

    source_times = solution.times_s[::60]
    source_boundary = np.column_stack(
        [
            source_times,
            boundary.temperature(source_times),
            boundary.moisture(source_times),
        ]
    )
    _write_csv(
        output_dir / "figure_boundary_conditions.csv",
        ["time_s", "ambient_temperature_c", "ambient_moisture_kg_kg"],
        source_boundary,
    )

    source_temperature = solution.temperature_c[::60]
    source_moisture = solution.moisture_kg_kg[::60]
    property_rows = np.column_stack(
        [
            source_times,
            density_kg_m3(source_moisture[:, 0]),
            density_kg_m3(source_moisture[:, -1]),
            heat_capacity_j_kg_k(source_moisture[:, 0]),
            heat_capacity_j_kg_k(source_moisture[:, -1]),
            thermal_conductivity_w_m_k(source_moisture[:, 0]),
            thermal_conductivity_w_m_k(source_moisture[:, -1]),
            moisture_diffusivity_m2_s(
                source_moisture[:, 0], source_temperature[:, 0]
            ),
            moisture_diffusivity_m2_s(
                source_moisture[:, -1], source_temperature[:, -1]
            ),
        ]
    )
    _write_csv(
        output_dir / "figure_material_properties.csv",
        [
            "time_s",
            "density_center_kg_m3",
            "density_surface_kg_m3",
            "heat_capacity_center_j_kg_k",
            "heat_capacity_surface_j_kg_k",
            "conductivity_center_w_m_k",
            "conductivity_surface_w_m_k",
            "diffusivity_center_m2_s",
            "diffusivity_surface_m2_s",
        ],
        property_rows,
    )

    heatmap_times = solution.times_s[::60]
    heatmap_t = sample_field(
        solution, solution.temperature_c, heatmap_times, OUTPUT_RADII_M
    )
    heatmap_c = sample_field(
        solution, solution.moisture_kg_kg, heatmap_times, OUTPUT_RADII_M
    )
    np.savez_compressed(
        output_dir / "figure_heatmaps.npz",
        time_s=heatmap_times,
        radius_cm=OUTPUT_RADII_M * 100.0,
        temperature_c=heatmap_t,
        moisture_kg_kg=heatmap_c,
    )

    with (output_dir / "question2_diagnostics.json").open("w", encoding="utf-8") as f:
        json.dump(solution.diagnostics, f, ensure_ascii=False, indent=2)
    diagnostic_rows = []
    for key, value in solution.diagnostics.items():
        if isinstance(value, (str, int, float, bool)):
            diagnostic_rows.append([key, value])
    with (output_dir / "question2_diagnostics.csv").open("w", encoding="utf-8", newline="") as f:
        f.write("metric,value\n")
        for key, value in diagnostic_rows:
            f.write(f"{key},{value}\n")
    if validation is not None:
        with (output_dir / "question2_validation.json").open("w", encoding="utf-8") as f:
            json.dump(validation, f, ensure_ascii=False, indent=2)
        rows = []
        for comparison in (
            "coarse_40_vs_main_80",
            "main_80_vs_fine_160",
            "dt1_vs_dt0_5",
        ):
            values = validation[comparison]
            rows.append(
                [
                    comparison,
                    values["full_output_max_abs_temperature_c"],
                    values["full_output_max_abs_moisture_kg_kg"],
                    values["report_table_max_abs_temperature_c"],
                    values["report_table_max_abs_moisture_kg_kg"],
                ]
            )
        with (output_dir / "question2_refinement.csv").open("w", encoding="utf-8", newline="") as f:
            f.write(
                "comparison,full_temperature_error_c,full_moisture_error_kg_kg,"
                "report_temperature_error_c,report_moisture_error_kg_kg\n"
            )
            for row in rows:
                f.write(",".join(str(value) for value in row) + "\n")


def main() -> int:
    args = parse_args()
    params = Q2Parameters(
        intervals=args.intervals,
        time_step_s=args.dt,
        end_time_s=args.end_time,
    )
    boundary = read_boundary_data(args.input, params.end_time_s)
    main_solution = solve_case(boundary, params)
    validation = None
    if not args.skip_validation:
        validation, _ = run_validation(boundary, main_solution, params)
    _write_solution_package(args.output_dir, boundary, main_solution, validation)
    print(json.dumps(main_solution.diagnostics, ensure_ascii=False, indent=2))
    if validation is not None:
        print(json.dumps(validation, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
