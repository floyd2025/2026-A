#!/usr/bin/env python3
"""根据问题2数值数据生成论文图。

本脚本仅使用 requirements 文件列出的 Python 包，输出 PDF/SVG、
600 dpi PNG/TIFF、灰度预览及质量审计清单。
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image


def project_path(value: str | Path) -> Path:
    """Resolve relative command-line paths from the delivery package root."""
    path = Path(value).expanduser()
    return path if path.is_absolute() else PROJECT_DIR / path


def portable_path(path: Path) -> str:
    """Use a package-relative path in the figure manifest when possible."""
    try:
        return path.resolve().relative_to(PROJECT_DIR).as_posix()
    except ValueError:
        return str(path.resolve())


def setup_style(
    journal: str,
    lang: str,
    use_sciplots: bool,
    constrained_layout: bool,
) -> dict[str, object]:
    """Apply a reproducible plotting style using installed Python packages only."""
    style = "matplotlib-default"
    if use_sciplots:
        try:
            import scienceplots  # noqa: F401

            plt.style.use(["science", "no-latex"])
            style = "science/no-latex"
        except (ImportError, OSError):
            plt.style.use("default")
    else:
        plt.style.use("default")
    mpl.rcParams.update(
        {
            "figure.constrained_layout.use": constrained_layout,
            "font.sans-serif": [
                "Microsoft YaHei",
                "SimHei",
                "Noto Sans CJK SC",
                "Source Han Sans SC",
                "DejaVu Sans",
            ],
            "axes.unicode_minus": False,
        }
    )
    return {"journal": journal, "language": lang, "style": style}


def render_preview(fig: plt.Figure, path: str, dpi: int) -> None:
    preview_path = Path(path)
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview_path, dpi=dpi, bbox_inches="tight", pad_inches=0.06)


def audit_layout(fig: plt.Figure) -> list[tuple[str, str]]:
    """Perform a lightweight local layout check without external helper scripts."""
    width, height = fig.get_size_inches()
    issues: list[tuple[str, str]] = []
    if width <= 0 or height <= 0:
        issues.append(("FAIL", "图幅尺寸必须为正"))
    return issues


def print_layout_report(issues: list[tuple[str, str]]) -> str:
    for level, message in issues:
        print(f"[{level}] {message}")
    verdict = "FAIL" if any(level == "FAIL" for level, _ in issues) else "PASS"
    print(f"[layout] {verdict}")
    return verdict


def export_figure(
    fig: plt.Figure,
    basename: str,
    formats: tuple[str, ...],
    dpi: int,
    size_inches: tuple[float, float],
    grayscale_preview: bool,
    pad_inches: float,
) -> list[str]:
    base_path = Path(basename)
    base_path.parent.mkdir(parents=True, exist_ok=True)
    fig.set_size_inches(*size_inches)
    exported: list[str] = []
    for file_format in formats:
        output_path = base_path.with_suffix(f".{file_format}")
        fig.savefig(
            output_path,
            format=file_format,
            dpi=dpi,
            bbox_inches="tight",
            pad_inches=pad_inches,
        )
        exported.append(portable_path(output_path))
    if grayscale_preview:
        png_path = base_path.with_suffix(".png")
        grayscale_path = base_path.with_name(f"{base_path.name}_grayscale.png")
        with Image.open(png_path) as source:
            source.convert("L").convert("RGB").save(
                grayscale_path,
                dpi=(dpi, dpi),
            )
        exported.append(portable_path(grayscale_path))
    return exported


def check_figure(path: str | Path, min_dpi: int) -> tuple[list[tuple[str, str]], dict[str, object]]:
    figure_path = project_path(path)
    issues: list[tuple[str, str]] = []
    info: dict[str, object] = {"format": figure_path.suffix.lower().lstrip(".")}
    if not figure_path.is_file():
        return [("FAIL", "文件不存在")], info
    if figure_path.suffix.lower() in {".png", ".tif", ".tiff"}:
        with Image.open(figure_path) as source:
            dpi = source.info.get("dpi", (0, 0))
            info.update({"size_px": source.size, "dpi": dpi})
            if dpi and min(dpi) + 1 < min_dpi:
                issues.append(("FAIL", f"分辨率低于 {min_dpi} dpi"))
    return issues, info


COLORS = {
    "blue": "#0072B2",
    "orange": "#E69F00",
    "green": "#009E73",
    "red": "#D55E00",
    "purple": "#CC79A7",
    "sky": "#56B4E9",
    "black": "#111111",
    "gray": "#777777",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="绘制问题2论文图")
    parser.add_argument(
        "--data-dir",
        type=project_path,
        default=PROJECT_DIR / "数值数据",
        help="绘图数据目录；相对路径以交付包根目录为基准",
    )
    parser.add_argument(
        "--output-dir",
        type=project_path,
        default=PROJECT_DIR / "论文图",
        help="图件输出目录；相对路径以交付包根目录为基准",
    )
    return parser.parse_args()


def read_numeric_csv(path: Path) -> dict[str, np.ndarray]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"绘图源数据为空：{path}")
    data: dict[str, np.ndarray] = {}
    for key in rows[0]:
        try:
            data[key] = np.asarray([row[key] for row in rows], dtype=float)
        except ValueError:
            data[key] = np.asarray([row[key] for row in rows], dtype=object)
    return data


def style_axes(ax: plt.Axes) -> None:
    ax.grid(color="#D8D8D8", linewidth=0.55, alpha=0.7)
    ax.tick_params(direction="out", length=3.0, width=0.7)
    ax.margins(x=0.02)


def save_figure(
    fig: plt.Figure,
    output_dir: Path,
    name: str,
    manifest: list[dict],
    size: tuple[float, float] = (7.2, 3.35),
) -> None:
    fig.set_size_inches(*size)
    fig.canvas.draw()
    preview_dir = output_dir / "_qa_previews"
    preview_path = preview_dir / f"{name}_preview.png"
    render_preview(fig, str(preview_path), dpi=180)
    issues = audit_layout(fig)
    verdict = print_layout_report(issues)
    if verdict == "FAIL":
        raise RuntimeError(f"{name}版面自检失败")
    exported = export_figure(
        fig,
        basename=str(output_dir / name),
        formats=("pdf", "svg", "png", "tiff"),
        dpi=600,
        size_inches=size,
        grayscale_preview=True,
        pad_inches=0.06,
    )
    manifest.append(
        {
            "name": name,
            "claim": {
                "q2_boundary_conditions": "附件1给出的外界温度与水分条件覆盖完整3 h过程",
                "q2_temperature_moisture_heatmaps": "热量向内传递而水分由表及里持续下降",
                "q2_radial_profiles": "3 h内温湿场的径向梯度随时间演化",
                "q2_center_surface_history": "表面响应快于中心，存在显著内部滞后",
                "q2_variable_properties": "含水率和温度变化使导热与扩散能力显著时变",
                "q2_numerical_refinement": "网格与时间步加密后的差异处于较小量级",
            }[name],
            "layout_verdict": verdict,
            "layout_issues": issues,
            "preview": portable_path(preview_path),
            "exported": exported,
        }
    )
    plt.close(fig)


def plot_boundary(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    hours = data["time_s"] / 3600.0
    fig, axes = plt.subplots(1, 2, sharex=True)
    axes[0].plot(hours, data["ambient_temperature_c"], color=COLORS["red"], lw=1.5)
    axes[0].set_ylabel("外界温度 / °C")
    axes[0].set_title("(a) 温度边界")
    axes[1].plot(hours, data["ambient_moisture_kg_kg"], color=COLORS["blue"], lw=1.5)
    axes[1].set_ylabel("外界水分浓度 / (kg/kg)")
    axes[1].set_title("(b) 水分边界")
    for ax in axes:
        ax.set_xlabel("时间 / h")
        ax.set_xticks(np.arange(0, 3.01, 0.5))
        style_axes(ax)
    fig.suptitle("问题2全过程边界条件", y=0.995)
    save_figure(fig, out, "q2_boundary_conditions", manifest)


def plot_heatmaps(npz_path: Path, out: Path, manifest: list[dict]) -> None:
    data = np.load(npz_path)
    time_h = data["time_s"] / 3600.0
    radius_cm = data["radius_cm"]
    fig, axes = plt.subplots(1, 2, sharex=True, sharey=True)
    im0 = axes[0].pcolormesh(
        time_h,
        radius_cm,
        data["temperature_c"].T,
        shading="auto",
        cmap="cividis",
    )
    im1 = axes[1].pcolormesh(
        time_h,
        radius_cm,
        data["moisture_kg_kg"].T,
        shading="auto",
        cmap="viridis_r",
    )
    for ax in axes:
        ax.set_xlabel("时间 / h")
        ax.set_xticks(np.arange(0, 3.01, 0.5))
    axes[0].set_ylabel("半径 / cm")
    axes[0].set_title("(a) 温度场")
    axes[1].set_title("(b) 含水率场")
    cb0 = fig.colorbar(im0, ax=axes[0], pad=0.02)
    cb0.set_label("温度 / °C")
    cb1 = fig.colorbar(im1, ax=axes[1], pad=0.02)
    cb1.set_label("含水率 / (kg/kg)")
    fig.suptitle("3 h内温度—水分时空演化", y=0.995)
    save_figure(fig, out, "q2_temperature_moisture_heatmaps", manifest, (7.4, 3.4))


def plot_profiles(
    temperature: dict[str, np.ndarray],
    moisture: dict[str, np.ndarray],
    out: Path,
    manifest: list[dict],
) -> None:
    fig, axes = plt.subplots(1, 2, sharex=True)
    times = np.unique(temperature["time_s"])
    colors = plt.get_cmap("cividis")(np.linspace(0.08, 0.92, len(times)))
    line_styles = ["-", "--", "-.", ":", (0, (5, 2)), (0, (2, 1)), (0, (6, 2, 1, 2))]
    markers = ["o", "s", "^", "D", "v", "P", "X"]
    for index, time_s in enumerate(times):
        mask_t = temperature["time_s"] == time_s
        mask_c = moisture["time_s"] == time_s
        label = f"{time_s / 3600:.1f} h"
        axes[0].plot(
            temperature["radius_cm"][mask_t],
            temperature["temperature_c"][mask_t],
            color=colors[index],
            ls=line_styles[index],
            marker=markers[index],
            markevery=4,
            ms=3.0,
            markerfacecolor="white",
            lw=1.15,
            label=label,
        )
        axes[1].plot(
            moisture["radius_cm"][mask_c],
            moisture["moisture_kg_kg"][mask_c],
            color=colors[index],
            ls=line_styles[index],
            marker=markers[index],
            markevery=4,
            ms=3.0,
            markerfacecolor="white",
            lw=1.15,
            label=label,
        )
    axes[0].set_ylabel("温度 / °C")
    axes[0].set_title("(a) 径向温度剖面")
    axes[1].set_ylabel("含水率 / (kg/kg)")
    axes[1].set_title("(b) 径向含水率剖面")
    for ax in axes:
        ax.set_xlabel("半径 / cm")
        ax.set_xticks(np.arange(0, 2.01, 0.5))
        style_axes(ax)
    axes[1].legend(ncol=2, loc="best", handlelength=2.2, columnspacing=0.8)
    fig.suptitle("不同时刻的径向温湿分布", y=0.995)
    save_figure(fig, out, "q2_radial_profiles", manifest)


def plot_histories(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    hours = data["time_s"] / 3600.0
    fig, axes = plt.subplots(1, 2, sharex=True)
    axes[0].plot(hours, data["ambient_temperature_c"], color=COLORS["gray"], lw=1.0, ls=":", label="外界")
    axes[0].plot(hours, data["temperature_surface_c"], color=COLORS["red"], lw=1.35, ls="--", label="表面")
    axes[0].plot(hours, data["temperature_center_c"], color=COLORS["blue"], lw=1.35, label="中心")
    axes[1].plot(hours, data["ambient_moisture_kg_kg"], color=COLORS["gray"], lw=1.0, ls=":", label="外界")
    axes[1].plot(hours, data["moisture_surface_kg_kg"], color=COLORS["orange"], lw=1.35, ls="--", label="表面")
    axes[1].plot(hours, data["moisture_center_kg_kg"], color=COLORS["green"], lw=1.35, label="中心")
    axes[0].set_ylabel("温度 / °C")
    axes[0].set_title("(a) 中心—表面温度")
    axes[1].set_ylabel("含水率 / (kg/kg)")
    axes[1].set_title("(b) 中心—表面含水率")
    for ax in axes:
        ax.set_xlabel("时间 / h")
        ax.set_xticks(np.arange(0, 3.01, 0.5))
        ax.legend(loc="best")
        style_axes(ax)
    fig.suptitle("中心与表面对外界条件的响应差异", y=0.995)
    save_figure(fig, out, "q2_center_surface_history", manifest)


def plot_properties(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    hours = data["time_s"] / 3600.0
    fig, axes = plt.subplots(1, 2, sharex=True)
    axes[0].plot(hours, data["conductivity_center_w_m_k"], color=COLORS["blue"], lw=1.35, label="中心")
    axes[0].plot(hours, data["conductivity_surface_w_m_k"], color=COLORS["red"], lw=1.35, ls="--", label="表面")
    axes[1].plot(hours, data["diffusivity_center_m2_s"] * 1e9, color=COLORS["green"], lw=1.35, label="中心")
    axes[1].plot(hours, data["diffusivity_surface_m2_s"] * 1e9, color=COLORS["orange"], lw=1.35, ls="--", label="表面")
    axes[0].set_ylabel("导热系数 / [W/(m·K)]")
    axes[0].set_title("(a) 导热系数 $k(C)$")
    axes[1].set_ylabel(r"扩散系数 / ($10^{-9}$ m$^2$/s)")
    axes[1].set_title("(b) 扩散系数 $D(C,T)$")
    for ax in axes:
        ax.set_xlabel("时间 / h")
        ax.set_xticks(np.arange(0, 3.01, 0.5))
        ax.legend(loc="best")
        style_axes(ax)
    fig.suptitle("变物性系数的时空差异", y=0.995)
    save_figure(fig, out, "q2_variable_properties", manifest)


def plot_refinement(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    labels = ["40–80\n网格", "80–160\n网格", "1–0.5 s\n时间步"]
    x = np.arange(3)
    fig, axes = plt.subplots(1, 2)
    for ax, full_key, report_key, ylabel, title in [
        (axes[0], "full_temperature_error_c", "report_temperature_error_c", "最大绝对差 / °C", "(a) 温度"),
        (axes[1], "full_moisture_error_kg_kg", "report_moisture_error_kg_kg", "最大绝对差 / (kg/kg)", "(b) 含水率"),
    ]:
        # 三个横轴类别分别代表空间和时间检验，不能用折线暗示连续顺序。
        ax.scatter(x - 0.08, data[full_key], color=COLORS["red"], marker="o", s=36, label="全输出域", zorder=3)
        ax.scatter(x + 0.08, data[report_key], color=COLORS["blue"], marker="s", s=36, label="题目报告点", zorder=3)
        ax.set_yscale("log")
        ax.set_xticks(x, labels)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.legend(loc="best")
        style_axes(ax)
    fig.suptitle("空间与时间离散加密检验", y=0.995)
    save_figure(fig, out, "q2_numerical_refinement", manifest)


def main() -> int:
    args = parse_args()
    data_dir = args.data_dir
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_info = setup_style(
        journal="general", lang="zh", use_sciplots=False, constrained_layout=True
    )
    mpl.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.titleweight": "semibold",
        }
    )

    manifest: list[dict] = []
    plot_boundary(read_numeric_csv(data_dir / "figure_boundary_conditions.csv"), output_dir, manifest)
    plot_heatmaps(data_dir / "figure_heatmaps.npz", output_dir, manifest)
    plot_profiles(
        read_numeric_csv(data_dir / "figure_temperature_profiles.csv"),
        read_numeric_csv(data_dir / "figure_moisture_profiles.csv"),
        output_dir,
        manifest,
    )
    plot_histories(read_numeric_csv(data_dir / "figure_center_surface.csv"), output_dir, manifest)
    plot_properties(read_numeric_csv(data_dir / "figure_material_properties.csv"), output_dir, manifest)
    plot_refinement(read_numeric_csv(data_dir / "question2_refinement.csv"), output_dir, manifest)

    compliance = []
    for figure in manifest:
        for path in figure["exported"]:
            issues, info = check_figure(path, min_dpi=300)
            compliance.append(
                {
                    "path": path,
                    "issues": issues,
                    "info": info,
                    "has_failure": any(level == "FAIL" for level, _ in issues),
                }
            )
    failures = [item for item in compliance if item["has_failure"]]
    if failures:
        raise RuntimeError(f"{len(failures)}个图文件未通过格式/DPI/字体审计")
    (output_dir / "figure_manifest.json").write_text(
        json.dumps(
            {
                "style": setup_info,
                "figures": manifest,
                "compliance_audit": compliance,
                "compliance_failures": len(failures),
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )
    print(f"共生成{len(manifest)}张问题2论文图：{output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
