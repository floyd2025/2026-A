import fs from "node:fs/promises";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = process.cwd();
const dataDir = `${root}/outputs/question2_package`;
const outputDir = `${root}/outputs`;
const previewDir = `${root}/work/question2_workbook_previews`;
const resultPath = `${outputDir}/result2.xlsx`;
const reportPath = `${outputDir}/问题2_报告表与数值检验.xlsx`;

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const COLORS = {
  navy: "#17365D",
  blue: "#1F4E78",
  paleBlue: "#D9EAF7",
  paleGreen: "#E2F0D9",
  paleYellow: "#FFF2CC",
  paleRed: "#FCE4D6",
  white: "#FFFFFF",
  text: "#1F1F1F",
  grid: "#D9E2F3",
  green: "#548235",
  red: "#C00000",
};
const FONT = "Arial";

function parseNumericCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(",");
  const rows = lines.slice(1).map((line) => line.split(",").map(Number));
  return { headers, rows };
}

function parseMixedCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(",");
  const rows = lines.slice(1).map((line) => {
    const fields = line.split(",");
    return fields.map((value, i) => {
      if (i === 0) return value;
      const numeric = Number(value);
      return Number.isFinite(numeric) ? numeric : value;
    });
  });
  return { headers, rows };
}

function columnLetter(index0) {
  let n = index0 + 1;
  let out = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function applyHeader(range) {
  range.format = {
    fill: COLORS.blue,
    font: { name: FONT, bold: true, color: COLORS.white, size: 10 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: COLORS.grid },
  };
  range.format.rowHeight = 30;
}

function applyBody(range, centered = false) {
  range.format = {
    font: { name: FONT, color: COLORS.text, size: 10 },
    horizontalAlignment: centered ? "center" : "left",
    verticalAlignment: "center",
    borders: { preset: "all", style: "thin", color: COLORS.grid },
  };
}

const temperatureCsv = parseNumericCsv(
  await fs.readFile(`${dataDir}/result2_temperature.csv`, "utf8")
);
const moistureCsv = parseNumericCsv(
  await fs.readFile(`${dataDir}/result2_moisture.csv`, "utf8")
);
const table3Csv = parseNumericCsv(
  await fs.readFile(`${dataDir}/table3_temperature.csv`, "utf8")
);
const table4Csv = parseNumericCsv(
  await fs.readFile(`${dataDir}/table4_moisture.csv`, "utf8")
);
const refinementCsv = parseMixedCsv(
  await fs.readFile(`${dataDir}/question2_refinement.csv`, "utf8")
);
const diagnostics = JSON.parse(
  await fs.readFile(`${dataDir}/question2_diagnostics.json`, "utf8")
);
const validation = JSON.parse(
  await fs.readFile(`${dataDir}/question2_validation.json`, "utf8")
);

function createResultWorkbook() {
  const workbook = Workbook.create();
  for (const [sheetName, source] of [
    ["温度", temperatureCsv],
    ["水分浓度", moistureCsv],
  ]) {
    const sheet = workbook.worksheets.add(sheetName);
    const radii = source.headers.slice(1).map((header) => {
      const match = header.match(/^r_([0-9.]+)_cm$/);
      if (!match) throw new Error(`无法识别半径表头：${header}`);
      return Number(match[1]);
    });
    const headers = ["时间/s", ...radii];
    const rowCount = source.rows.length + 1;
    const colCount = headers.length;
    sheet.getRangeByIndexes(0, 0, 1, colCount).values = [headers];
    applyHeader(sheet.getRangeByIndexes(0, 0, 1, colCount));
    sheet.getRangeByIndexes(1, 0, source.rows.length, colCount).values = source.rows;
    const lastColumn = columnLetter(colCount - 1);
    sheet.getRange(`A2:A${rowCount}`).setNumberFormat("0");
    sheet.getRange(`B1:${lastColumn}1`).setNumberFormat("0.0");
    sheet.getRange(`B2:${lastColumn}${rowCount}`).setNumberFormat("0.0000");
    sheet.getRange(`A1:A${rowCount}`).format.columnWidth = 11;
    sheet.getRange(`B1:${lastColumn}${rowCount}`).format.columnWidth = 10;
    sheet.getRange(`A2:${lastColumn}${rowCount}`).format.font = {
      name: FONT,
      size: 9,
      color: COLORS.text,
    };
    sheet.freezePanes.freezeRows(1);
    sheet.freezePanes.freezeColumns(1);
    sheet.showGridLines = true;
    sheet.tabColor = sheetName === "温度" ? COLORS.blue : COLORS.green;
  }
  return workbook;
}

function addExplanationSheet(workbook) {
  const sheet = workbook.worksheets.add("说明");
  sheet.showGridLines = false;
  sheet.getRange("A2:B2").values = [["问题2：变物性耦合温湿场计算", ""]];
  sheet.getRange("A2:B2").format = {
    font: { name: FONT, bold: true, size: 15, color: COLORS.navy },
    borders: { bottom: { style: "medium", color: COLORS.blue } },
  };
  sheet.getRange("A4:B4").values = [["项目", "内容"]];
  applyHeader(sheet.getRange("A4:B4"));
  const rows = [
    ["研究目标", "计算圆柱药材在0~3 h内的径向温度和含水率分布，并按题目要求给出每0.5 h、5个半径位置的报告表。"],
    ["主模型", "轴对称一维圆柱模型；空间为节点型守恒有限体积法，80个径向区间（81节点）；时间为1 s后向欧拉。"],
    ["非线性求解", "每一时间步内用耦合Picard迭代，同时更新T、C、ρ(C)、cp(C)、k(C)与D(C,T)，温度和水分子问题均为三对角线性方程组。"],
    ["材料参数", "ρ=650+128C；cp=1450+2736C/(C+1)；k=0.21+0.38C/(C+1)；D=2.4×10^-3 exp(-0.45/C) exp[-3850/(T+273.15)]。"],
    ["初始条件", "T(r,0)=28 °C，C(r,0)=2.55 kg/kg。"],
    ["边界数据", "附件1覆盖0~14400 s；本题使用0~10800 s并对相邻60 s测点线性插值。"],
    ["必要假设", "题目第二问未另给表面对流系数，沿用第一问h=25 W/(m²·K)、hm=8×10^-7 m/s；半径固定为2 cm。"],
    ["边界离散", "r=0由中心控制体自动满足对称零通量；r=R将Robin对流换热/传质通量直接计入表面半控制体。"],
    ["报告精度", "结果值保留完整浮点数，Excel显示为4位小数；论文表3、表4使用0.5 h间隔和0、0.5、1、1.5、2 cm半径。"],
    ["验证结论", "线性/非线性残差、全局离散守恒、正性及网格/时间步加密均已检查；详细数值见“数值检验”。"],
    ["局限性", "题面未给蒸发潜热、体积收缩及平衡含水率模型，因此本问不自行引入；第二问半径按题意保持2 cm，收缩留待第四问。"],
    ["模板说明", "当前附件中未包含附件3原始模板；result2.xlsx严格按题面规定建立“温度”“水分浓度”两张表，A列为时间、首行为半径。"],
  ];
  sheet.getRangeByIndexes(4, 0, rows.length, 2).values = rows;
  applyBody(sheet.getRangeByIndexes(4, 0, rows.length, 2));
  sheet.getRange(`A5:A${4 + rows.length}`).format = {
    fill: COLORS.paleBlue,
    font: { name: FONT, bold: true, color: COLORS.navy, size: 10 },
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: COLORS.grid },
  };
  sheet.getRange(`B5:B${4 + rows.length}`).format.wrapText = true;
  sheet.getRange(`A5:B${4 + rows.length}`).format.rowHeight = 33;
  sheet.getRange("A1:A20").format.columnWidth = 20;
  sheet.getRange("B1:B20").format.columnWidth = 92;
  sheet.freezePanes.freezeRows(4);
  sheet.tabColor = COLORS.navy;
}

function addReportTable(workbook, sheetName, title, source, unitLabel, tabColor) {
  const sheet = workbook.worksheets.add(sheetName);
  sheet.showGridLines = false;
  sheet.getRange("A2:F2").values = [[title, "", "", "", "", ""]];
  sheet.getRange("A2:F2").format = {
    font: { name: FONT, bold: true, size: 14, color: COLORS.navy },
    borders: { bottom: { style: "medium", color: COLORS.blue } },
  };
  const radii = source.headers.slice(1).map((header) => Number(header.match(/^r_([0-9.]+)_cm$/)[1]));
  sheet.getRange("A4:F4").values = [["时间/h", ...radii.map((r) => `r=${r.toFixed(1)} cm`)]];
  applyHeader(sheet.getRange("A4:F4"));
  const rows = source.rows.map((row) => [row[0] / 3600.0, ...row.slice(1)]);
  sheet.getRangeByIndexes(4, 0, rows.length, 6).values = rows;
  applyBody(sheet.getRangeByIndexes(4, 0, rows.length, 6), true);
  sheet.getRange(`A5:A${4 + rows.length}`).setNumberFormat("0.0");
  sheet.getRange(`B5:F${4 + rows.length}`).setNumberFormat("0.0000");
  sheet.getRange("A12:B12").values = [["单位", unitLabel]];
  sheet.getRange("A12:B12").format = {
    fill: COLORS.paleYellow,
    font: { name: FONT, italic: true, color: COLORS.text, size: 10 },
    borders: { preset: "outside", style: "thin", color: COLORS.grid },
  };
  sheet.getRange("A1:F14").format.columnWidth = 16;
  sheet.freezePanes.freezeRows(4);
  sheet.tabColor = tabColor;
}

function addValidationSheet(workbook) {
  const sheet = workbook.worksheets.add("数值检验");
  sheet.showGridLines = false;
  sheet.getRange("A2:E2").values = [["问题2数值可信度检验", "", "", "", ""]];
  sheet.getRange("A2:E2").format = {
    font: { name: FONT, bold: true, size: 14, color: COLORS.navy },
    borders: { bottom: { style: "medium", color: COLORS.blue } },
  };

  sheet.getRange("A4:D4").values = [["主算例检验项", "实测最大值", "验收阈值", "判断"]];
  applyHeader(sheet.getRange("A4:D4"));
  const checks = [
    ["温度线性相对残差", diagnostics.max_temperature_linear_relative_residual, 1e-10],
    ["水分线性相对残差", diagnostics.max_moisture_linear_relative_residual, 1e-10],
    ["温度非线性相对残差", diagnostics.max_temperature_nonlinear_relative_residual, 1e-10],
    ["水分非线性相对残差", diagnostics.max_moisture_nonlinear_relative_residual, 1e-10],
    ["热量离散守恒相对残差", diagnostics.max_heat_balance_relative_residual, 1e-8],
    ["水分离散守恒相对残差", diagnostics.max_moisture_balance_relative_residual, 1e-8],
    ["Picard最终相对更新", diagnostics.max_final_picard_relative_update, 1e-9],
  ];
  sheet.getRangeByIndexes(4, 0, checks.length, 3).values = checks;
  applyBody(sheet.getRangeByIndexes(4, 0, checks.length, 3));
  for (let i = 0; i < checks.length; i += 1) {
    const row = 5 + i;
    sheet.getRange(`D${row}`).formulas = [[`=IF(B${row}<=C${row},"通过","检查")`]];
  }
  applyBody(sheet.getRange(`D5:D${4 + checks.length}`), true);
  sheet.getRange(`B5:C${4 + checks.length}`).setNumberFormat("0.000E+00");

  sheet.getRange("A14:E14").values = [["加密比较", "全域max|ΔT|/°C", "全域max|ΔC|/(kg/kg)", "报告点max|ΔT|/°C", "报告点max|ΔC|/(kg/kg)"]];
  applyHeader(sheet.getRange("A14:E14"));
  const labels = {
    coarse_40_vs_main_80: "空间40–80",
    main_80_vs_fine_160: "空间80–160",
    dt1_vs_dt0_5: "时间1–0.5 s",
  };
  const refinementRows = refinementCsv.rows.map((row) => [labels[row[0]] ?? row[0], ...row.slice(1)]);
  sheet.getRangeByIndexes(14, 0, refinementRows.length, 5).values = refinementRows;
  applyBody(sheet.getRangeByIndexes(14, 0, refinementRows.length, 5), true);
  sheet.getRange("B15:E17").setNumberFormat("0.000000E+00");

  sheet.getRange("G4:H4").values = [["迭代与范围", "数值"]];
  applyHeader(sheet.getRange("G4:H4"));
  const auxiliary = [
    ["Picard最多次数", diagnostics.picard_iterations_max],
    ["Picard平均次数", diagnostics.picard_iterations_mean],
    ["温度最小/°C", diagnostics.temperature_min_c],
    ["温度最大/°C", diagnostics.temperature_max_c],
    ["含水率最小/(kg/kg)", diagnostics.moisture_min_kg_kg],
    ["含水率最大/(kg/kg)", diagnostics.moisture_max_kg_kg],
    ["热平衡最大绝对残差/(J/m)", diagnostics.max_heat_balance_absolute_residual_j_per_m],
    ["水分平衡最大绝对残差", diagnostics.max_moisture_balance_absolute_residual_m2_kg_per_kg],
  ];
  sheet.getRangeByIndexes(4, 6, auxiliary.length, 2).values = auxiliary;
  applyBody(sheet.getRangeByIndexes(4, 6, auxiliary.length, 2));
  sheet.getRange(`H5:H${4 + auxiliary.length}`).setNumberFormat("0.000000E+00");

  sheet.getRange("G14:H14").values = [["综合判断", "结论"]];
  applyHeader(sheet.getRange("G14:H14"));
  const conclusions = [
    ["代数求解", "通过：线性与耦合非线性残差均远低于阈值。"],
    ["离散守恒", "通过：热量与水分的控制体全局平衡残差远低于10^-8。"],
    ["空间加密", "40–80到80–160时，报告点温度/水分差异约缩小4倍，符合二阶空间收敛特征。"],
    ["时间加密", "1 s与0.5 s在报告点的最大差异小于0.001 °C和0.00005 kg/kg。"],
    ["报告口径", "四位小数并非逐项完全相同；应报告加密误差，不能用无条件稳定替代收敛性论证。"],
  ];
  sheet.getRangeByIndexes(14, 6, conclusions.length, 2).values = conclusions;
  applyBody(sheet.getRangeByIndexes(14, 6, conclusions.length, 2));
  sheet.getRange("H15:H19").format = {
    fill: COLORS.paleGreen,
    font: { name: FONT, color: COLORS.green, bold: true, size: 10 },
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: COLORS.grid },
  };

  sheet.getRange("A1:A22").format.columnWidth = 29;
  sheet.getRange("B1:E22").format.columnWidth = 20;
  sheet.getRange("F1:F22").format.columnWidth = 3;
  sheet.getRange("G1:G22").format.columnWidth = 30;
  sheet.getRange("H1:H22").format.columnWidth = 62;
  sheet.getRange("A15:H19").format.rowHeight = 31;
  sheet.freezePanes.freezeRows(4);
  sheet.tabColor = COLORS.green;
}

function addPropertiesSheet(workbook) {
  const sheet = workbook.worksheets.add("物性范围");
  sheet.showGridLines = false;
  sheet.getRange("A2:D2").values = [["3 h计算过程中的变物性范围", "", "", ""]];
  sheet.getRange("A2:D2").format = {
    font: { name: FONT, bold: true, size: 14, color: COLORS.navy },
    borders: { bottom: { style: "medium", color: COLORS.blue } },
  };
  sheet.getRange("A4:D4").values = [["物性", "最小值", "最大值", "单位"]];
  applyHeader(sheet.getRange("A4:D4"));
  const rows = [
    ["密度ρ(C)", diagnostics.density_min_kg_m3, diagnostics.density_max_kg_m3, "kg/m³"],
    ["比热容cp(C)", diagnostics.heat_capacity_min_j_kg_k, diagnostics.heat_capacity_max_j_kg_k, "J/(kg·K)"],
    ["导热系数k(C)", diagnostics.conductivity_min_w_m_k, diagnostics.conductivity_max_w_m_k, "W/(m·K)"],
    ["扩散系数D(C,T)", diagnostics.diffusivity_min_m2_s, diagnostics.diffusivity_max_m2_s, "m²/s"],
  ];
  sheet.getRangeByIndexes(4, 0, rows.length, 4).values = rows;
  applyBody(sheet.getRangeByIndexes(4, 0, rows.length, 4), true);
  sheet.getRange("B5:C8").setNumberFormat("0.000000E+00");
  sheet.getRange("A10:A11").merge();
  sheet.getRange("B10:D11").merge();
  sheet.getRange("A10").values = [["解释"]];
  sheet.getRange("B10").values = [["干燥使ρ、cp、k下降；D受T与C共同作用，先增强后趋稳。"]];
  sheet.getRange("A10:D11").format = {
    fill: COLORS.paleYellow,
    font: { name: FONT, italic: true, color: COLORS.text, size: 10 },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "outside", style: "thin", color: COLORS.grid },
  };
  sheet.getRange("A10:D11").format.rowHeight = 30;
  sheet.getRange("A1:A12").format.columnWidth = 26;
  sheet.getRange("B1:C12").format.columnWidth = 22;
  sheet.getRange("D1:D12").format.columnWidth = 18;
  sheet.tabColor = COLORS.paleBlue;
}

function createReportWorkbook() {
  const workbook = Workbook.create();
  addExplanationSheet(workbook);
  addReportTable(workbook, "表3温度", "表3  不同时刻与半径位置的温度", table3Csv, "温度：°C", COLORS.blue);
  addReportTable(workbook, "表4水分浓度", "表4  不同时刻与半径位置的含水率", table4Csv, "含水率：kg/kg", COLORS.green);
  addValidationSheet(workbook);
  addPropertiesSheet(workbook);
  return workbook;
}

async function finalizeAndSave(workbook, outputPath) {
  await workbook.recalculate();
  const output = await SpreadsheetFile.exportXlsx(workbook);
  await output.save(outputPath);
}

async function verifyWorkbook(workbookPath, keyRanges, previewSheets, previewPrefix, truncateLarge = false) {
  const blob = await FileBlob.load(workbookPath);
  const workbook = await SpreadsheetFile.importXlsx(blob);
  const sheets = await workbook.inspect({
    kind: "sheet",
    include: "id,name",
    maxChars: 6000,
  });
  const rangeInspections = [];
  for (const range of keyRanges) {
    const inspection = await workbook.inspect({
      kind: "table",
      range,
      include: "values,formulas",
      tableMaxRows: 12,
      tableMaxCols: 24,
      maxChars: 20000,
    });
    rangeInspections.push({ range, ndjson: inspection.ndjson });
  }
  const formulaErrors = await workbook.inspect({
    kind: "match",
    searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!",
    options: { useRegex: true, maxResults: 100 },
    summary: "formula error scan",
    maxChars: 5000,
  });

  if (truncateLarge) {
    for (const sheetName of previewSheets) {
      const sheet = workbook.worksheets.getItem(sheetName);
      sheet.getRange("A52:V10802").clear({ applyTo: "contents" });
    }
  }
  for (const sheetName of previewSheets) {
    const preview = await workbook.render({
      sheetName,
      autoCrop: "all",
      scale: 1.0,
      format: "png",
    });
    const bytes = new Uint8Array(await preview.arrayBuffer());
    await fs.writeFile(`${previewDir}/${previewPrefix}_${sheetName}.png`, bytes);
  }
  return {
    sheets: sheets.ndjson,
    rangeInspections,
    formulaErrors: formulaErrors.ndjson,
  };
}

const resultWorkbook = createResultWorkbook();
await finalizeAndSave(resultWorkbook, resultPath);
const reportWorkbook = createReportWorkbook();
await finalizeAndSave(reportWorkbook, reportPath);

const verification = {
  result2: await verifyWorkbook(
    resultPath,
    ["温度!A1:V6", "温度!A10798:V10802", "水分浓度!A1:V6", "水分浓度!A10798:V10802"],
    ["温度", "水分浓度"],
    "result2",
    true
  ),
  report: await verifyWorkbook(
    reportPath,
    ["说明!A2:B16", "表3温度!A4:F10", "表4水分浓度!A4:F10", "数值检验!A4:H19", "物性范围!A4:D10"],
    ["说明", "表3温度", "表4水分浓度", "数值检验", "物性范围"],
    "report",
    false
  ),
};
await fs.writeFile(
  `${previewDir}/verification.json`,
  JSON.stringify(verification, null, 2),
  "utf8"
);

console.log(JSON.stringify({
  resultPath,
  reportPath,
  resultFormulaErrors: verification.result2.formulaErrors,
  reportFormulaErrors: verification.report.formulaErrors,
}, null, 2));
process.exit(0);
