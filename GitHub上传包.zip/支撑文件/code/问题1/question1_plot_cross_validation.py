#!/usr/bin/env python3
"""以可独立复现的论文绘图工作流绘制问题1两类交叉验证图。

运行前应先执行question1_generate_cross_validation_data.py，并用
生成的数据完成绘图源数据剖析。本脚本仅依赖公开Python包，内置统一样式、
多格式导出和基础版面自检，输出PDF/SVG/PNG/TIFF及灰度预览。
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent

try:
    import matplotlib as mpl

    mpl.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib import font_manager
    from PIL import Image
except ImportError as exc:
    mpl = None
    plt = None
    np = None
    font_manager = None
    Image = None
    _PLOTTING_IMPORT_ERROR: ImportError | None = exc
else:
    _PLOTTING_IMPORT_ERROR = None


OKABE_ITO = {
    "blue": "#0072B2",
    "orange": "#E69F00",
    "green": "#009E73",
    "red": "#D55E00",
    "purple": "#CC79A7",
    "sky": "#56B4E9",
    "black": "#111111",
    "gray": "#777777",
}


def setup_style(
    journal: str = "general",
    lang: str = "zh",
    use_sciplots: bool = False,
    constrained_layout: bool = True,
) -> dict:
    """配置不依赖本地SciPilot安装的基础论文图样式。"""
    del journal, use_sciplots  # 保留与原调用的接口一致性
    preferred = (
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Heiti SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
    )
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    selected = next((name for name in preferred if name in available), None)
    sans_serif = [selected, "DejaVu Sans"] if selected else ["DejaVu Sans"]
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": sans_serif,
            "axes.unicode_minus": False,
            "figure.constrained_layout.use": constrained_layout,
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 10,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    if lang == "zh" and selected is None:
        print(
            "警告：未检测到中文字体，建议安装Noto Sans CJK SC；"
            "数值计算不受影响，但图中中文可能缺字。"
        )
    return {
        "mode": "portable-matplotlib",
        "language": lang,
        "font": selected or "DejaVu Sans (CJK font unavailable)",
        "constrained_layout": constrained_layout,
    }


def render_preview(fig: plt.Figure, path: str, dpi: int = 180) -> None:
    preview_path = Path(path)
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview_path, dpi=dpi, bbox_inches="tight", pad_inches=0.06)


def audit_layout(fig: plt.Figure) -> list[tuple[str, str]]:
    """便携版的基础版面检查；高级感知检查仍需人工审图。"""
    issues: list[tuple[str, str]] = []
    if not fig.axes:
        issues.append(("FAIL", "图中没有坐标轴"))
        return issues
    for index, ax in enumerate(fig.axes, start=1):
        if not ax.get_xlabel().strip():
            issues.append(("WARN", f"第{index}个坐标轴缺少x轴名称"))
        if not ax.get_ylabel().strip():
            issues.append(("WARN", f"第{index}个坐标轴缺少y轴名称"))
        if not ax.get_title().strip():
            issues.append(("WARN", f"第{index}个坐标轴缺少图题"))
    return issues


def print_layout_report(issues: list[tuple[str, str]]) -> str:
    for level, message in issues:
        print(f"[{level}] {message}")
    verdict = "FAIL" if any(level == "FAIL" for level, _ in issues) else "PASS"
    print(f"[版面检查] {verdict}")
    return verdict


def export_figure(
    fig: plt.Figure,
    basename: str,
    formats: tuple[str, ...],
    dpi: int,
    size_inches: tuple[float, float],
    grayscale_preview: bool,
    pad_inches: float,
) -> list[str]:
    """用matplotlib导出多格式图，并生成灰度检查图。"""
    base = Path(basename)
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.set_size_inches(*size_inches)
    exported: list[str] = []
    for suffix in formats:
        output_path = base.with_suffix(f".{suffix}")
        save_options = {"bbox_inches": "tight", "pad_inches": pad_inches}
        if suffix.lower() in {"png", "tif", "tiff"}:
            save_options["dpi"] = dpi
        fig.savefig(output_path, **save_options)
        exported.append(str(output_path))

    if grayscale_preview:
        png_path = base.with_suffix(".png")
        grayscale_path = base.with_name(base.name + "_grayscale").with_suffix(".png")
        with Image.open(png_path) as image:
            source_dpi = image.info.get("dpi", (dpi, dpi))
            image.convert("L").save(grayscale_path, dpi=source_dpi)
        exported.append(str(grayscale_path))
    return exported


def check_figure(path: str, min_dpi: int = 300) -> tuple[list[tuple[str, str]], dict]:
    """检查文件存在性与位图DPI；PDF/SVG为矢量格式。"""
    figure_path = Path(path)
    issues: list[tuple[str, str]] = []
    info: dict = {"path": str(figure_path), "suffix": figure_path.suffix.lower()}
    if not figure_path.exists() or figure_path.stat().st_size == 0:
        issues.append(("FAIL", "图文件不存在或为空"))
        return issues, info
    if figure_path.suffix.lower() in {".png", ".tif", ".tiff"}:
        with Image.open(figure_path) as image:
            dpi_value = image.info.get("dpi", (0.0, 0.0))
            dpi_x = float(dpi_value[0]) if dpi_value else 0.0
            dpi_y = float(dpi_value[1]) if dpi_value else 0.0
            info.update({"pixels": image.size, "dpi": (dpi_x, dpi_y)})
            if min(dpi_x, dpi_y) + 1.0e-6 < min_dpi:
                issues.append(("FAIL", f"位图DPI低于{min_dpi}"))
    return issues, info


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="绘制问题1交叉验证论文图")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=SCRIPT_DIR / "cross_validation_data",
        help="包含figure_source_data的目录",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "cross_validation_figures",
    )
    parser.add_argument(
        "--reference-intervals",
        type=int,
        default=None,
        help="FVM基准空间区间数；默认从指标JSON读取",
    )
    return parser.parse_args()


def read_numeric_csv(path: Path) -> dict[str, np.ndarray]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"绘图源数据为空：{path}")
    result: dict[str, np.ndarray] = {}
    for key in rows[0]:
        values = [row[key] for row in rows]
        if key == "accepted":
            result[key] = np.asarray([v.lower() == "true" for v in values])
        else:
            result[key] = np.asarray(values, dtype=float)
    return result


def style_axes(ax: plt.Axes) -> None:
    ax.grid(axis="both", color="#D8D8D8", linewidth=0.55, alpha=0.7)
    ax.tick_params(direction="out", length=3.0, width=0.7)
    ax.margins(x=0.02)


def save_figure(
    fig: plt.Figure,
    output_dir: Path,
    name: str,
    manifest: list[dict],
    size: tuple[float, float] = (5.2, 3.55),
) -> None:
    fig.set_size_inches(*size)
    fig.canvas.draw()
    preview_dir = output_dir / "_qa_previews"
    preview_path = preview_dir / f"{name}_preview.png"
    render_preview(fig, str(preview_path), dpi=180)
    issues = audit_layout(fig)
    verdict = print_layout_report(issues)
    if verdict == "FAIL":
        raise RuntimeError(f"{name}版面自检失败，请修图后再导出")
    exported = export_figure(
        fig,
        basename=str(output_dir / name),
        formats=("pdf", "svg", "png", "tiff"),
        dpi=600,
        size_inches=size,
        grayscale_preview=True,
        pad_inches=0.06,
    )
    manifest.append(
        {
            "name": name,
            "layout_verdict": verdict,
            "layout_issues": issues,
            "preview": str(preview_path),
            "exported": exported,
        }
    )
    plt.close(fig)


def plot_fdm_profiles(
    data: dict[str, np.ndarray],
    output_dir: Path,
    manifest: list[dict],
    reference_intervals: int,
) -> None:
    radius = data["radius_mm"]
    configurations = [
        ("FDM 40", "FDM40", OKABE_ITO["orange"], "--", "o"),
        ("FDM 80", "FDM80", OKABE_ITO["sky"], "-.", "s"),
        ("FDM 160", "FDM160", OKABE_ITO["green"], ":", "^"),
        ("FDM 320", "FDM320", OKABE_ITO["purple"], (0, (5, 2)), "D"),
    ]
    for field, ylabel, title, name in [
        (
            "temperature_c",
            "温度 / °C",
            f"1800 s径向温度分布：FDM与FVM{reference_intervals}基准",
            f"fdm_temperature_profiles_vs_fvm{reference_intervals}",
        ),
        (
            "moisture_kg_kg",
            "含水率 / (kg/kg)",
            f"1800 s径向含水率分布：FDM与FVM{reference_intervals}基准",
            f"fdm_moisture_profiles_vs_fvm{reference_intervals}",
        ),
    ]:
        fig, ax = plt.subplots()
        for label, prefix, color, line_style, marker in configurations:
            ax.plot(
                radius,
                data[f"{prefix}_{field}"],
                color=color,
                linestyle=line_style,
                marker=marker,
                markevery=4,
                markerfacecolor="white",
                markeredgewidth=0.8,
                linewidth=1.0,
                label=label,
                zorder=2,
            )
        ax.plot(
            radius,
            data[f"FVM{reference_intervals}_{field}"],
            color=OKABE_ITO["black"],
            linewidth=2.1,
            label=f"FVM {reference_intervals}（基准）",
            zorder=4,
        )
        ax.set_xlabel("半径 / mm")
        ax.set_ylabel(ylabel)
        ax.set_title(title, pad=7)
        ax.set_xticks(np.arange(0, 21, 4))
        ax.legend(ncol=2, loc="best", handlelength=2.5, columnspacing=1.2)
        style_axes(ax)
        save_figure(fig, output_dir, name, manifest)


def plot_fdm_convergence(
    data: dict[str, np.ndarray],
    output_dir: Path,
    manifest: list[dict],
    reference_intervals: int,
) -> None:
    intervals = data["intervals"]
    for field, ylabel, title, name in [
        (
            "temperature_c",
            "绝对误差 / °C",
            f"FDM温度结果与FVM{reference_intervals}基准的差异",
            f"fdm_temperature_error_vs_fvm{reference_intervals}",
        ),
        (
            "moisture_kg_kg",
            "绝对误差 / (kg/kg)",
            f"FDM含水率结果与FVM{reference_intervals}基准的差异",
            f"fdm_moisture_error_vs_fvm{reference_intervals}",
        ),
    ]:
        fig, ax = plt.subplots()
        series = [
            (
                f"full_max_abs_{field}",
                "全时空最大误差",
                OKABE_ITO["red"],
                "o",
                "-",
            ),
            (
                f"report_max_abs_{field}",
                "指定点最大误差",
                OKABE_ITO["blue"],
                "s",
                "--",
            ),
            (
                f"final_profile_max_abs_{field}",
                "1800 s剖面最大误差",
                OKABE_ITO["green"],
                "^",
                ":",
            ),
        ]
        for key, label, color, marker, line_style in series:
            ax.plot(
                intervals,
                data[key],
                color=color,
                marker=marker,
                markerfacecolor="white",
                markeredgewidth=0.9,
                linestyle=line_style,
                linewidth=1.4,
                label=label,
            )
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xticks(intervals, [str(int(n)) for n in intervals])
        ax.set_xlabel("径向区间数 N")
        ax.set_ylabel(ylabel)
        ax.set_title(title, pad=7)
        ax.legend(loc="best")
        style_axes(ax)
        save_figure(fig, output_dir, name, manifest)


def plot_adaptive_profiles(
    data: dict[str, np.ndarray],
    output_dir: Path,
    manifest: list[dict],
    reference_intervals: int,
) -> None:
    radius = data["radius_mm"]
    for field, ylabel, title, name in [
        (
            "temperature_c",
            "温度 / °C",
            "1800 s温度分布：固定步与自适应步对照",
            f"adaptive_temperature_profile_vs_fixed{reference_intervals}",
        ),
        (
            "moisture_kg_kg",
            "含水率 / (kg/kg)",
            "1800 s含水率分布：固定步与自适应步对照",
            f"adaptive_moisture_profile_vs_fixed{reference_intervals}",
        ),
    ]:
        fig, ax = plt.subplots()
        ax.plot(
            radius,
            data[f"fixed_{field}"],
            color=OKABE_ITO["black"],
            linewidth=2.0,
            label="固定步长 1 s",
            zorder=3,
        )
        ax.plot(
            radius,
            data[f"adaptive_{field}"],
            color=OKABE_ITO["orange"],
            linestyle="--",
            marker="o",
            markevery=3,
            markerfacecolor="white",
            markeredgewidth=0.8,
            linewidth=1.25,
            label="自适应步长",
            zorder=4,
        )
        ax.set_xlabel("半径 / mm")
        ax.set_ylabel(ylabel)
        ax.set_title(title, pad=7)
        ax.set_xticks(np.arange(0, 21, 4))
        ax.legend(loc="best")
        style_axes(ax)
        save_figure(fig, output_dir, name, manifest)


def plot_adaptive_errors(
    data: dict[str, np.ndarray], output_dir: Path, manifest: list[dict]
) -> None:
    time = data["time_s"]
    for key, ylabel, title, name, color in [
        (
            "temperature_max_abs_c",
            "最大绝对误差 / °C",
            "自适应步与固定1 s步温度差异的时间演化",
            "adaptive_temperature_error_vs_time",
            OKABE_ITO["red"],
        ),
        (
            "moisture_max_abs_kg_kg",
            "最大绝对误差 / (kg/kg)",
            "自适应步与固定1 s步含水率差异的时间演化",
            "adaptive_moisture_error_vs_time",
            OKABE_ITO["blue"],
        ),
    ]:
        fig, ax = plt.subplots()
        ax.plot(time, data[key], color=color, linewidth=1.35)
        ax.fill_between(time, 0.0, data[key], color=color, alpha=0.12)
        maximum = float(np.max(data[key]))
        maximum_time = float(time[int(np.argmax(data[key]))])
        ax.scatter(
            [maximum_time], [maximum], color=color, edgecolor="white", s=30, zorder=4
        )
        ax.annotate(
            f"最大值 {maximum:.3g}",
            xy=(maximum_time, maximum),
            xytext=(45, -25) if maximum_time < 300 else (-58, -22),
            textcoords="offset points",
            arrowprops={"arrowstyle": "-", "color": OKABE_ITO["gray"], "lw": 0.7},
            fontsize=8,
        )
        ax.set_xlim(0, 1800)
        ax.set_ylim(bottom=0)
        ax.set_xticks(np.arange(0, 1801, 300))
        ax.set_xlabel("时间 / s")
        ax.set_ylabel(ylabel)
        ax.set_title(title, pad=7)
        style_axes(ax)
        save_figure(fig, output_dir, name, manifest)


def plot_adaptive_step_history(
    data: dict[str, np.ndarray], output_dir: Path, manifest: list[dict]
) -> None:
    accepted = data["accepted"].astype(bool)
    rejected = ~accepted
    fig, ax = plt.subplots()
    ax.plot(
        data["start_time_s"][accepted],
        data["candidate_step_s"][accepted],
        color=OKABE_ITO["blue"],
        linewidth=1.05,
        marker="o",
        markevery=max(1, int(np.sum(accepted) / 35)),
        markerfacecolor="white",
        markeredgewidth=0.7,
        label="已接受步长",
    )
    ax.scatter(
        data["start_time_s"][rejected],
        data["candidate_step_s"][rejected],
        color=OKABE_ITO["red"],
        marker="x",
        s=34,
        linewidths=1.3,
        label="被拒绝候选步长",
        zorder=5,
    )
    ax.set_yscale("log")
    ax.set_xlim(0, 1800)
    ax.set_xticks(np.arange(0, 1801, 300))
    ax.set_xlabel("候选步起始时间 / s")
    ax.set_ylabel("候选步长 / s（对数坐标）")
    ax.set_title("自适应后向欧拉的时间步长历史", pad=7)
    ax.legend(loc="best")
    style_axes(ax)
    save_figure(fig, output_dir, "adaptive_step_history", manifest)


def main() -> int:
    args = parse_args()
    if _PLOTTING_IMPORT_ERROR is not None:
        raise SystemExit(
            "缺少绘图依赖。请先在当前Python环境中执行 "
            "`python -m pip install -r requirements.txt`。"
            f"\n原始导入错误：{_PLOTTING_IMPORT_ERROR}"
        )
    data_dir = args.data_dir.resolve()
    source_dir = data_dir / "figure_source_data"
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_info = setup_style(
        journal="general", lang="zh", use_sciplots=False, constrained_layout=True
    )
    mpl.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.titleweight": "semibold",
        }
    )

    metrics = json.loads(
        (data_dir / "cross_validation_metrics.json").read_text(encoding="utf-8")
    )
    reference_intervals = args.reference_intervals
    if reference_intervals is None:
        reference_intervals = int(metrics["adaptive_summary"]["intervals"])

    fdm_profiles = read_numeric_csv(source_dir / "fdm_profiles_1800s.csv")
    fdm_convergence = read_numeric_csv(source_dir / "fdm_convergence.csv")
    adaptive_profiles = read_numeric_csv(
        source_dir / "adaptive_profiles_1800s.csv"
    )
    adaptive_errors = read_numeric_csv(source_dir / "adaptive_error_time.csv")
    adaptive_history = read_numeric_csv(source_dir / "adaptive_step_history.csv")

    manifest: list[dict] = []
    plot_fdm_profiles(fdm_profiles, output_dir, manifest, reference_intervals)
    plot_fdm_convergence(fdm_convergence, output_dir, manifest, reference_intervals)
    plot_adaptive_profiles(adaptive_profiles, output_dir, manifest, reference_intervals)
    plot_adaptive_errors(adaptive_errors, output_dir, manifest)
    plot_adaptive_step_history(adaptive_history, output_dir, manifest)

    compliance = []
    for figure in manifest:
        for path in figure["exported"]:
            issues, info = check_figure(path, min_dpi=300)
            compliance.append(
                {
                    "path": path,
                    "issues": issues,
                    "info": info,
                    "has_failure": any(level == "FAIL" for level, _ in issues),
                }
            )
    failures = [item for item in compliance if item["has_failure"]]
    if failures:
        raise RuntimeError(f"{len(failures)}个图文件未通过格式/DPI/字体审计")

    (output_dir / "figure_manifest.json").write_text(
        json.dumps(
            {
                "style": setup_info,
                "figures": manifest,
                "compliance_audit": compliance,
                "compliance_failures": len(failures),
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )
    print(f"共生成{len(manifest)}张图，目录：{output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
