#!/usr/bin/env python3
"""问题1对照模型二：有限体积空间离散 + 自适应后向欧拉。

自适应策略使用步长加倍法进行局部误差估计：
同一候选时间区间分别计算一个整步和两个半步，利用两者差异构造
归一化误差；误差达标则接受两个半步的结果，否则缩短候选步长。

脚本同时计算固定 1 s 步长的有限体积主模型，输出：
1. 自适应模型的温度、含水率Excel结果；
2. 与固定步长主模型的误差摘要；
3. 自适应步长历史和两种模型的论文用对照图。

本脚本需要与 ``question1_fvm_backward_euler.py`` 放在同一目录。

示例
----
python question1_fvm_adaptive_time.py --input 附件1.xlsx --output-dir adaptive_check

依赖：numpy、openpyxl、matplotlib，以及主模型脚本。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import warnings
from dataclasses import asdict, dataclass, replace
from pathlib import Path

try:
    import matplotlib as mpl

    mpl.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
except (ImportError, AttributeError):  # 数值求解本身不依赖matplotlib
    mpl = None
    plt = None
    font_manager = None
import numpy as np

import question1_fvm_backward_euler as fvm


SCRIPT_DIR = Path(__file__).resolve().parent


@dataclass
class StepDiagnostics:
    temperature_relative_residual: float
    moisture_relative_residual: float
    heat_balance_relative_residual: float
    moisture_balance_relative_residual: float
    picard_iterations: int


@dataclass
class AdaptiveStatistics:
    accepted_steps: int = 0
    rejected_steps: int = 0
    attempted_steps: int = 0
    minimum_accepted_macro_step_s: float = math.inf
    maximum_accepted_macro_step_s: float = 0.0
    mean_accepted_macro_step_s: float = 0.0
    max_normalized_error: float = 0.0
    max_temperature_linear_relative_residual: float = 0.0
    max_moisture_nonlinear_relative_residual: float = 0.0
    max_heat_balance_relative_residual: float = 0.0
    max_moisture_balance_relative_residual: float = 0.0
    picard_iterations_max: int = 0
    picard_iterations_mean: float = 0.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="问题1有限体积自适应时间步对照模型"
    )
    parser.add_argument(
        "--input", type=Path, default=SCRIPT_DIR / "附件1.xlsx",
        help="附件1.xlsx路径；默认读取脚本同目录文件",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=SCRIPT_DIR / "q1_adaptive_output",
        help="输出目录；默认为脚本同目录下的q1_adaptive_output",
    )
    parser.add_argument("--intervals", type=int, default=80)
    parser.add_argument("--fixed-dt", type=float, default=1.0)
    parser.add_argument("--initial-dt", type=float, default=1.0)
    parser.add_argument("--min-dt", type=float, default=0.0625)
    parser.add_argument("--max-dt", type=float, default=12.0)
    parser.add_argument("--relative-tolerance", type=float, default=2.0e-5)
    parser.add_argument(
        "--temperature-absolute-tolerance", type=float, default=1.0e-4
    )
    parser.add_argument(
        "--moisture-absolute-tolerance", type=float, default=2.0e-5
    )
    parser.add_argument("--safety", type=float, default=0.9)
    parser.add_argument("--no-plots", action="store_true")
    return parser.parse_args()


class VariableStepFvmSolver:
    """在固定空间网格上执行单个可变步长后向欧拉步。"""

    def __init__(
        self,
        boundary: fvm.BoundaryData,
        params: fvm.ModelParameters,
    ) -> None:
        self.boundary = boundary
        self.params = params
        self.geometry = fvm.build_geometry(params.radius_m, params.intervals)
        self._temperature_cache: dict[
            float,
            tuple[
                tuple[np.ndarray, np.ndarray, np.ndarray],
                np.ndarray,
                np.ndarray,
                np.ndarray,
                np.ndarray,
            ],
        ] = {}

    def _temperature_objects(
        self, step_size_s: float
    ) -> tuple[
        tuple[np.ndarray, np.ndarray, np.ndarray],
        np.ndarray,
        np.ndarray,
        np.ndarray,
        np.ndarray,
    ]:
        key = round(float(step_size_s), 12)
        if key not in self._temperature_cache:
            step_params = replace(self.params, time_step_s=step_size_s)
            lower, diagonal, upper, capacity = fvm.temperature_matrix(
                self.geometry, step_params
            )
            factors = fvm.factorize_tridiagonal(lower, diagonal, upper)
            self._temperature_cache[key] = (
                factors,
                lower,
                diagonal,
                upper,
                capacity,
            )
        return self._temperature_cache[key]

    def step(
        self,
        time_s: float,
        step_size_s: float,
        temperature_old: np.ndarray,
        moisture_old: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, StepDiagnostics]:
        next_time = time_s + step_size_s
        step_params = replace(self.params, time_step_s=step_size_s)
        factors, lower_t, diagonal_t, upper_t, capacity_t = (
            self._temperature_objects(step_size_s)
        )
        rhs_t = capacity_t * temperature_old
        rhs_t[-1] += (
            step_params.heat_transfer_w_m2_k
            * self.geometry.surface_area_m
            * float(self.boundary.temperature(next_time))
        )
        temperature_new = fvm.solve_tridiagonal_factored(factors, rhs_t)
        residual_t = (
            fvm.tridiagonal_matvec(
                lower_t, diagonal_t, upper_t, temperature_new
            )
            - rhs_t
        )
        relative_residual_t = fvm.relative_residual(residual_t, rhs_t)
        heat_change = float(
            np.sum(
                step_params.density_kg_m3
                * step_params.heat_capacity_j_kg_k
                * self.geometry.cell_volumes_m2
                * (temperature_new - temperature_old)
            )
        )
        heat_boundary = float(
            step_size_s
            * step_params.heat_transfer_w_m2_k
            * self.geometry.surface_area_m
            * (
                float(self.boundary.temperature(next_time))
                - temperature_new[-1]
            )
        )
        heat_balance_residual = abs(heat_change - heat_boundary) / max(
            abs(heat_change), abs(heat_boundary), 1.0e-30
        )

        guess = moisture_old.copy()
        converged = False
        moisture_new = guess
        relative_residual_c = math.inf
        iteration_count = 0
        for iteration in range(1, step_params.picard_max_iterations + 1):
            lower_c, diagonal_c, upper_c, capacity_c = fvm.moisture_matrix(
                self.geometry, step_params, guess
            )
            rhs_c = capacity_c * moisture_old
            rhs_c[-1] += (
                step_params.mass_transfer_m_s
                * self.geometry.surface_area_m
                * float(self.boundary.moisture(next_time))
            )
            candidate = fvm.solve_tridiagonal(
                lower_c, diagonal_c, upper_c, rhs_c
            )
            if np.any(~np.isfinite(candidate)) or np.any(candidate <= 0.0):
                raise FloatingPointError(
                    f"t={next_time:g}s、dt={step_size_s:g}s时产生非法含水率"
                )
            increment = float(
                np.max(np.abs(candidate - guess))
                / max(1.0, float(np.max(np.abs(candidate))))
            )
            lower_r, diagonal_r, upper_r, _ = fvm.moisture_matrix(
                self.geometry, step_params, candidate
            )
            nonlinear_residual = (
                fvm.tridiagonal_matvec(
                    lower_r, diagonal_r, upper_r, candidate
                )
                - rhs_c
            )
            relative_residual_c = fvm.relative_residual(
                nonlinear_residual, rhs_c
            )
            if (
                increment <= step_params.picard_tolerance
                and relative_residual_c
                <= step_params.picard_residual_tolerance
            ):
                moisture_new = candidate
                converged = True
                iteration_count = iteration
                break
            guess = (
                step_params.picard_relaxation * candidate
                + (1.0 - step_params.picard_relaxation) * guess
            )
        if not converged:
            raise RuntimeError(
                f"t={next_time:g}s、dt={step_size_s:g}s时Picard迭代未收敛"
            )
        moisture_change = float(
            np.sum(
                self.geometry.cell_volumes_m2
                * (moisture_new - moisture_old)
            )
        )
        moisture_boundary = float(
            step_size_s
            * step_params.mass_transfer_m_s
            * self.geometry.surface_area_m
            * (
                float(self.boundary.moisture(next_time))
                - moisture_new[-1]
            )
        )
        moisture_balance_residual = abs(
            moisture_change - moisture_boundary
        ) / max(abs(moisture_change), abs(moisture_boundary), 1.0e-30)
        return (
            temperature_new,
            moisture_new,
            StepDiagnostics(
                temperature_relative_residual=relative_residual_t,
                moisture_relative_residual=relative_residual_c,
                heat_balance_relative_residual=heat_balance_residual,
                moisture_balance_relative_residual=moisture_balance_residual,
                picard_iterations=iteration_count,
            ),
        )


def _normalized_step_error(
    full_temperature: np.ndarray,
    full_moisture: np.ndarray,
    half_temperature: np.ndarray,
    half_moisture: np.ndarray,
    relative_tolerance: float,
    temperature_absolute_tolerance: float,
    moisture_absolute_tolerance: float,
) -> tuple[float, float, float]:
    scale_temperature = temperature_absolute_tolerance + relative_tolerance * np.maximum(
        np.abs(full_temperature), np.abs(half_temperature)
    )
    scale_moisture = moisture_absolute_tolerance + relative_tolerance * np.maximum(
        np.abs(full_moisture), np.abs(half_moisture)
    )
    error_temperature = float(
        np.max(np.abs(half_temperature - full_temperature) / scale_temperature)
    )
    error_moisture = float(
        np.max(np.abs(half_moisture - full_moisture) / scale_moisture)
    )
    return max(error_temperature, error_moisture), error_temperature, error_moisture


def _next_landmark_after(time_s: float, landmarks: np.ndarray) -> float:
    index = int(np.searchsorted(landmarks, time_s + 1.0e-11, side="right"))
    if index >= len(landmarks):
        return math.inf
    return float(landmarks[index])


def solve_adaptive(
    boundary: fvm.BoundaryData,
    params: fvm.ModelParameters,
    initial_step_s: float,
    minimum_step_s: float,
    maximum_step_s: float,
    relative_tolerance: float,
    temperature_absolute_tolerance: float,
    moisture_absolute_tolerance: float,
    safety: float,
) -> tuple[fvm.Solution, AdaptiveStatistics, list[dict]]:
    if not (0.0 < minimum_step_s <= initial_step_s <= maximum_step_s):
        raise ValueError("必须满足0 < min_dt <= initial_dt <= max_dt")
    if not (0.0 < safety < 1.0):
        raise ValueError("安全系数必须位于0和1之间")
    if relative_tolerance <= 0.0:
        raise ValueError("相对容差必须为正")

    solver = VariableStepFvmSolver(boundary, params)
    boundary_landmarks = boundary.time_s[
        (boundary.time_s > 0.0) & (boundary.time_s <= params.end_time_s)
    ]
    landmarks = np.unique(
        np.concatenate(
            [boundary_landmarks, fvm.REPORT_TIMES_S, [params.end_time_s]]
        )
    )
    landmarks = landmarks[(landmarks > 0.0) & (landmarks <= params.end_time_s)]

    accepted_times = [0.0]
    accepted_temperature = [
        np.full(params.intervals + 1, params.initial_temperature_c, dtype=float)
    ]
    accepted_moisture = [
        np.full(params.intervals + 1, params.initial_moisture_kg_kg, dtype=float)
    ]
    history: list[dict] = []
    accepted_step_sizes: list[float] = []
    accepted_errors: list[float] = []
    accepted_picard_counts: list[int] = []
    statistics = AdaptiveStatistics()

    current_time = 0.0
    proposed_step = initial_step_s
    while current_time < params.end_time_s - 1.0e-12:
        next_landmark = _next_landmark_after(current_time, landmarks)
        step_size = min(
            proposed_step,
            params.end_time_s - current_time,
            next_landmark - current_time,
        )
        if step_size < minimum_step_s * (1.0 - 1.0e-10):
            if next_landmark - current_time <= minimum_step_s:
                step_size = next_landmark - current_time
            else:
                step_size = minimum_step_s
        if step_size <= 1.0e-12:
            current_time = min(next_landmark, params.end_time_s)
            continue

        temperature_old = accepted_temperature[-1]
        moisture_old = accepted_moisture[-1]
        full_t, full_c, full_diag = solver.step(
            current_time,
            step_size,
            temperature_old,
            moisture_old,
        )
        half_t_1, half_c_1, half_diag_1 = solver.step(
            current_time,
            0.5 * step_size,
            temperature_old,
            moisture_old,
        )
        half_t_2, half_c_2, half_diag_2 = solver.step(
            current_time + 0.5 * step_size,
            0.5 * step_size,
            half_t_1,
            half_c_1,
        )
        error, error_t, error_c = _normalized_step_error(
            full_t,
            full_c,
            half_t_2,
            half_c_2,
            relative_tolerance,
            temperature_absolute_tolerance,
            moisture_absolute_tolerance,
        )
        statistics.attempted_steps += 1
        accept = error <= 1.0
        history.append(
            {
                "start_time_s": current_time,
                "candidate_step_s": step_size,
                "normalized_error": error,
                "temperature_error_component": error_t,
                "moisture_error_component": error_c,
                "accepted": accept,
            }
        )

        if accept:
            current_time += step_size
            if abs(current_time - next_landmark) <= 1.0e-10:
                current_time = next_landmark
            accepted_times.append(current_time)
            accepted_temperature.append(half_t_2)
            accepted_moisture.append(half_c_2)
            accepted_step_sizes.append(step_size)
            accepted_errors.append(error)
            accepted_picard_counts.extend(
                [half_diag_1.picard_iterations, half_diag_2.picard_iterations]
            )
            statistics.accepted_steps += 1
            statistics.max_temperature_linear_relative_residual = max(
                statistics.max_temperature_linear_relative_residual,
                half_diag_1.temperature_relative_residual,
                half_diag_2.temperature_relative_residual,
            )
            statistics.max_moisture_nonlinear_relative_residual = max(
                statistics.max_moisture_nonlinear_relative_residual,
                half_diag_1.moisture_relative_residual,
                half_diag_2.moisture_relative_residual,
            )
            statistics.max_heat_balance_relative_residual = max(
                statistics.max_heat_balance_relative_residual,
                half_diag_1.heat_balance_relative_residual,
                half_diag_2.heat_balance_relative_residual,
            )
            statistics.max_moisture_balance_relative_residual = max(
                statistics.max_moisture_balance_relative_residual,
                half_diag_1.moisture_balance_relative_residual,
                half_diag_2.moisture_balance_relative_residual,
            )
            if error == 0.0:
                growth = 2.0
            else:
                growth = safety * error ** (-0.5)
            proposed_step = min(
                maximum_step_s,
                max(minimum_step_s, step_size * min(2.0, max(0.5, growth))),
            )
        else:
            statistics.rejected_steps += 1
            if step_size <= minimum_step_s * (1.0 + 1.0e-10):
                raise RuntimeError(
                    "自适应误差在最小时间步处仍不满足容差，请减小--min-dt"
                )
            shrink = safety * error ** (-0.5)
            proposed_step = max(
                minimum_step_s,
                step_size * min(0.8, max(0.1, shrink)),
            )

    statistics.minimum_accepted_macro_step_s = min(accepted_step_sizes)
    statistics.maximum_accepted_macro_step_s = max(accepted_step_sizes)
    statistics.mean_accepted_macro_step_s = float(np.mean(accepted_step_sizes))
    statistics.max_normalized_error = max(accepted_errors)
    statistics.picard_iterations_max = max(accepted_picard_counts)
    statistics.picard_iterations_mean = float(np.mean(accepted_picard_counts))

    solution = fvm.Solution(
        times_s=np.asarray(accepted_times),
        radius_nodes_m=solver.geometry.radius_nodes_m,
        temperature_c=np.asarray(accepted_temperature),
        moisture_kg_kg=np.asarray(accepted_moisture),
        diagnostics={
            **asdict(statistics),
            "intervals": params.intervals,
            "nodes": params.intervals + 1,
            "dr_m": solver.geometry.dr_m,
            "temperature_min_c": float(np.min(accepted_temperature)),
            "temperature_max_c": float(np.max(accepted_temperature)),
            "moisture_min_kg_kg": float(np.min(accepted_moisture)),
            "moisture_max_kg_kg": float(np.max(accepted_moisture)),
            "temperature_radial_order_violations": int(
                np.sum(np.diff(np.asarray(accepted_temperature), axis=1) < -1.0e-10)
            ),
            "moisture_radial_order_violations": int(
                np.sum(np.diff(np.asarray(accepted_moisture), axis=1) > 1.0e-10)
            ),
        },
    )
    return solution, statistics, history


def _comparison_details(
    fixed: fvm.Solution,
    adaptive: fvm.Solution,
) -> tuple[dict, np.ndarray, np.ndarray, np.ndarray]:
    comparison = fvm.compare_solutions(fixed, adaptive)
    times = np.arange(0.0, fixed.times_s[-1] + 0.5, 1.0)
    fixed_t = fvm.sample_field(
        fixed, fixed.temperature_c, times, fvm.OUTPUT_RADII_M
    )
    adaptive_t = fvm.sample_field(
        adaptive, adaptive.temperature_c, times, fvm.OUTPUT_RADII_M
    )
    fixed_c = fvm.sample_field(
        fixed, fixed.moisture_kg_kg, times, fvm.OUTPUT_RADII_M
    )
    adaptive_c = fvm.sample_field(
        adaptive, adaptive.moisture_kg_kg, times, fvm.OUTPUT_RADII_M
    )
    temperature_error_time = np.max(np.abs(fixed_t - adaptive_t), axis=1)
    moisture_error_time = np.max(np.abs(fixed_c - adaptive_c), axis=1)
    return comparison, times, temperature_error_time, moisture_error_time


def _write_history(path: Path, history: list[dict]) -> None:
    if not history:
        raise ValueError("自适应历史不能为空")
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)


def _configure_plotting() -> None:
    preferred = (
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Heiti SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
    )
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    selected = next((name for name in preferred if name in available), None)
    if selected is None:
        warnings.warn(
            "未检测到中文字体；数值计算不受影响，但图中中文可能缺字。"
            "建议安装 Noto Sans CJK SC。",
            RuntimeWarning,
            stacklevel=2,
        )
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [selected, "DejaVu Sans"]
            if selected
            else ["DejaVu Sans"],
            "axes.unicode_minus": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
        }
    )


def _save_single_panel(fig: plt.Figure, output_base: Path) -> None:
    fig.savefig(output_base.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def _plot_step_history(
    output_dir: Path,
    adaptive: fvm.Solution,
) -> None:
    steps = np.diff(adaptive.times_s)
    fig, ax = plt.subplots(figsize=(89 / 25.4, 66 / 25.4), constrained_layout=True)
    ax.step(
        adaptive.times_s[1:],
        steps,
        where="post",
        color="#7C3AED",
        linewidth=1.3,
    )
    ax.set_xlabel("时间 / s")
    ax.set_ylabel("接受的自适应宏步长 / s")
    ax.grid(True, linewidth=0.45, alpha=0.28)
    _save_single_panel(fig, output_dir / "adaptive_step_history")


def _plot_error_history(
    output_dir: Path,
    times: np.ndarray,
    errors: np.ndarray,
    ylabel: str,
    filename: str,
    color: str,
) -> None:
    fig, ax = plt.subplots(figsize=(89 / 25.4, 66 / 25.4), constrained_layout=True)
    ax.plot(times, errors, color=color, linewidth=1.3)
    ax.set_xlabel("时间 / s")
    ax.set_ylabel(ylabel)
    ax.grid(True, linewidth=0.45, alpha=0.28)
    _save_single_panel(fig, output_dir / filename)


def _plot_final_profile(
    output_dir: Path,
    fixed: fvm.Solution,
    adaptive: fvm.Solution,
    field_name: str,
    ylabel: str,
    filename: str,
) -> None:
    radii = np.linspace(0.0, fixed.radius_nodes_m[-1], 201)
    if field_name == "temperature":
        fixed_field = fixed.temperature_c
        adaptive_field = adaptive.temperature_c
        color = "#C2410C"
    else:
        fixed_field = fixed.moisture_kg_kg
        adaptive_field = adaptive.moisture_kg_kg
        color = "#0369A1"
    fixed_profile = fvm.sample_field(
        fixed, fixed_field, [fixed.times_s[-1]], radii
    )[0]
    adaptive_profile = fvm.sample_field(
        adaptive, adaptive_field, [adaptive.times_s[-1]], radii
    )[0]
    fig, ax = plt.subplots(figsize=(89 / 25.4, 66 / 25.4), constrained_layout=True)
    ax.plot(
        radii * 100.0,
        fixed_profile,
        color="#111827",
        linewidth=2.0,
    )
    ax.plot(
        radii * 100.0,
        adaptive_profile,
        color=color,
        linewidth=1.5,
        linestyle="--",
    )
    ax.set_xlabel("距圆柱中心的径向距离 / cm")
    ax.set_ylabel(ylabel)
    ax.grid(True, linewidth=0.45, alpha=0.28)
    ax.text(
        0.0,
        1.04,
        "固定1 s步长",
        transform=ax.transAxes,
        color="#111827",
        fontsize=7,
        va="bottom",
    )
    ax.text(
        0.55,
        1.04,
        "自适应时间步",
        transform=ax.transAxes,
        color=color,
        fontsize=7,
        va="bottom",
    )
    _save_single_panel(fig, output_dir / filename)


def main() -> int:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    params = fvm.ModelParameters(
        intervals=args.intervals,
        time_step_s=args.fixed_dt,
    )
    boundary = fvm.read_boundary_data(args.input, params.end_time_s)

    print("正在求解固定时间步有限体积主模型……")
    fixed_solution = fvm.solve_case(boundary, params)
    print("正在求解自适应时间步有限体积对照模型……")
    adaptive_solution, statistics, history = solve_adaptive(
        boundary=boundary,
        params=params,
        initial_step_s=args.initial_dt,
        minimum_step_s=args.min_dt,
        maximum_step_s=args.max_dt,
        relative_tolerance=args.relative_tolerance,
        temperature_absolute_tolerance=args.temperature_absolute_tolerance,
        moisture_absolute_tolerance=args.moisture_absolute_tolerance,
        safety=args.safety,
    )
    comparison, times, temperature_error, moisture_error = _comparison_details(
        fixed_solution, adaptive_solution
    )

    fvm.write_result_workbook(
        args.output_dir / "adaptive_result.xlsx", adaptive_solution
    )
    fvm.write_report_tables(
        args.output_dir / "adaptive_report_values.json", adaptive_solution
    )
    _write_history(args.output_dir / "adaptive_step_history.csv", history)

    summary = {
        "model": "finite_volume_adaptive_backward_euler_step_doubling",
        "input_file": args.input.name,
        "parameters": {
            "intervals": args.intervals,
            "nodes": args.intervals + 1,
            "fixed_reference_dt_s": args.fixed_dt,
            "initial_adaptive_macro_dt_s": args.initial_dt,
            "minimum_adaptive_macro_dt_s": args.min_dt,
            "maximum_adaptive_macro_dt_s": args.max_dt,
            "relative_tolerance": args.relative_tolerance,
            "temperature_absolute_tolerance_c": args.temperature_absolute_tolerance,
            "moisture_absolute_tolerance_kg_kg": args.moisture_absolute_tolerance,
            "safety": args.safety,
        },
        "adaptive_statistics": asdict(statistics),
        "fixed_vs_adaptive": comparison,
        "fixed_diagnostics": fixed_solution.diagnostics,
        "interpretation": (
            "若固定步长与自适应步长差异远小于变量变化幅度，且残差满足容差，"
            "则固定1 s步长可作为更简洁的主模型。"
        ),
    }
    (args.output_dir / "adaptive_vs_fixed_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if not args.no_plots:
        _configure_plotting()
        _plot_step_history(args.output_dir, adaptive_solution)
        _plot_error_history(
            args.output_dir,
            times,
            temperature_error,
            "温度最大绝对差 / °C",
            "adaptive_fixed_temperature_error",
            "#C2410C",
        )
        _plot_error_history(
            args.output_dir,
            times,
            moisture_error,
            "含水率最大绝对差 / (kg/kg)",
            "adaptive_fixed_moisture_error",
            "#0369A1",
        )
        _plot_final_profile(
            args.output_dir,
            fixed_solution,
            adaptive_solution,
            "temperature",
            "温度 / °C",
            "adaptive_fixed_temperature_profile_1800s",
        )
        _plot_final_profile(
            args.output_dir,
            fixed_solution,
            adaptive_solution,
            "moisture",
            "含水率 / (kg/kg)",
            "adaptive_fixed_moisture_profile_1800s",
        )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
