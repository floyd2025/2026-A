#!/usr/bin/env python3
"""问题1对照模型一：有限差分空间离散 + 固定步长后向欧拉。

用途
----
1. 用经典点值有限差分独立求解圆柱药材的温度场和水分场；
2. 在 40、80、160 等逐级加密网格上，与主模型有限体积解比较；
3. 输出有限差分结果、交叉验证误差、收敛阶和论文用图片。

本脚本需要与 ``question1_fvm_backward_euler.py`` 放在同一目录。

示例
----
python question1_fdm_fixed_step.py --input 附件1.xlsx --output-dir fdm_check

依赖：numpy、openpyxl、matplotlib，以及主模型脚本。
"""

from __future__ import annotations

import argparse
import json
import math
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path

try:
    import matplotlib as mpl

    mpl.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
except (ImportError, AttributeError):  # 数值求解本身不依赖matplotlib
    mpl = None
    plt = None
    font_manager = None
import numpy as np

import question1_fvm_backward_euler as fvm


SCRIPT_DIR = Path(__file__).resolve().parent


@dataclass
class FdmDiagnostics:
    intervals: int
    nodes: int
    dr_m: float
    dt_s: float
    max_temperature_relative_residual: float
    max_moisture_nonlinear_relative_residual: float
    picard_iterations_max: int
    picard_iterations_mean: float
    temperature_min_c: float
    temperature_max_c: float
    moisture_min_kg_kg: float
    moisture_max_kg_kg: float
    temperature_radial_order_violations: int
    moisture_radial_order_violations: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="问题1有限差分固定步长对照模型"
    )
    parser.add_argument(
        "--input", type=Path, default=SCRIPT_DIR / "附件1.xlsx",
        help="附件1.xlsx路径；默认读取脚本同目录文件",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=SCRIPT_DIR / "q1_fdm_output",
        help="输出目录；默认为脚本同目录下的q1_fdm_output",
    )
    parser.add_argument(
        "--grids",
        type=int,
        nargs="+",
        default=[40, 80, 160, 320],
        help="用于FDM-FVM交叉验证的径向区间数",
    )
    parser.add_argument(
        "--primary-intervals",
        type=int,
        default=80,
        help="写入Excel和剖面对照图的主区间数",
    )
    parser.add_argument("--dt", type=float, default=1.0, help="固定时间步长/s")
    parser.add_argument("--no-plots", action="store_true")
    return parser.parse_args()


def _prepare_last_row_elimination(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
    last_second_lower: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """将仅最后一行含第二下对角元的矩阵化为三对角矩阵。"""
    lower_t = lower.astype(float, copy=True)
    diagonal_t = diagonal.astype(float, copy=True)
    upper_t = upper.astype(float, copy=True)
    pivot = lower_t[-2]
    if abs(pivot) <= np.finfo(float).eps:
        raise np.linalg.LinAlgError("倒数第二行消元主元接近零")
    elimination_factor = last_second_lower / pivot
    lower_t[-1] -= elimination_factor * diagonal_t[-2]
    diagonal_t[-1] -= elimination_factor * upper_t[-2]
    return lower_t, diagonal_t, upper_t, elimination_factor


def _solve_with_second_lower_last_row(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
    last_second_lower: float,
    rhs: np.ndarray,
) -> np.ndarray:
    lower_t, diagonal_t, upper_t, factor = _prepare_last_row_elimination(
        lower, diagonal, upper, last_second_lower
    )
    rhs_t = rhs.astype(float, copy=True)
    rhs_t[-1] -= factor * rhs_t[-2]
    return fvm.solve_tridiagonal(lower_t, diagonal_t, upper_t, rhs_t)


def _banded_matvec(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
    last_second_lower: float,
    vector: np.ndarray,
) -> np.ndarray:
    result = fvm.tridiagonal_matvec(lower, diagonal, upper, vector)
    result[-1] += last_second_lower * vector[-3]
    return result


def _temperature_system(
    params: fvm.ModelParameters,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    n = params.intervals + 1
    dr = params.radius_m / params.intervals
    alpha = params.thermal_conductivity_w_m_k / (
        params.density_kg_m3 * params.heat_capacity_j_kg_k
    )
    factor = params.time_step_s * alpha
    lower = np.zeros(n)
    diagonal = np.ones(n)
    upper = np.zeros(n)

    diagonal[0] += 4.0 * factor / dr**2
    upper[0] = -4.0 * factor / dr**2
    for i in range(1, n - 1):
        radius = i * dr
        left_operator = 1.0 / dr**2 - 1.0 / (2.0 * radius * dr)
        right_operator = 1.0 / dr**2 + 1.0 / (2.0 * radius * dr)
        lower[i] = -factor * left_operator
        diagonal[i] = 1.0 + 2.0 * factor / dr**2
        upper[i] = -factor * right_operator

    conductivity = params.thermal_conductivity_w_m_k
    transfer = params.heat_transfer_w_m2_k
    last_second_lower = conductivity / (2.0 * dr)
    lower[-1] = -2.0 * conductivity / dr
    diagonal[-1] = 3.0 * conductivity / (2.0 * dr) + transfer
    return lower, diagonal, upper, last_second_lower


def _moisture_system(
    params: fvm.ModelParameters,
    guess: np.ndarray,
    old: np.ndarray,
    ambient: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, np.ndarray]:
    n = params.intervals + 1
    dr = params.radius_m / params.intervals
    dt = params.time_step_s
    diffusivity = fvm.moisture_diffusivity(guess)
    diffusivity_derivative = diffusivity * 0.89 / guess**2

    lower = np.zeros(n)
    diagonal = np.ones(n)
    upper = np.zeros(n)
    rhs = old.astype(float, copy=True)

    diagonal[0] += 4.0 * dt * diffusivity[0] / dr**2
    upper[0] = -4.0 * dt * diffusivity[0] / dr**2
    for i in range(1, n - 1):
        radius = i * dr
        left_operator = 1.0 / dr**2 - 1.0 / (2.0 * radius * dr)
        right_operator = 1.0 / dr**2 + 1.0 / (2.0 * radius * dr)
        lower[i] = -dt * diffusivity[i] * left_operator
        diagonal[i] = 1.0 + 2.0 * dt * diffusivity[i] / dr**2
        upper[i] = -dt * diffusivity[i] * right_operator

        gradient_guess = (guess[i + 1] - guess[i - 1]) / (2.0 * dr)
        rhs[i] += dt * diffusivity_derivative[i] * gradient_guess**2

    surface_d = diffusivity[-1]
    last_second_lower = surface_d / (2.0 * dr)
    lower[-1] = -2.0 * surface_d / dr
    diagonal[-1] = 3.0 * surface_d / (2.0 * dr) + params.mass_transfer_m_s
    rhs[-1] = params.mass_transfer_m_s * ambient
    return lower, diagonal, upper, last_second_lower, rhs


def _moisture_nonlinear_residual(
    params: fvm.ModelParameters,
    candidate: np.ndarray,
    old: np.ndarray,
    ambient: float,
) -> float:
    dr = params.radius_m / params.intervals
    dt = params.time_step_s
    diffusivity = fvm.moisture_diffusivity(candidate)
    diffusivity_derivative = diffusivity * 0.89 / candidate**2
    residual = np.zeros_like(candidate)

    residual[0] = (
        candidate[0]
        - old[0]
        - dt
        * diffusivity[0]
        * 4.0
        * (candidate[1] - candidate[0])
        / dr**2
    )
    for i in range(1, len(candidate) - 1):
        radius = i * dr
        first_derivative = (candidate[i + 1] - candidate[i - 1]) / (2.0 * dr)
        second_derivative = (
            candidate[i + 1] - 2.0 * candidate[i] + candidate[i - 1]
        ) / dr**2
        operator = diffusivity[i] * (
            second_derivative + first_derivative / radius
        ) + diffusivity_derivative[i] * first_derivative**2
        residual[i] = candidate[i] - old[i] - dt * operator

    surface_derivative = (
        3.0 * candidate[-1] - 4.0 * candidate[-2] + candidate[-3]
    ) / (2.0 * dr)
    residual[-1] = (
        -diffusivity[-1] * surface_derivative
        - params.mass_transfer_m_s * (candidate[-1] - ambient)
    )
    scale = max(float(np.max(np.abs(candidate))), float(np.max(np.abs(old))), 1.0)
    return float(np.max(np.abs(residual)) / scale)


def solve_fdm_case(
    boundary: fvm.BoundaryData,
    params: fvm.ModelParameters,
) -> fvm.Solution:
    steps_float = params.end_time_s / params.time_step_s
    steps = int(round(steps_float))
    if not math.isclose(steps_float, steps, rel_tol=0.0, abs_tol=1.0e-12):
        raise ValueError("end_time_s必须是time_step_s的整数倍")

    radius = np.linspace(0.0, params.radius_m, params.intervals + 1)
    times = np.linspace(0.0, params.end_time_s, steps + 1)
    temperature = np.empty((steps + 1, params.intervals + 1))
    moisture = np.empty_like(temperature)
    temperature[0] = params.initial_temperature_c
    moisture[0] = params.initial_moisture_kg_kg

    lower_t, diagonal_t, upper_t, second_t = _temperature_system(params)
    lower_tt, diagonal_tt, upper_tt, elimination_t = _prepare_last_row_elimination(
        lower_t, diagonal_t, upper_t, second_t
    )
    temperature_factors = fvm.factorize_tridiagonal(
        lower_tt, diagonal_tt, upper_tt
    )

    max_temperature_residual = 0.0
    max_moisture_residual = 0.0
    picard_counts: list[int] = []
    for step in range(steps):
        next_time = times[step + 1]
        rhs_t = temperature[step].copy()
        rhs_t[-1] = (
            params.heat_transfer_w_m2_k
            * float(boundary.temperature(next_time))
        )
        rhs_tt = rhs_t.copy()
        rhs_tt[-1] -= elimination_t * rhs_tt[-2]
        next_temperature = fvm.solve_tridiagonal_factored(
            temperature_factors, rhs_tt
        )
        residual_t = (
            _banded_matvec(
                lower_t,
                diagonal_t,
                upper_t,
                second_t,
                next_temperature,
            )
            - rhs_t
        )
        max_temperature_residual = max(
            max_temperature_residual,
            fvm.relative_residual(residual_t, rhs_t),
        )
        temperature[step + 1] = next_temperature

        old_moisture = moisture[step]
        guess = old_moisture.copy()
        ambient = float(boundary.moisture(next_time))
        converged = False
        for iteration in range(1, params.picard_max_iterations + 1):
            lower_c, diagonal_c, upper_c, second_c, rhs_c = _moisture_system(
                params, guess, old_moisture, ambient
            )
            candidate = _solve_with_second_lower_last_row(
                lower_c, diagonal_c, upper_c, second_c, rhs_c
            )
            if np.any(~np.isfinite(candidate)) or np.any(candidate <= 0.0):
                raise FloatingPointError(
                    f"t={next_time:g}s时有限差分Picard迭代产生非法含水率"
                )
            increment = float(
                np.max(np.abs(candidate - guess))
                / max(1.0, float(np.max(np.abs(candidate))))
            )
            nonlinear_residual = _moisture_nonlinear_residual(
                params, candidate, old_moisture, ambient
            )
            if (
                increment <= params.picard_tolerance
                and nonlinear_residual <= params.picard_residual_tolerance
            ):
                moisture[step + 1] = candidate
                max_moisture_residual = max(
                    max_moisture_residual, nonlinear_residual
                )
                picard_counts.append(iteration)
                converged = True
                break
            guess = (
                params.picard_relaxation * candidate
                + (1.0 - params.picard_relaxation) * guess
            )
        if not converged:
            raise RuntimeError(
                f"t={next_time:g}s时有限差分Picard迭代未在"
                f"{params.picard_max_iterations}次内收敛"
            )

    diagnostics = FdmDiagnostics(
        intervals=params.intervals,
        nodes=params.intervals + 1,
        dr_m=params.radius_m / params.intervals,
        dt_s=params.time_step_s,
        max_temperature_relative_residual=max_temperature_residual,
        max_moisture_nonlinear_relative_residual=max_moisture_residual,
        picard_iterations_max=max(picard_counts),
        picard_iterations_mean=float(np.mean(picard_counts)),
        temperature_min_c=float(np.min(temperature)),
        temperature_max_c=float(np.max(temperature)),
        moisture_min_kg_kg=float(np.min(moisture)),
        moisture_max_kg_kg=float(np.max(moisture)),
        temperature_radial_order_violations=int(
            np.sum(np.diff(temperature, axis=1) < -1.0e-10)
        ),
        moisture_radial_order_violations=int(
            np.sum(np.diff(moisture, axis=1) > 1.0e-10)
        ),
    )
    return fvm.Solution(
        times,
        radius,
        temperature,
        moisture,
        asdict(diagnostics),
    )


def _method_difference(
    fdm_solution: fvm.Solution,
    fvm_solution: fvm.Solution,
) -> dict:
    standard_comparison = fvm.compare_solutions(fvm_solution, fdm_solution)
    times = np.arange(0.0, fdm_solution.times_s[-1] + 0.5, 1.0)
    radii = fvm.OUTPUT_RADII_M
    fdm_t = fvm.sample_field(
        fdm_solution, fdm_solution.temperature_c, times, radii
    )
    fvm_t = fvm.sample_field(
        fvm_solution, fvm_solution.temperature_c, times, radii
    )
    fdm_c = fvm.sample_field(
        fdm_solution, fdm_solution.moisture_kg_kg, times, radii
    )
    fvm_c = fvm.sample_field(
        fvm_solution, fvm_solution.moisture_kg_kg, times, radii
    )
    return {
        **standard_comparison,
        "max_abs_temperature_c": float(np.max(np.abs(fdm_t - fvm_t))),
        "max_abs_moisture_kg_kg": float(np.max(np.abs(fdm_c - fvm_c))),
        "rms_temperature_c": float(np.sqrt(np.mean((fdm_t - fvm_t) ** 2))),
        "rms_moisture_kg_kg": float(np.sqrt(np.mean((fdm_c - fvm_c) ** 2))),
    }


def _empirical_orders(grid_results: dict[int, dict], key: str) -> list[dict]:
    ordered = sorted(grid_results)
    values: list[dict] = []
    for coarse, fine in zip(ordered[:-1], ordered[1:]):
        error_coarse = grid_results[coarse][key]
        error_fine = grid_results[fine][key]
        ratio = (1.0 / coarse) / (1.0 / fine)
        order = math.log(error_coarse / error_fine) / math.log(ratio)
        values.append(
            {
                "coarse_intervals": coarse,
                "fine_intervals": fine,
                "estimated_order": float(order),
            }
        )
    return values


def _configure_plotting() -> None:
    preferred = (
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Microsoft YaHei",
        "SimHei",
        "PingFang SC",
        "Heiti SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
    )
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    selected = next((name for name in preferred if name in available), None)
    if selected is None:
        warnings.warn(
            "未检测到中文字体；数值计算不受影响，但图中中文可能缺字。"
            "建议安装 Noto Sans CJK SC。",
            RuntimeWarning,
            stacklevel=2,
        )
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [selected, "DejaVu Sans"]
            if selected
            else ["DejaVu Sans"],
            "axes.unicode_minus": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
        }
    )


def _save_single_panel(fig: plt.Figure, output_base: Path) -> None:
    fig.savefig(output_base.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(output_base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def _plot_convergence(
    output_dir: Path,
    grid_results: dict[int, dict],
    key: str,
    ylabel: str,
    filename: str,
    color: str,
) -> None:
    grids = np.asarray(sorted(grid_results), dtype=float)
    dr_mm = 20.0 / grids
    errors = np.asarray([grid_results[int(n)][key] for n in grids])
    if not np.all(np.diff(dr_mm[::-1]) > 0.0):
        raise AssertionError("空间步长必须严格有序")
    fig, ax = plt.subplots(figsize=(89 / 25.4, 66 / 25.4), constrained_layout=True)
    ax.loglog(
        dr_mm,
        errors,
        marker="o",
        markersize=4.5,
        linewidth=1.6,
        color=color,
    )
    guide = errors[-1] * (dr_mm / dr_mm[-1]) ** 2
    ax.loglog(
        dr_mm,
        guide,
        linestyle="--",
        linewidth=1.0,
        color="#6B7280",
    )
    ax.set_xlabel("空间步长 Δr / mm")
    ax.set_ylabel(ylabel)
    ax.grid(True, which="both", linewidth=0.45, alpha=0.28)
    ax.text(
        0.0,
        1.04,
        "FDM与FVM最大绝对差",
        transform=ax.transAxes,
        color=color,
        fontsize=7,
        va="bottom",
    )
    ax.text(
        0.64,
        1.04,
        "二阶参考斜率",
        transform=ax.transAxes,
        color="#6B7280",
        fontsize=7,
        va="bottom",
    )
    _save_single_panel(fig, output_dir / filename)


def _plot_profile(
    output_dir: Path,
    fdm_solution: fvm.Solution,
    fvm_solution: fvm.Solution,
    field_name: str,
    ylabel: str,
    filename: str,
) -> None:
    if field_name == "temperature":
        fdm_field = fdm_solution.temperature_c
        fvm_field = fvm_solution.temperature_c
        color = "#C2410C"
    else:
        fdm_field = fdm_solution.moisture_kg_kg
        fvm_field = fvm_solution.moisture_kg_kg
        color = "#0369A1"
    radii = np.linspace(0.0, fdm_solution.radius_nodes_m[-1], 201)
    fdm_profile = fvm.sample_field(
        fdm_solution, fdm_field, [fdm_solution.times_s[-1]], radii
    )[0]
    fvm_profile = fvm.sample_field(
        fvm_solution, fvm_field, [fvm_solution.times_s[-1]], radii
    )[0]
    fig, ax = plt.subplots(figsize=(89 / 25.4, 66 / 25.4), constrained_layout=True)
    ax.plot(
        radii * 100.0,
        fvm_profile,
        color="#111827",
        linewidth=2.0,
    )
    ax.plot(
        radii * 100.0,
        fdm_profile,
        color=color,
        linewidth=1.5,
        linestyle="--",
    )
    ax.set_xlabel("距圆柱中心的径向距离 / cm")
    ax.set_ylabel(ylabel)
    ax.grid(True, linewidth=0.45, alpha=0.28)
    ax.text(
        0.0,
        1.04,
        "有限体积主模型",
        transform=ax.transAxes,
        color="#111827",
        fontsize=7,
        va="bottom",
    )
    ax.text(
        0.52,
        1.04,
        "有限差分对照模型",
        transform=ax.transAxes,
        color=color,
        fontsize=7,
        va="bottom",
    )
    _save_single_panel(fig, output_dir / filename)


def main() -> int:
    args = parse_args()
    grids = sorted(set(args.grids + [args.primary_intervals]))
    if any(value < 4 for value in grids):
        raise ValueError("所有径向区间数必须至少为4")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    base_params = fvm.ModelParameters(time_step_s=args.dt)
    boundary = fvm.read_boundary_data(args.input, base_params.end_time_s)
    fdm_solutions: dict[int, fvm.Solution] = {}
    fvm_solutions: dict[int, fvm.Solution] = {}
    grid_results: dict[int, dict] = {}

    for intervals in grids:
        params = fvm.ModelParameters(
            **{
                **asdict(base_params),
                "intervals": intervals,
                "time_step_s": args.dt,
            }
        )
        print(f"正在求解 N={intervals} 的有限差分模型……")
        fdm_solution = solve_fdm_case(boundary, params)
        print(f"正在求解 N={intervals} 的有限体积参照模型……")
        fvm_solution = fvm.solve_case(boundary, params)
        fdm_solutions[intervals] = fdm_solution
        fvm_solutions[intervals] = fvm_solution
        grid_results[intervals] = {
            "dr_m": params.radius_m / intervals,
            **_method_difference(fdm_solution, fvm_solution),
            "fdm_diagnostics": fdm_solution.diagnostics,
            "fvm_diagnostics": fvm_solution.diagnostics,
        }

    primary_fdm = fdm_solutions[args.primary_intervals]
    primary_fvm = fvm_solutions[args.primary_intervals]
    fvm.write_result_workbook(
        args.output_dir / "fdm_result_primary_grid.xlsx", primary_fdm
    )
    fvm.write_report_tables(
        args.output_dir / "fdm_report_values.json", primary_fdm
    )

    summary = {
        "model": "finite_difference_backward_euler_fixed_step",
        "input_file": args.input.name,
        "fixed_time_step_s": args.dt,
        "primary_intervals": args.primary_intervals,
        "grid_comparisons": {str(key): value for key, value in grid_results.items()},
        "estimated_order_temperature": _empirical_orders(
            grid_results, "max_abs_temperature_c"
        ),
        "estimated_order_moisture": _empirical_orders(
            grid_results, "max_abs_moisture_kg_kg"
        ),
        "interpretation": (
            "随着dr减小，FDM与FVM差异应趋于零；经验阶用于描述这种趋近速度。"
        ),
    }
    (args.output_dir / "fdm_fvm_cross_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if not args.no_plots:
        _configure_plotting()
        _plot_convergence(
            args.output_dir,
            grid_results,
            "max_abs_temperature_c",
            "温度最大绝对差 / °C",
            "fdm_fvm_temperature_convergence",
            "#C2410C",
        )
        _plot_convergence(
            args.output_dir,
            grid_results,
            "max_abs_moisture_kg_kg",
            "含水率最大绝对差 / (kg/kg)",
            "fdm_fvm_moisture_convergence",
            "#0369A1",
        )
        _plot_profile(
            args.output_dir,
            primary_fdm,
            primary_fvm,
            "temperature",
            "温度 / °C",
            "fdm_fvm_temperature_profile_1800s",
        )
        _plot_profile(
            args.output_dir,
            primary_fdm,
            primary_fvm,
            "moisture",
            "含水率 / (kg/kg)",
            "fdm_fvm_moisture_profile_1800s",
        )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
