#!/usr/bin/env python3
"""生成问题1两类交叉验证所需的统一数据集。

对照一：有限差分(FDM)，空间区间数40/80/160/320，固定dt=1 s；
        所有结果均与用户指定区间数的有限体积(FVM)固定dt=1 s模型比较。
对照二：相同空间网格的FVM自适应后向欧拉；
        与同一空间网格的FVM固定dt=1 s主模型比较。

输出包括：
1. 供Excel工作簿生成器读取的JSON；
2. 供SciPilot Figure工作流剖析和绘图的CSV；
3. 一份机器可读的指标汇总JSON。

本脚本需要与三个求解器脚本位于同一目录。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, replace
from pathlib import Path
from typing import Iterable

import numpy as np

import question1_fdm_fixed_step as fdm
import question1_fvm_adaptive_time as adaptive
import question1_fvm_backward_euler as fvm


SCRIPT_DIR = Path(__file__).resolve().parent


FDM_INTERVALS = (40, 80, 160, 320)
DEFAULT_REFERENCE_INTERVALS = 160
FIXED_DT_S = 1.0
COMMON_TIMES_S = np.arange(0.0, 1800.0 + 0.5, 1.0)
COMMON_RADII_M = fvm.OUTPUT_RADII_M


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成问题1交叉验证数据")
    parser.add_argument(
        "--input",
        type=Path,
        default=SCRIPT_DIR / "附件1.xlsx",
        help="附件1.xlsx路径；默认读取脚本同目录文件",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "cross_validation_data",
        help="JSON与CSV输出目录",
    )
    parser.add_argument(
        "--reference-intervals",
        type=int,
        default=DEFAULT_REFERENCE_INTERVALS,
        help="固定步长FVM基准的空间区间数",
    )
    parser.add_argument("--adaptive-initial-dt", type=float, default=1.0)
    parser.add_argument("--adaptive-min-dt", type=float, default=0.0625)
    parser.add_argument("--adaptive-max-dt", type=float, default=12.0)
    parser.add_argument("--adaptive-rtol", type=float, default=2.0e-5)
    parser.add_argument("--adaptive-temperature-atol", type=float, default=1.0e-4)
    parser.add_argument("--adaptive-moisture-atol", type=float, default=2.0e-5)
    parser.add_argument("--adaptive-safety", type=float, default=0.9)
    return parser.parse_args()


def _sample(solution: fvm.Solution) -> tuple[np.ndarray, np.ndarray]:
    return (
        fvm.sample_field(
            solution, solution.temperature_c, COMMON_TIMES_S, COMMON_RADII_M
        ),
        fvm.sample_field(
            solution, solution.moisture_kg_kg, COMMON_TIMES_S, COMMON_RADII_M
        ),
    )


def _sample_report(solution: fvm.Solution) -> tuple[np.ndarray, np.ndarray]:
    return (
        fvm.sample_field(
            solution, solution.temperature_c, fvm.REPORT_TIMES_S, fvm.REPORT_RADII_M
        ),
        fvm.sample_field(
            solution, solution.moisture_kg_kg, fvm.REPORT_TIMES_S, fvm.REPORT_RADII_M
        ),
    )


def _comparison_metrics(
    reference_t: np.ndarray,
    reference_c: np.ndarray,
    candidate_t: np.ndarray,
    candidate_c: np.ndarray,
    report_reference_t: np.ndarray,
    report_reference_c: np.ndarray,
    report_candidate_t: np.ndarray,
    report_candidate_c: np.ndarray,
) -> dict:
    delta_t = candidate_t - reference_t
    delta_c = candidate_c - reference_c
    report_delta_t = report_candidate_t - report_reference_t
    report_delta_c = report_candidate_c - report_reference_c
    final_delta_t = delta_t[-1]
    final_delta_c = delta_c[-1]
    reference_t_range = max(float(np.ptp(reference_t)), 1.0e-30)
    reference_c_range = max(float(np.ptp(reference_c)), 1.0e-30)
    return {
        "full_max_abs_temperature_c": float(np.max(np.abs(delta_t))),
        "full_rms_temperature_c": float(np.sqrt(np.mean(delta_t**2))),
        "full_max_abs_moisture_kg_kg": float(np.max(np.abs(delta_c))),
        "full_rms_moisture_kg_kg": float(np.sqrt(np.mean(delta_c**2))),
        "full_max_temperature_percent_of_range": float(
            100.0 * np.max(np.abs(delta_t)) / reference_t_range
        ),
        "full_max_moisture_percent_of_range": float(
            100.0 * np.max(np.abs(delta_c)) / reference_c_range
        ),
        "report_max_abs_temperature_c": float(np.max(np.abs(report_delta_t))),
        "report_rms_temperature_c": float(np.sqrt(np.mean(report_delta_t**2))),
        "report_max_abs_moisture_kg_kg": float(np.max(np.abs(report_delta_c))),
        "report_rms_moisture_kg_kg": float(np.sqrt(np.mean(report_delta_c**2))),
        "final_profile_max_abs_temperature_c": float(
            np.max(np.abs(final_delta_t))
        ),
        "final_profile_rms_temperature_c": float(
            np.sqrt(np.mean(final_delta_t**2))
        ),
        "final_profile_max_abs_moisture_kg_kg": float(
            np.max(np.abs(final_delta_c))
        ),
        "final_profile_rms_moisture_kg_kg": float(
            np.sqrt(np.mean(final_delta_c**2))
        ),
        "full_four_decimal_equal_temperature": bool(
            np.array_equal(np.round(candidate_t, 4), np.round(reference_t, 4))
        ),
        "full_four_decimal_equal_moisture": bool(
            np.array_equal(np.round(candidate_c, 4), np.round(reference_c, 4))
        ),
    }


def _write_csv(path: Path, header: list[str], rows: Iterable[Iterable]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        writer.writerows(rows)


def _model_table(
    times: np.ndarray,
    radii_m: np.ndarray,
    temperature: np.ndarray,
    moisture: np.ndarray,
) -> dict:
    return {
        "times_s": times.tolist(),
        "radii_mm": (1000.0 * radii_m).tolist(),
        "temperature_c": temperature.tolist(),
        "moisture_kg_kg": moisture.tolist(),
    }


def _report_rows(
    model_name: str,
    candidate_t: np.ndarray,
    candidate_c: np.ndarray,
    reference_t: np.ndarray,
    reference_c: np.ndarray,
) -> list[list]:
    rows: list[list] = []
    for i, time_s in enumerate(fvm.REPORT_TIMES_S):
        for j, radius_m in enumerate(fvm.REPORT_RADII_M):
            rows.append(
                [
                    model_name,
                    float(time_s),
                    float(1000.0 * radius_m),
                    float(candidate_t[i, j]),
                    float(reference_t[i, j]),
                    float(candidate_t[i, j] - reference_t[i, j]),
                    float(candidate_c[i, j]),
                    float(reference_c[i, j]),
                    float(candidate_c[i, j] - reference_c[i, j]),
                ]
            )
    return rows


def _finite_or_none(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def main() -> int:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    source_dir = output_dir / "figure_source_data"
    source_dir.mkdir(exist_ok=True)

    reference_intervals = args.reference_intervals
    if reference_intervals < 2:
        raise ValueError("--reference-intervals必须至少为2")
    reference_label = f"FVM{reference_intervals}"
    base_params = fvm.ModelParameters(
        intervals=reference_intervals, time_step_s=FIXED_DT_S
    )
    boundary = fvm.read_boundary_data(args.input.resolve(), base_params.end_time_s)

    print(f"[1/7] 求解{reference_label}固定1 s基准模型...", flush=True)
    reference = fvm.solve_case(boundary, base_params)
    reference_t, reference_c = _sample(reference)
    report_reference_t, report_reference_c = _sample_report(reference)

    fdm_tables: dict[str, dict] = {}
    fdm_summary: list[dict] = []
    fdm_report_rows: list[list] = []
    fdm_final_profiles: dict[int, tuple[np.ndarray, np.ndarray]] = {}

    for ordinal, intervals in enumerate(FDM_INTERVALS, start=2):
        print(
            f"[{ordinal}/7] 求解FDM{intervals}固定1 s并与{reference_label}比较...",
            flush=True,
        )
        params = replace(base_params, intervals=intervals)
        solution = fdm.solve_fdm_case(boundary, params)
        candidate_t, candidate_c = _sample(solution)
        report_candidate_t, report_candidate_c = _sample_report(solution)
        metrics = _comparison_metrics(
            reference_t,
            reference_c,
            candidate_t,
            candidate_c,
            report_reference_t,
            report_reference_c,
            report_candidate_t,
            report_candidate_c,
        )
        row = {
            "method": "FDM",
            "intervals": intervals,
            "nodes": intervals + 1,
            "dr_mm": 20.0 / intervals,
            "dt_s": FIXED_DT_S,
            **metrics,
            "temperature_linear_relative_residual": solution.diagnostics[
                "max_temperature_relative_residual"
            ],
            "moisture_nonlinear_relative_residual": solution.diagnostics[
                "max_moisture_nonlinear_relative_residual"
            ],
            "picard_iterations_max": solution.diagnostics[
                "picard_iterations_max"
            ],
            "picard_iterations_mean": solution.diagnostics[
                "picard_iterations_mean"
            ],
        }
        fdm_summary.append(row)
        fdm_tables[str(intervals)] = _model_table(
            COMMON_TIMES_S, COMMON_RADII_M, candidate_t, candidate_c
        )
        fdm_report_rows.extend(
            _report_rows(
                f"FDM{intervals}",
                report_candidate_t,
                report_candidate_c,
                report_reference_t,
                report_reference_c,
            )
        )
        fdm_final_profiles[intervals] = (candidate_t[-1], candidate_c[-1])

    print(f"[6/7] 求解{reference_label}自适应后向欧拉模型...", flush=True)
    adaptive_solution, adaptive_stats, adaptive_history = adaptive.solve_adaptive(
        boundary=boundary,
        params=base_params,
        initial_step_s=args.adaptive_initial_dt,
        minimum_step_s=args.adaptive_min_dt,
        maximum_step_s=args.adaptive_max_dt,
        relative_tolerance=args.adaptive_rtol,
        temperature_absolute_tolerance=args.adaptive_temperature_atol,
        moisture_absolute_tolerance=args.adaptive_moisture_atol,
        safety=args.adaptive_safety,
    )
    adaptive_t, adaptive_c = _sample(adaptive_solution)
    report_adaptive_t, report_adaptive_c = _sample_report(adaptive_solution)
    adaptive_metrics = _comparison_metrics(
        reference_t,
        reference_c,
        adaptive_t,
        adaptive_c,
        report_reference_t,
        report_reference_c,
        report_adaptive_t,
        report_adaptive_c,
    )
    adaptive_error_t = np.max(np.abs(adaptive_t - reference_t), axis=1)
    adaptive_error_c = np.max(np.abs(adaptive_c - reference_c), axis=1)
    adaptive_summary = {
        "method": "FVM adaptive backward Euler",
        "intervals": reference_intervals,
        "nodes": reference_intervals + 1,
        "dr_mm": 20.0 / reference_intervals,
        "reference_dt_s": FIXED_DT_S,
        "relative_tolerance": args.adaptive_rtol,
        "temperature_absolute_tolerance": args.adaptive_temperature_atol,
        "moisture_absolute_tolerance": args.adaptive_moisture_atol,
        "initial_dt_s": args.adaptive_initial_dt,
        "minimum_allowed_dt_s": args.adaptive_min_dt,
        "maximum_allowed_dt_s": args.adaptive_max_dt,
        **adaptive_metrics,
        **{
            key: _finite_or_none(value)
            for key, value in asdict(adaptive_stats).items()
        },
    }

    print("[7/7] 写入统一JSON和绘图源CSV...", flush=True)
    reference_table = _model_table(
        COMMON_TIMES_S, COMMON_RADII_M, reference_t, reference_c
    )
    adaptive_table = _model_table(
        COMMON_TIMES_S, COMMON_RADII_M, adaptive_t, adaptive_c
    )
    adaptive_report_rows = _report_rows(
        f"{reference_label}自适应",
        report_adaptive_t,
        report_adaptive_c,
        report_reference_t,
        report_reference_c,
    )

    payload = {
        "metadata": {
            "input_file": str(args.input.resolve()),
            "comparison_reference": (
                f"FVM，{reference_intervals}个空间区间"
                f"（{reference_intervals + 1}节点），固定dt=1 s"
            ),
            "reference_intervals": reference_intervals,
            "reference_label": reference_label,
            "common_time_range_s": [0.0, 1800.0],
            "common_time_step_s": 1.0,
            "common_radii_mm": (1000.0 * COMMON_RADII_M).tolist(),
            "report_times_s": fvm.REPORT_TIMES_S.tolist(),
            "report_radii_mm": (1000.0 * fvm.REPORT_RADII_M).tolist(),
            "note": (
                "完整对照表统一输出每1 s、每1 mm的数据；指定点表为7时刻×5半径。"
                "FDM与FVM边界离散不同，表面附近通常给出最大方法差异。"
            ),
        },
        "reference": reference_table,
        "reference_diagnostics": reference.diagnostics,
        "fdm": {
            "summary": fdm_summary,
            "models": fdm_tables,
            "report_rows": fdm_report_rows,
        },
        "adaptive": {
            "summary": adaptive_summary,
            "model": adaptive_table,
            "report_rows": adaptive_report_rows,
            "history": adaptive_history,
            "error_time": {
                "times_s": COMMON_TIMES_S.tolist(),
                "temperature_max_abs_c": adaptive_error_t.tolist(),
                "moisture_max_abs_kg_kg": adaptive_error_c.tolist(),
            },
        },
    }
    payload_path = output_dir / "cross_validation_payload.json"
    payload_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    summary_path = output_dir / "cross_validation_metrics.json"
    summary_path.write_text(
        json.dumps(
            {
                "reference_diagnostics": reference.diagnostics,
                "fdm_summary": fdm_summary,
                "adaptive_summary": adaptive_summary,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    # 有限差分：1800 s空间分布曲线源数据。
    profile_header = ["radius_mm", f"{reference_label}_temperature_c"]
    for intervals in FDM_INTERVALS:
        profile_header.append(f"FDM{intervals}_temperature_c")
    profile_header.append(f"{reference_label}_moisture_kg_kg")
    for intervals in FDM_INTERVALS:
        profile_header.append(f"FDM{intervals}_moisture_kg_kg")
    profile_rows = []
    for j, radius_m in enumerate(COMMON_RADII_M):
        row = [float(1000.0 * radius_m), float(reference_t[-1, j])]
        row.extend(
            float(fdm_final_profiles[n][0][j]) for n in FDM_INTERVALS
        )
        row.append(float(reference_c[-1, j]))
        row.extend(
            float(fdm_final_profiles[n][1][j]) for n in FDM_INTERVALS
        )
        profile_rows.append(row)
    _write_csv(source_dir / "fdm_profiles_1800s.csv", profile_header, profile_rows)

    convergence_header = [
        "intervals",
        "nodes",
        "dr_mm",
        "full_max_abs_temperature_c",
        "full_rms_temperature_c",
        "full_max_abs_moisture_kg_kg",
        "full_rms_moisture_kg_kg",
        "report_max_abs_temperature_c",
        "report_max_abs_moisture_kg_kg",
        "final_profile_max_abs_temperature_c",
        "final_profile_max_abs_moisture_kg_kg",
    ]
    _write_csv(
        source_dir / "fdm_convergence.csv",
        convergence_header,
        ([row[column] for column in convergence_header] for row in fdm_summary),
    )

    adaptive_profile_rows = [
        [
            float(1000.0 * radius_m),
            float(reference_t[-1, j]),
            float(adaptive_t[-1, j]),
            float(adaptive_t[-1, j] - reference_t[-1, j]),
            float(reference_c[-1, j]),
            float(adaptive_c[-1, j]),
            float(adaptive_c[-1, j] - reference_c[-1, j]),
        ]
        for j, radius_m in enumerate(COMMON_RADII_M)
    ]
    _write_csv(
        source_dir / "adaptive_profiles_1800s.csv",
        [
            "radius_mm",
            "fixed_temperature_c",
            "adaptive_temperature_c",
            "temperature_difference_c",
            "fixed_moisture_kg_kg",
            "adaptive_moisture_kg_kg",
            "moisture_difference_kg_kg",
        ],
        adaptive_profile_rows,
    )
    _write_csv(
        source_dir / "adaptive_error_time.csv",
        ["time_s", "temperature_max_abs_c", "moisture_max_abs_kg_kg"],
        zip(COMMON_TIMES_S, adaptive_error_t, adaptive_error_c),
    )
    _write_csv(
        source_dir / "adaptive_step_history.csv",
        list(adaptive_history[0].keys()),
        ([entry[key] for key in adaptive_history[0].keys()] for entry in adaptive_history),
    )

    # Excel之外额外提供长表CSV，便于复核或导入其他软件。
    comparison_header = [
        "model",
        "time_s",
        "radius_mm",
        "candidate_temperature_c",
        "reference_temperature_c",
        "temperature_difference_c",
        "candidate_moisture_kg_kg",
        "reference_moisture_kg_kg",
        "moisture_difference_kg_kg",
    ]
    _write_csv(
        output_dir / "fdm_report_point_comparison.csv",
        comparison_header,
        fdm_report_rows,
    )
    _write_csv(
        output_dir / "adaptive_report_point_comparison.csv",
        comparison_header,
        adaptive_report_rows,
    )

    print(f"已生成：{payload_path}")
    print(f"已生成：{summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
