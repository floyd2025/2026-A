#!/usr/bin/env python3
"""在任意电脑上一键运行问题4主模型、验证算例、汇总和绘图。"""

from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="完整复现问题4")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印将执行的命令，不进行耗时计算",
    )
    parser.add_argument(
        "--main-only",
        action="store_true",
        help="只运行N=640主模型，不运行交叉验证和绘图",
    )
    parser.add_argument("--progress", action="store_true", help="显示求解进度")
    return parser.parse_args()


def printable(command: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in command)


def execute(command: list[str], dry_run: bool) -> None:
    print(f"\n> {printable(command)}", flush=True)
    if not dry_run:
        subprocess.run(command, cwd=SCRIPT_DIR, check=True)


def solver_command(output_dir: Path, extra: list[str], progress: bool) -> list[str]:
    command = [
        sys.executable,
        str(SCRIPT_DIR / "question4_shrinking_fvm.py"),
        "--input",
        str(SCRIPT_DIR / "附件1.xlsx"),
        "--radius-input",
        str(SCRIPT_DIR / "附件2.xlsx"),
        "--output-dir",
        str(output_dir),
        *extra,
    ]
    if progress:
        command.append("--progress")
    return command


def main() -> int:
    args = parse_args()
    final_dir = SCRIPT_DIR / "question4_final"
    work_dir = SCRIPT_DIR / "work"
    figure_dir = SCRIPT_DIR / "question4_figures"

    execute(
        solver_command(
            final_dir,
            ["--intervals", "640", "--early-dt", "1", "--late-dt", "30"],
            args.progress,
        ),
        args.dry_run,
    )
    if args.main_only:
        return 0

    cases = [
        ("q4_n80", ["--intervals", "80"]),
        ("q4_n160", ["--intervals", "160"]),
        ("q4_n320", ["--intervals", "320"]),
        ("q4_n640_dt15", ["--intervals", "640", "--late-dt", "15"]),
        ("q4_n640_dt60", ["--intervals", "640", "--late-dt", "60"]),
        (
            "q4_fixed_initial_n320",
            ["--intervals", "320", "--radius-mode", "fixed-initial"],
        ),
        ("q4_hm_low_n320", ["--intervals", "320", "--mass-transfer", "6.4e-7"]),
        ("q4_hm_high_n320", ["--intervals", "320", "--mass-transfer", "9.6e-7"]),
        ("q4_h_low_n160", ["--intervals", "160", "--heat-transfer", "20"]),
        ("q4_h_high_n160", ["--intervals", "160", "--heat-transfer", "30"]),
        (
            "q4_last_point_n320",
            ["--intervals", "320", "--plateau-mode", "last-point"],
        ),
    ]
    for name, options in cases:
        execute(
            solver_command(work_dir / name, options, args.progress),
            args.dry_run,
        )

    execute(
        [
            sys.executable,
            str(SCRIPT_DIR / "question4_collect_validation.py"),
            "--final-dir",
            str(final_dir),
            "--work-dir",
            str(work_dir),
        ],
        args.dry_run,
    )
    execute(
        [
            sys.executable,
            str(SCRIPT_DIR / "question4_plot_results.py"),
            "--data-dir",
            str(final_dir),
            "--work-dir",
            str(work_dir),
            "--output-dir",
            str(figure_dir),
        ],
        args.dry_run,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
