#!/usr/bin/env python3
"""汇总问题4的网格、时间步、移动边界和参数敏感性检验。"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from question1_fvm_backward_euler import BoundaryData, build_geometry
from question4_shrinking_fvm import (
    ExtendedBoundary,
    Q4Parameters,
    coupled_backward_euler_step,
)


SCRIPT_DIR = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="汇总问题4数值验证结果")
    parser.add_argument(
        "--final-dir",
        type=Path,
        default=SCRIPT_DIR / "question4_final",
        help="N=640、后期dt=30 s主结果目录",
    )
    parser.add_argument(
        "--work-dir",
        type=Path,
        default=SCRIPT_DIR / "work",
        help="其余网格、时间步与敏感性算例目录",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def completion_hours(directory: Path) -> float:
    return float(
        read_json(directory / "question4_summary.json")["main_result"]
        ["drying_completion_time_h"]
    )


def common_field_difference(path_a: Path, path_b: Path) -> dict[str, float | int]:
    def load(path: Path) -> dict[float, dict[str, float]]:
        result: dict[float, dict[str, float]] = {}
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                parsed: dict[str, float] = {}
                for key, value in row.items():
                    if value is not None and value.strip() != "":
                        parsed[key] = float(value)
                result[round(parsed["time_s"], 6)] = parsed
        return result

    rows_a = load(path_a)
    rows_b = load(path_b)
    common_times = sorted(set(rows_a) & set(rows_b))
    maximum = 0.0
    compared = 0
    for time_key in common_times:
        common_columns = set(rows_a[time_key]) & set(rows_b[time_key])
        for column in common_columns - {"time_s"}:
            maximum = max(
                maximum,
                abs(rows_a[time_key][column] - rows_b[time_key][column]),
            )
            compared += 1
    return {
        "common_time_count": len(common_times),
        "compared_value_count": compared,
        "max_abs_difference": maximum,
    }


def percent_difference(candidate: float, reference: float) -> float:
    return abs(candidate - reference) / abs(reference) * 100.0


def uniform_state_invariant() -> dict[str, float]:
    temperature = np.full(81, 28.0)
    moisture = np.full(81, 2.55)
    source = BoundaryData(
        time_s=np.array([0.0, 60.0]),
        temperature_c=np.array([28.0, 28.0]),
        moisture_kg_kg=np.array([2.55, 2.55]),
    )
    boundary = ExtendedBoundary(
        source=source,
        transition_time_s=60.0,
        plateau_temperature_c=28.0,
        plateau_moisture_kg_kg=2.55,
        plateau_window_s=60.0,
        plateau_mode="window-mean",
        plateau_temperature_std_c=0.0,
        plateau_moisture_std_kg_kg=0.0,
    )
    next_temperature, next_moisture, _ = coupled_backward_euler_step(
        geometry=build_geometry(0.015, 80),
        params=Q4Parameters(),
        old_temperature_c=temperature,
        old_moisture_kg_kg=moisture,
        next_time_s=30.0,
        dt_s=30.0,
        boundary=boundary,
    )
    return {
        "radius_used_cm": 1.5,
        "max_abs_temperature_change_c": float(
            np.max(np.abs(next_temperature - temperature))
        ),
        "max_abs_moisture_change_kg_kg": float(
            np.max(np.abs(next_moisture - moisture))
        ),
    }


def main() -> None:
    args = parse_args()
    final_dir = args.final_dir.expanduser().resolve()
    work_dir = args.work_dir.expanduser().resolve()
    if not final_dir.is_dir():
        raise FileNotFoundError(f"找不到主结果目录：{final_dir}")
    if not work_dir.is_dir():
        raise FileNotFoundError(f"找不到验证算例目录：{work_dir}")

    directories = {
        80: work_dir / "q4_n80",
        160: work_dir / "q4_n160",
        320: work_dir / "q4_n320",
        640: final_dir,
    }
    spatial = {n: completion_hours(path) for n, path in directories.items()}
    differences = {
        "80_to_160_h": spatial[80] - spatial[160],
        "160_to_320_h": spatial[160] - spatial[320],
        "320_to_640_h": spatial[320] - spatial[640],
    }
    observed_order = math.log(
        differences["160_to_320_h"] / differences["320_to_640_h"], 2.0
    )
    richardson_h = spatial[640] + (
        spatial[640] - spatial[320]
    ) / (2.0**observed_order - 1.0)
    conservative_h = spatial[640] + (spatial[640] - spatial[320]) / 3.0

    time_hours = {
        15: completion_hours(work_dir / "q4_n640_dt15"),
        30: spatial[640],
        60: completion_hours(work_dir / "q4_n640_dt60"),
    }
    temporal_order = math.log(
        (time_hours[60] - time_hours[30])
        / (time_hours[30] - time_hours[15]),
        2.0,
    )
    temporal_extrapolated_h = time_hours[15] + (
        time_hours[15] - time_hours[30]
    ) / (2.0**temporal_order - 1.0)

    fixed_n320 = completion_hours(work_dir / "q4_fixed_initial_n320")
    hm_low = completion_hours(work_dir / "q4_hm_low_n320")
    hm_high = completion_hours(work_dir / "q4_hm_high_n320")
    h_low = completion_hours(work_dir / "q4_h_low_n160")
    h_high = completion_hours(work_dir / "q4_h_high_n160")
    last_point = completion_hours(work_dir / "q4_last_point_n320")

    final_summary_path = final_dir / "question4_summary.json"
    final_summary = read_json(final_summary_path)
    validation = {
        "spatial_convergence": {
            "completion_time_h_by_intervals": {
                str(n): value for n, value in spatial.items()
            },
            "successive_differences_h": differences,
            "observed_order_160_320_640": observed_order,
            "richardson_extrapolated_completion_time_h": richardson_h,
            "n640_estimated_absolute_error_s": abs(spatial[640] - richardson_h)
            * 3600.0,
            "n640_estimated_relative_error_percent": percent_difference(
                spatial[640], richardson_h
            ),
            "conservative_second_order_extrapolated_time_h": conservative_h,
            "conservative_n640_error_s": abs(spatial[640] - conservative_h)
            * 3600.0,
            "n320_vs_n640_moisture_field": common_field_difference(
                directories[320] / "result4_moisture.csv",
                directories[640] / "result4_moisture.csv",
            ),
            "n320_vs_n640_temperature_field": common_field_difference(
                directories[320] / "question4_temperature_history.csv",
                directories[640] / "question4_temperature_history.csv",
            ),
        },
        "temporal_convergence_n640": {
            "completion_time_h_by_late_dt_s": {
                str(dt): value for dt, value in time_hours.items()
            },
            "observed_order_15_30_60": temporal_order,
            "zero_step_extrapolated_completion_time_h": temporal_extrapolated_h,
            "dt30_estimated_absolute_error_s": abs(
                time_hours[30] - temporal_extrapolated_h
            )
            * 3600.0,
            "dt30_estimated_relative_error_percent": percent_difference(
                time_hours[30], temporal_extrapolated_h
            ),
        },
        "moving_boundary_necessity_n320": {
            "measured_radius_completion_time_h": spatial[320],
            "fixed_initial_radius_completion_time_h": fixed_n320,
            "absolute_difference_h": fixed_n320 - spatial[320],
            "fixed_model_overestimate_relative_to_moving_percent": (
                fixed_n320 - spatial[320]
            )
            / spatial[320]
            * 100.0,
        },
        "borrowed_parameter_sensitivity": {
            "mass_transfer_n320": {
                "baseline_8e-7_h": spatial[320],
                "minus_20_percent_h": hm_low,
                "plus_20_percent_h": hm_high,
                "minus_20_percent_relative_change_percent": (
                    hm_low - spatial[320]
                )
                / spatial[320]
                * 100.0,
                "plus_20_percent_relative_change_percent": (
                    hm_high - spatial[320]
                )
                / spatial[320]
                * 100.0,
            },
            "heat_transfer_n160": {
                "baseline_25_h": spatial[160],
                "minus_20_percent_h": h_low,
                "plus_20_percent_h": h_high,
                "minus_20_percent_relative_change_percent": (
                    h_low - spatial[160]
                )
                / spatial[160]
                * 100.0,
                "plus_20_percent_relative_change_percent": (
                    h_high - spatial[160]
                )
                / spatial[160]
                * 100.0,
            },
        },
        "boundary_extension_sensitivity_n320": {
            "last_60min_mean_h": spatial[320],
            "last_point_h": last_point,
            "absolute_difference_min": abs(last_point - spatial[320]) * 60.0,
            "relative_difference_percent": percent_difference(
                last_point, spatial[320]
            ),
        },
        "uniform_state_invariant_test": uniform_state_invariant(),
        "solver_diagnostics_n640_dt30": final_summary["diagnostics"],
    }

    write_json(final_dir / "question4_validation_final.json", validation)
    final_summary["validation"] = validation
    final_summary["interpretation"] = (
        "烘干结束定义为移动药材域全部节点干基含水率首次不高于0.15 kg/kg。"
        "最终采用材料坐标上640个区间，前4 h步长1 s、后期30 s，阈值附近1 s。"
        "附件2半径线性插值；附件1结束后采用末1 h均值延拓。"
    )
    write_json(final_summary_path, final_summary)

    with (final_dir / "question4_completion_convergence.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["intervals", "initial_dr_m", "completion_time_h", "relative_to_n640_percent"]
        )
        for n, value in spatial.items():
            writer.writerow([n, 0.02 / n, value, percent_difference(value, spatial[640])])

    rows: list[list[Any]] = [[
        "validation_type", "setting", "completion_time_h", "relative_change_percent"
    ]]
    rows.extend(
        ["spatial", f"N={n}", value, percent_difference(value, spatial[640])]
        for n, value in spatial.items()
    )
    rows.extend(
        ["temporal", f"late_dt={dt}s,N=640", value, percent_difference(value, time_hours[30])]
        for dt, value in time_hours.items()
    )
    rows.extend([
        ["radius", "measured,N=320", spatial[320], 0.0],
        ["radius", "fixed_initial,N=320", fixed_n320, (fixed_n320 / spatial[320] - 1.0) * 100.0],
        ["mass_transfer", "hm=-20%,N=320", hm_low, (hm_low / spatial[320] - 1.0) * 100.0],
        ["mass_transfer", "hm=+20%,N=320", hm_high, (hm_high / spatial[320] - 1.0) * 100.0],
        ["heat_transfer", "h=-20%,N=160", h_low, (h_low / spatial[160] - 1.0) * 100.0],
        ["heat_transfer", "h=+20%,N=160", h_high, (h_high / spatial[160] - 1.0) * 100.0],
        ["boundary", "last_point,N=320", last_point, (last_point / spatial[320] - 1.0) * 100.0],
    ])
    with (final_dir / "question4_validation_table.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        csv.writer(handle).writerows(rows)

    print(json.dumps(validation, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
