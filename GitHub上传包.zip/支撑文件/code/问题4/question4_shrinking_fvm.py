#!/usr/bin/env python3
"""CUMCM A题问题4：收缩圆柱域上的变物性温湿耦合数值求解。

数学模型
--------
使用材料坐标 xi=r/R(t) 将随时间变化的区间 0<=r<=R(t) 映射到固定区间
0<=xi<=1。假设附件2给出的径向收缩是均匀的，xi 固定的网格点随药材骨架
一起运动，因此温度、干基含水率方程中的时间导数取材料导数，不再额外加入
人为的网格对流项：

rho(C) cp(C) dT/dt = 1/[R(t)^2 xi] d/dxi[xi k(C) dT/dxi]
dC/dt              = 1/[R(t)^2 xi] d/dxi[xi D(C,T) dC/dxi]

空间采用节点型守恒有限体积法，时间采用后向欧拉，变物性耦合采用 Picard
迭代。附件1结束后，外界温度和水分浓度采用最后稳定时间窗均值延拓；附件2
半径在测点间线性插值。默认前4 h步长1 s、之后30 s，阈值附近回退到1 s。

本脚本只生成 CSV/JSON 数值结果。result4.xlsx 由独立 artifact-tool 脚本生成。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from openpyxl import load_workbook

from question1_fvm_backward_euler import (
    BoundaryData,
    Geometry,
    build_geometry,
    read_boundary_data,
    relative_residual,
    solve_tridiagonal,
    tridiagonal_matvec,
)


SCRIPT_DIR = Path(__file__).resolve().parent
SECONDS_PER_HOUR = 3600.0
INITIAL_RADIUS_M = 0.020
FIXED_OUTPUT_RADII_M = np.linspace(0.0, INITIAL_RADIUS_M, 21)
PROFILE_XI = np.linspace(0.0, 1.0, 101)


@dataclass(frozen=True)
class Q4Parameters:
    heat_transfer_w_m2_k: float = 25.0
    mass_transfer_m_s: float = 8.0e-7
    initial_temperature_c: float = 28.0
    initial_moisture_kg_kg: float = 2.55
    picard_update_tolerance: float = 1.0e-9
    picard_residual_tolerance: float = 1.0e-10
    picard_max_iterations: int = 200
    picard_relaxation: float = 1.0


@dataclass(frozen=True)
class Q4Config:
    intervals: int = 640
    threshold_kg_kg: float = 0.15
    transition_time_s: float = 4.0 * SECONDS_PER_HOUR
    plateau_window_s: float = SECONDS_PER_HOUR
    plateau_mode: str = "window-mean"
    early_dt_s: float = 1.0
    late_dt_s: float = 30.0
    final_refine_dt_s: float = 1.0
    output_interval_s: float = 60.0
    paper_interval_s: float = 6.0 * SECONDS_PER_HOUR
    progress_interval_s: float = 6.0 * SECONDS_PER_HOUR
    max_time_s: float = 7.0 * 24.0 * SECONDS_PER_HOUR
    radius_mode: str = "measured"
    radius_extrapolation: str = "hold-last"


@dataclass(frozen=True)
class ExtendedBoundary:
    source: BoundaryData
    transition_time_s: float
    plateau_temperature_c: float
    plateau_moisture_kg_kg: float
    plateau_window_s: float
    plateau_mode: str
    plateau_temperature_std_c: float
    plateau_moisture_std_kg_kg: float

    def temperature(self, time_s: float | np.ndarray) -> float | np.ndarray:
        time_value = np.asarray(time_s, dtype=float)
        original = np.interp(
            np.minimum(time_value, self.transition_time_s),
            self.source.time_s,
            self.source.temperature_c,
        )
        result = np.where(
            time_value <= self.transition_time_s,
            original,
            self.plateau_temperature_c,
        )
        return float(result) if np.ndim(result) == 0 else result

    def moisture(self, time_s: float | np.ndarray) -> float | np.ndarray:
        time_value = np.asarray(time_s, dtype=float)
        original = np.interp(
            np.minimum(time_value, self.transition_time_s),
            self.source.time_s,
            self.source.moisture_kg_kg,
        )
        result = np.where(
            time_value <= self.transition_time_s,
            original,
            self.plateau_moisture_kg_kg,
        )
        return float(result) if np.ndim(result) == 0 else result


@dataclass(frozen=True)
class RadiusData:
    time_s: np.ndarray
    measured_radius_m: np.ndarray
    mode: str = "measured"
    extrapolation: str = "hold-last"

    def radius(self, time_s: float | np.ndarray) -> float | np.ndarray:
        values = np.asarray(time_s, dtype=float)
        if self.mode == "fixed-initial":
            result = np.full_like(values, self.measured_radius_m[0], dtype=float)
        elif self.mode == "fixed-final":
            result = np.full_like(values, self.measured_radius_m[-1], dtype=float)
        elif self.mode == "measured":
            result = np.interp(
                values,
                self.time_s,
                self.measured_radius_m,
                left=self.measured_radius_m[0],
                right=self.measured_radius_m[-1],
            )
        else:
            raise ValueError(f"不支持的radius_mode：{self.mode}")
        return float(result) if np.ndim(result) == 0 else result


@dataclass
class DiagnosticAccumulator:
    max_temperature_linear_relative_residual: float = 0.0
    max_moisture_linear_relative_residual: float = 0.0
    max_temperature_nonlinear_relative_residual: float = 0.0
    max_moisture_nonlinear_relative_residual: float = 0.0
    max_picard_relative_update_encountered: float = 0.0
    max_final_picard_relative_update: float = 0.0
    max_heat_balance_relative_residual: float = 0.0
    max_moisture_balance_relative_residual: float = 0.0
    max_heat_balance_absolute_residual_j_per_m: float = 0.0
    max_moisture_balance_absolute_residual_m2_kg_per_kg: float = 0.0
    picard_iterations_max: int = 0
    picard_iterations_sum: int = 0
    accepted_steps: int = 0
    early_steps: int = 0
    late_steps: int = 0
    refined_steps: int = 0
    min_dt_s: float = math.inf
    max_dt_s: float = 0.0
    temperature_min_c: float = math.inf
    temperature_max_c: float = -math.inf
    moisture_min_kg_kg: float = math.inf
    moisture_max_kg_kg: float = -math.inf
    moisture_radial_order_violations: int = 0

    def absorb(self, step: dict[str, float | int], dt_s: float, stage: str) -> None:
        maximum_fields = (
            "max_temperature_linear_relative_residual",
            "max_moisture_linear_relative_residual",
            "max_temperature_nonlinear_relative_residual",
            "max_moisture_nonlinear_relative_residual",
            "max_picard_relative_update_encountered",
            "max_final_picard_relative_update",
            "max_heat_balance_relative_residual",
            "max_moisture_balance_relative_residual",
            "max_heat_balance_absolute_residual_j_per_m",
            "max_moisture_balance_absolute_residual_m2_kg_per_kg",
        )
        for field in maximum_fields:
            setattr(self, field, max(float(getattr(self, field)), float(step[field])))
        self.picard_iterations_max = max(
            self.picard_iterations_max, int(step["picard_iterations"])
        )
        self.picard_iterations_sum += int(step["picard_iterations"])
        self.accepted_steps += 1
        if stage == "early":
            self.early_steps += 1
        elif stage == "late":
            self.late_steps += 1
        elif stage == "refined":
            self.refined_steps += 1
        else:
            raise ValueError(f"未知时间步阶段：{stage}")
        self.min_dt_s = min(self.min_dt_s, dt_s)
        self.max_dt_s = max(self.max_dt_s, dt_s)
        self.temperature_min_c = min(
            self.temperature_min_c, float(step["temperature_min_c"])
        )
        self.temperature_max_c = max(
            self.temperature_max_c, float(step["temperature_max_c"])
        )
        self.moisture_min_kg_kg = min(
            self.moisture_min_kg_kg, float(step["moisture_min_kg_kg"])
        )
        self.moisture_max_kg_kg = max(
            self.moisture_max_kg_kg, float(step["moisture_max_kg_kg"])
        )
        self.moisture_radial_order_violations += int(
            step["moisture_radial_order_violations"]
        )

    def as_dict(self) -> dict[str, float | int]:
        result = asdict(self)
        result["picard_iterations_mean"] = (
            self.picard_iterations_sum / self.accepted_steps
            if self.accepted_steps
            else 0.0
        )
        if not math.isfinite(float(result["min_dt_s"])):
            result["min_dt_s"] = 0.0
        return result


@dataclass
class Q4Solution:
    times_s: np.ndarray
    radius_history_m: np.ndarray
    temperature_output_c: np.ndarray
    moisture_output_kg_kg: np.ndarray
    profile_times_s: np.ndarray
    profile_radius_m: np.ndarray
    profile_temperature_c: np.ndarray
    profile_moisture_kg_kg: np.ndarray
    completion_time_s: float
    completion_radius_m: float
    completion_temperature_nodes_c: np.ndarray
    completion_moisture_nodes_kg_kg: np.ndarray
    completion_radius_nodes_m: np.ndarray
    diagnostics: dict


def density_kg_m3(moisture: np.ndarray) -> np.ndarray:
    return 760.0 + 90.0 * moisture


def heat_capacity_j_kg_k(moisture: np.ndarray) -> np.ndarray:
    return 1850.0 + 2150.0 * moisture / (moisture + 1.0)


def thermal_conductivity_w_m_k(moisture: np.ndarray) -> np.ndarray:
    return 0.12 + 0.20 * moisture / (moisture + 1.0)


def moisture_diffusivity_m2_s(
    moisture: np.ndarray, temperature_c: np.ndarray
) -> np.ndarray:
    temperature_k = temperature_c + 273.15
    if np.any(~np.isfinite(moisture)) or np.any(moisture <= 0.0):
        raise FloatingPointError("附录4扩散系数要求含水率为有限正数")
    if np.any(~np.isfinite(temperature_k)) or np.any(temperature_k <= 0.0):
        raise FloatingPointError("附录4扩散系数要求绝对温度为有限正数")
    diffusivity = (
        4.2e-4
        * np.exp(-0.30 / moisture)
        * np.exp(-3850.0 / temperature_k)
    )
    if np.any(~np.isfinite(diffusivity)) or np.any(diffusivity <= 0.0):
        raise FloatingPointError("附录4扩散系数出现非正或非有限值")
    return diffusivity


def harmonic_faces(node_values: np.ndarray) -> np.ndarray:
    denominator = node_values[:-1] + node_values[1:]
    if np.any(denominator <= 0.0):
        raise FloatingPointError("面系数调和平均分母必须为正")
    return 2.0 * node_values[:-1] * node_values[1:] / denominator


def assemble_tridiagonal(
    geometry: Geometry,
    capacity: np.ndarray,
    node_transport: np.ndarray,
    surface_transfer: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    node_count = len(capacity)
    face_transport = harmonic_faces(node_transport)
    conductance = (
        face_transport * geometry.internal_face_areas_m / geometry.dr_m
    )
    lower = np.zeros(node_count)
    diagonal = capacity.copy()
    upper = np.zeros(node_count)
    diagonal[0] += conductance[0]
    upper[0] = -conductance[0]
    for index in range(1, node_count - 1):
        lower[index] = -conductance[index - 1]
        diagonal[index] += conductance[index - 1] + conductance[index]
        upper[index] = -conductance[index]
    lower[-1] = -conductance[-1]
    diagonal[-1] += (
        conductance[-1] + surface_transfer * geometry.surface_area_m
    )
    return lower, diagonal, upper


def read_radius_data(
    path: Path, mode: str = "measured", extrapolation: str = "hold-last"
) -> RadiusData:
    if not path.exists():
        raise FileNotFoundError(f"找不到附件2：{path}")
    workbook = load_workbook(path, data_only=True, read_only=True)
    worksheet = workbook.active
    rows = list(worksheet.iter_rows(min_row=2, max_col=2, values_only=True))
    workbook.close()
    if not rows:
        raise ValueError("附件2没有半径数据")
    data = np.asarray(rows, dtype=float)
    if data.ndim != 2 or data.shape[1] != 2 or np.any(~np.isfinite(data)):
        raise ValueError("附件2必须是无缺失的时间、半径两列数值")
    time_s = data[:, 0]
    radius_m = data[:, 1] / 100.0
    if not math.isclose(float(time_s[0]), 0.0, abs_tol=1.0e-9):
        raise ValueError("附件2必须从t=0开始")
    if np.any(np.diff(time_s) <= 0.0):
        raise ValueError("附件2时间必须严格递增")
    if np.any(radius_m <= 0.0):
        raise ValueError("附件2半径必须为正")
    if np.any(np.diff(radius_m) > 1.0e-12):
        raise ValueError("附件2半径不是单调不增，需先核查数据")
    if not math.isclose(float(radius_m[0]), INITIAL_RADIUS_M, abs_tol=1.0e-12):
        raise ValueError("附件2初始半径与题目2 cm不一致")
    if extrapolation != "hold-last":
        raise ValueError("当前实现仅允许hold-last半径外推")
    return RadiusData(time_s, radius_m, mode=mode, extrapolation=extrapolation)


def build_extended_boundary(
    source: BoundaryData, config: Q4Config
) -> ExtendedBoundary:
    if config.plateau_mode not in {"window-mean", "last-point"}:
        raise ValueError("plateau_mode必须为window-mean或last-point")
    if config.plateau_mode == "last-point":
        temperature = float(source.temperature_c[-1])
        moisture = float(source.moisture_kg_kg[-1])
        temperature_std = 0.0
        moisture_std = 0.0
        window_s = 0.0
    else:
        start = config.transition_time_s - config.plateau_window_s
        if start < float(source.time_s[0]):
            raise ValueError("边界稳定时间窗超出附件1范围")
        mask = source.time_s >= start - 1.0e-9
        if np.count_nonzero(mask) < 2:
            raise ValueError("稳定时间窗内至少需要两个附件1测点")
        temperature = float(np.mean(source.temperature_c[mask]))
        moisture = float(np.mean(source.moisture_kg_kg[mask]))
        temperature_std = float(np.std(source.temperature_c[mask], ddof=1))
        moisture_std = float(np.std(source.moisture_kg_kg[mask], ddof=1))
        window_s = config.plateau_window_s
    return ExtendedBoundary(
        source=source,
        transition_time_s=config.transition_time_s,
        plateau_temperature_c=temperature,
        plateau_moisture_kg_kg=moisture,
        plateau_window_s=window_s,
        plateau_mode=config.plateau_mode,
        plateau_temperature_std_c=temperature_std,
        plateau_moisture_std_kg_kg=moisture_std,
    )


def heat_system(
    geometry: Geometry,
    params: Q4Parameters,
    old_temperature_c: np.ndarray,
    moisture_for_properties: np.ndarray,
    ambient_temperature_c: float,
    dt_s: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    volumetric_capacity = (
        density_kg_m3(moisture_for_properties)
        * heat_capacity_j_kg_k(moisture_for_properties)
    )
    capacity = volumetric_capacity * geometry.cell_volumes_m2 / dt_s
    conductivity = thermal_conductivity_w_m_k(moisture_for_properties)
    lower, diagonal, upper = assemble_tridiagonal(
        geometry, capacity, conductivity, params.heat_transfer_w_m2_k
    )
    rhs = capacity * old_temperature_c
    rhs[-1] += (
        params.heat_transfer_w_m2_k
        * geometry.surface_area_m
        * ambient_temperature_c
    )
    return lower, diagonal, upper, rhs


def moisture_system(
    geometry: Geometry,
    params: Q4Parameters,
    old_moisture_kg_kg: np.ndarray,
    moisture_for_properties: np.ndarray,
    temperature_for_properties_c: np.ndarray,
    ambient_moisture_kg_kg: float,
    dt_s: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    capacity = geometry.cell_volumes_m2 / dt_s
    diffusivity = moisture_diffusivity_m2_s(
        moisture_for_properties, temperature_for_properties_c
    )
    lower, diagonal, upper = assemble_tridiagonal(
        geometry, capacity, diffusivity, params.mass_transfer_m_s
    )
    rhs = capacity * old_moisture_kg_kg
    rhs[-1] += (
        params.mass_transfer_m_s
        * geometry.surface_area_m
        * ambient_moisture_kg_kg
    )
    return lower, diagonal, upper, rhs


def normalized_update(
    candidate_temperature_c: np.ndarray,
    guess_temperature_c: np.ndarray,
    candidate_moisture_kg_kg: np.ndarray,
    guess_moisture_kg_kg: np.ndarray,
) -> float:
    temperature_scale = max(
        float(np.max(np.abs(candidate_temperature_c))), 1.0
    )
    moisture_scale = max(
        float(np.max(np.abs(candidate_moisture_kg_kg))), 1.0
    )
    return max(
        float(np.max(np.abs(candidate_temperature_c - guess_temperature_c)))
        / temperature_scale,
        float(np.max(np.abs(candidate_moisture_kg_kg - guess_moisture_kg_kg)))
        / moisture_scale,
    )


def coupled_backward_euler_step(
    geometry: Geometry,
    params: Q4Parameters,
    old_temperature_c: np.ndarray,
    old_moisture_kg_kg: np.ndarray,
    next_time_s: float,
    dt_s: float,
    boundary: ExtendedBoundary,
) -> tuple[np.ndarray, np.ndarray, dict[str, float | int]]:
    ambient_temperature = float(boundary.temperature(next_time_s))
    ambient_moisture = float(boundary.moisture(next_time_s))
    guess_temperature = old_temperature_c.copy()
    guess_moisture = old_moisture_kg_kg.copy()
    heat_linear_max = 0.0
    moisture_linear_max = 0.0
    update_seen_max = 0.0
    update = math.inf
    heat_nonlinear = math.inf
    moisture_nonlinear = math.inf
    candidate_temperature = guess_temperature.copy()
    candidate_moisture = guess_moisture.copy()

    for iteration in range(1, params.picard_max_iterations + 1):
        heat_lower, heat_diagonal, heat_upper, heat_rhs = heat_system(
            geometry,
            params,
            old_temperature_c,
            guess_moisture,
            ambient_temperature,
            dt_s,
        )
        candidate_temperature = solve_tridiagonal(
            heat_lower, heat_diagonal, heat_upper, heat_rhs
        )
        heat_linear = relative_residual(
            tridiagonal_matvec(
                heat_lower, heat_diagonal, heat_upper, candidate_temperature
            )
            - heat_rhs,
            heat_rhs,
        )
        heat_linear_max = max(heat_linear_max, heat_linear)

        moisture_lower, moisture_diagonal, moisture_upper, moisture_rhs = (
            moisture_system(
                geometry,
                params,
                old_moisture_kg_kg,
                guess_moisture,
                candidate_temperature,
                ambient_moisture,
                dt_s,
            )
        )
        candidate_moisture = solve_tridiagonal(
            moisture_lower, moisture_diagonal, moisture_upper, moisture_rhs
        )
        moisture_linear = relative_residual(
            tridiagonal_matvec(
                moisture_lower,
                moisture_diagonal,
                moisture_upper,
                candidate_moisture,
            )
            - moisture_rhs,
            moisture_rhs,
        )
        moisture_linear_max = max(moisture_linear_max, moisture_linear)
        if np.any(candidate_moisture <= 0.0):
            raise FloatingPointError(
                f"t={next_time_s:g} s时Picard产生非正含水率"
            )

        final_heat = heat_system(
            geometry,
            params,
            old_temperature_c,
            candidate_moisture,
            ambient_temperature,
            dt_s,
        )
        final_moisture = moisture_system(
            geometry,
            params,
            old_moisture_kg_kg,
            candidate_moisture,
            candidate_temperature,
            ambient_moisture,
            dt_s,
        )
        heat_nonlinear = relative_residual(
            tridiagonal_matvec(
                final_heat[0], final_heat[1], final_heat[2], candidate_temperature
            )
            - final_heat[3],
            final_heat[3],
        )
        moisture_nonlinear = relative_residual(
            tridiagonal_matvec(
                final_moisture[0],
                final_moisture[1],
                final_moisture[2],
                candidate_moisture,
            )
            - final_moisture[3],
            final_moisture[3],
        )
        update = normalized_update(
            candidate_temperature,
            guess_temperature,
            candidate_moisture,
            guess_moisture,
        )
        update_seen_max = max(update_seen_max, update)
        if (
            update <= params.picard_update_tolerance
            and heat_nonlinear <= params.picard_residual_tolerance
            and moisture_nonlinear <= params.picard_residual_tolerance
        ):
            break
        relaxation = params.picard_relaxation
        guess_temperature = (
            relaxation * candidate_temperature
            + (1.0 - relaxation) * guess_temperature
        )
        guess_moisture = (
            relaxation * candidate_moisture
            + (1.0 - relaxation) * guess_moisture
        )
    else:
        raise RuntimeError(
            f"t={next_time_s:g} s、dt={dt_s:g} s时Picard未在"
            f"{params.picard_max_iterations}次内收敛；update={update:.3e}, "
            f"heat_res={heat_nonlinear:.3e}, moisture_res={moisture_nonlinear:.3e}"
        )

    volumetric_capacity = (
        density_kg_m3(candidate_moisture)
        * heat_capacity_j_kg_k(candidate_moisture)
    )
    heat_cell_change = (
        volumetric_capacity
        * geometry.cell_volumes_m2
        * (candidate_temperature - old_temperature_c)
    )
    heat_change = float(np.sum(heat_cell_change))
    heat_boundary = float(
        dt_s
        * params.heat_transfer_w_m2_k
        * geometry.surface_area_m
        * (ambient_temperature - candidate_temperature[-1])
    )
    heat_absolute = abs(heat_change - heat_boundary)
    heat_scale = float(np.sum(np.abs(heat_cell_change))) + abs(heat_boundary)

    moisture_cell_change = geometry.cell_volumes_m2 * (
        candidate_moisture - old_moisture_kg_kg
    )
    moisture_change = float(np.sum(moisture_cell_change))
    moisture_boundary = float(
        dt_s
        * params.mass_transfer_m_s
        * geometry.surface_area_m
        * (ambient_moisture - candidate_moisture[-1])
    )
    moisture_absolute = abs(moisture_change - moisture_boundary)
    moisture_scale = (
        float(np.sum(np.abs(moisture_cell_change)))
        + abs(moisture_boundary)
    )

    info: dict[str, float | int] = {
        "max_temperature_linear_relative_residual": heat_linear_max,
        "max_moisture_linear_relative_residual": moisture_linear_max,
        "max_temperature_nonlinear_relative_residual": heat_nonlinear,
        "max_moisture_nonlinear_relative_residual": moisture_nonlinear,
        "max_picard_relative_update_encountered": update_seen_max,
        "max_final_picard_relative_update": update,
        "max_heat_balance_relative_residual": (
            heat_absolute / heat_scale if heat_scale >= 1.0e-6 else 0.0
        ),
        "max_moisture_balance_relative_residual": (
            moisture_absolute / max(moisture_scale, 1.0e-30)
        ),
        "max_heat_balance_absolute_residual_j_per_m": heat_absolute,
        "max_moisture_balance_absolute_residual_m2_kg_per_kg": moisture_absolute,
        "picard_iterations": iteration,
        "temperature_min_c": float(np.min(candidate_temperature)),
        "temperature_max_c": float(np.max(candidate_temperature)),
        "moisture_min_kg_kg": float(np.min(candidate_moisture)),
        "moisture_max_kg_kg": float(np.max(candidate_moisture)),
        "moisture_radial_order_violations": int(
            np.count_nonzero(np.diff(candidate_moisture) > 1.0e-10)
        ),
    }
    return candidate_temperature, candidate_moisture, info


def sample_physical_output(
    node_field: np.ndarray, radius_m: float
) -> np.ndarray:
    radius_nodes = np.linspace(0.0, radius_m, len(node_field))
    values = np.full(len(FIXED_OUTPUT_RADII_M) + 1, np.nan)
    inside = FIXED_OUTPUT_RADII_M <= radius_m + 1.0e-12
    values[:-1][inside] = np.interp(
        FIXED_OUTPUT_RADII_M[inside], radius_nodes, node_field
    )
    values[-1] = float(node_field[-1])
    return values


def append_output(
    time_s: float,
    radius_m: float,
    temperature_nodes_c: np.ndarray,
    moisture_nodes_kg_kg: np.ndarray,
    output_times: list[float],
    output_radii: list[float],
    output_temperatures: list[np.ndarray],
    output_moistures: list[np.ndarray],
) -> None:
    if output_times and math.isclose(output_times[-1], time_s, abs_tol=1.0e-8):
        return
    output_times.append(float(time_s))
    output_radii.append(float(radius_m))
    output_temperatures.append(
        sample_physical_output(temperature_nodes_c, radius_m)
    )
    output_moistures.append(
        sample_physical_output(moisture_nodes_kg_kg, radius_m)
    )


def append_profile(
    time_s: float,
    radius_m: float,
    temperature_nodes_c: np.ndarray,
    moisture_nodes_kg_kg: np.ndarray,
    profile_times: list[float],
    profile_radii: list[np.ndarray],
    profile_temperatures: list[np.ndarray],
    profile_moistures: list[np.ndarray],
) -> None:
    if profile_times and math.isclose(profile_times[-1], time_s, abs_tol=1.0e-8):
        return
    xi_nodes = np.linspace(0.0, 1.0, len(temperature_nodes_c))
    profile_times.append(float(time_s))
    profile_radii.append(PROFILE_XI * radius_m)
    profile_temperatures.append(
        np.interp(PROFILE_XI, xi_nodes, temperature_nodes_c)
    )
    profile_moistures.append(
        np.interp(PROFILE_XI, xi_nodes, moisture_nodes_kg_kg)
    )


def validate_config(config: Q4Config) -> None:
    if config.intervals < 4:
        raise ValueError("径向空间区间数至少为4")
    if not (0.0 < config.threshold_kg_kg < 2.55):
        raise ValueError("终止阈值必须为正且低于初始含水率")
    for field in (
        "early_dt_s",
        "late_dt_s",
        "final_refine_dt_s",
        "output_interval_s",
        "paper_interval_s",
    ):
        if float(getattr(config, field)) <= 0.0:
            raise ValueError(f"{field}必须为正")
    if config.transition_time_s <= 0.0:
        raise ValueError("边界切换时间必须为正")
    if config.max_time_s <= config.transition_time_s:
        raise ValueError("最大计算时间必须超过边界切换时间")


def solve_case(
    boundary: ExtendedBoundary,
    radius_data: RadiusData,
    config: Q4Config,
    params: Q4Parameters | None = None,
    progress: bool = False,
) -> Q4Solution:
    validate_config(config)
    if params is None:
        params = Q4Parameters()
    node_count = config.intervals + 1
    temperature = np.full(
        node_count, params.initial_temperature_c, dtype=float
    )
    moisture = np.full(
        node_count, params.initial_moisture_kg_kg, dtype=float
    )
    current_time = 0.0
    current_radius = float(radius_data.radius(current_time))

    output_times: list[float] = []
    output_radii: list[float] = []
    output_temperatures: list[np.ndarray] = []
    output_moistures: list[np.ndarray] = []
    profile_times: list[float] = []
    profile_radii: list[np.ndarray] = []
    profile_temperatures: list[np.ndarray] = []
    profile_moistures: list[np.ndarray] = []
    append_output(
        current_time,
        current_radius,
        temperature,
        moisture,
        output_times,
        output_radii,
        output_temperatures,
        output_moistures,
    )

    next_output = config.output_interval_s
    next_paper = config.paper_interval_s
    next_progress = config.progress_interval_s
    diagnostics = DiagnosticAccumulator(
        temperature_min_c=float(np.min(temperature)),
        temperature_max_c=float(np.max(temperature)),
        moisture_min_kg_kg=float(np.min(moisture)),
        moisture_max_kg_kg=float(np.max(moisture)),
    )
    started = time.perf_counter()

    while current_time < config.max_time_s - 1.0e-9:
        early_stage = current_time < config.transition_time_s - 1.0e-9
        nominal_dt = config.early_dt_s if early_stage else config.late_dt_s
        dt_s = min(nominal_dt, config.max_time_s - current_time)
        if early_stage:
            dt_s = min(dt_s, config.transition_time_s - current_time)
        if next_output > current_time + 1.0e-9:
            dt_s = min(dt_s, next_output - current_time)
        if dt_s <= 1.0e-10:
            raise RuntimeError("时间推进出现非正步长")

        next_time = current_time + dt_s
        next_radius = float(radius_data.radius(next_time))
        geometry = build_geometry(next_radius, config.intervals)
        candidate_temperature, candidate_moisture, step_info = (
            coupled_backward_euler_step(
                geometry,
                params,
                temperature,
                moisture,
                next_time,
                dt_s,
                boundary,
            )
        )
        old_max = float(np.max(moisture))
        new_max = float(np.max(candidate_moisture))
        crossing = (
            old_max > config.threshold_kg_kg
            and new_max <= config.threshold_kg_kg
        )

        if crossing and dt_s > config.final_refine_dt_s + 1.0e-9:
            refined_temperature = temperature.copy()
            refined_moisture = moisture.copy()
            refined_time = current_time
            while refined_time < next_time - 1.0e-10:
                sub_dt = min(
                    config.final_refine_dt_s, next_time - refined_time
                )
                sub_next = refined_time + sub_dt
                sub_radius = float(radius_data.radius(sub_next))
                sub_geometry = build_geometry(sub_radius, config.intervals)
                sub_temperature, sub_moisture, sub_info = (
                    coupled_backward_euler_step(
                        sub_geometry,
                        params,
                        refined_temperature,
                        refined_moisture,
                        sub_next,
                        sub_dt,
                        boundary,
                    )
                )
                previous_max = float(np.max(refined_moisture))
                sub_max = float(np.max(sub_moisture))
                if (
                    previous_max > config.threshold_kg_kg
                    and sub_max <= config.threshold_kg_kg
                ):
                    fraction = (previous_max - config.threshold_kg_kg) / max(
                        previous_max - sub_max, 1.0e-30
                    )
                    fraction = float(np.clip(fraction, 0.0, 1.0))
                    current_time = refined_time + fraction * sub_dt
                    temperature = refined_temperature + fraction * (
                        sub_temperature - refined_temperature
                    )
                    moisture = refined_moisture + fraction * (
                        sub_moisture - refined_moisture
                    )
                    current_radius = float(radius_data.radius(current_time))
                    diagnostics.absorb(sub_info, sub_dt, "refined")
                    break
                diagnostics.absorb(sub_info, sub_dt, "refined")
                refined_time = sub_next
                refined_temperature = sub_temperature
                refined_moisture = sub_moisture
                if math.isclose(refined_time, next_output, abs_tol=1.0e-8):
                    append_output(
                        refined_time,
                        sub_radius,
                        refined_temperature,
                        refined_moisture,
                        output_times,
                        output_radii,
                        output_temperatures,
                        output_moistures,
                    )
                    next_output += config.output_interval_s
            else:
                raise RuntimeError("末端1 s精化未能复现阈值穿越")
            append_output(
                current_time,
                current_radius,
                temperature,
                moisture,
                output_times,
                output_radii,
                output_temperatures,
                output_moistures,
            )
            append_profile(
                current_time,
                current_radius,
                temperature,
                moisture,
                profile_times,
                profile_radii,
                profile_temperatures,
                profile_moistures,
            )
            break

        diagnostics.absorb(
            step_info, dt_s, "early" if early_stage else "late"
        )
        current_time = next_time
        current_radius = next_radius
        temperature = candidate_temperature
        moisture = candidate_moisture

        if math.isclose(current_time, next_output, abs_tol=1.0e-8):
            append_output(
                current_time,
                current_radius,
                temperature,
                moisture,
                output_times,
                output_radii,
                output_temperatures,
                output_moistures,
            )
            next_output += config.output_interval_s

        if math.isclose(current_time, next_paper, abs_tol=1.0e-8):
            append_profile(
                current_time,
                current_radius,
                temperature,
                moisture,
                profile_times,
                profile_radii,
                profile_temperatures,
                profile_moistures,
            )
            next_paper += config.paper_interval_s

        if progress and current_time + 1.0e-9 >= next_progress:
            print(
                f"mode={radius_data.mode}, N={config.intervals}, "
                f"late_dt={config.late_dt_s:g}s, "
                f"t={current_time / SECONDS_PER_HOUR:.1f}h, "
                f"R={current_radius * 100.0:.4f}cm, "
                f"maxC={np.max(moisture):.6f}, "
                f"wall={time.perf_counter() - started:.1f}s",
                flush=True,
            )
            next_progress += config.progress_interval_s

        if float(np.max(moisture)) <= config.threshold_kg_kg:
            append_output(
                current_time,
                current_radius,
                temperature,
                moisture,
                output_times,
                output_radii,
                output_temperatures,
                output_moistures,
            )
            append_profile(
                current_time,
                current_radius,
                temperature,
                moisture,
                profile_times,
                profile_radii,
                profile_temperatures,
                profile_moistures,
            )
            break
    else:
        raise RuntimeError(
            f"计算至{config.max_time_s / SECONDS_PER_HOUR:.1f} h仍未达到"
            f"C<={config.threshold_kg_kg:g}；maxC={np.max(moisture):.6f}"
        )

    maximum_index = int(np.argmax(moisture))
    completion_nodes = np.linspace(0.0, current_radius, node_count)
    payload = diagnostics.as_dict()
    payload.update(
        {
            "config": asdict(config),
            "nodes": node_count,
            "initial_dr_m": INITIAL_RADIUS_M / config.intervals,
            "completion_dr_m": current_radius / config.intervals,
            "completion_time_s": float(current_time),
            "completion_time_h": float(current_time / SECONDS_PER_HOUR),
            "completion_radius_cm": float(current_radius * 100.0),
            "radius_ratio_at_completion": float(
                current_radius / INITIAL_RADIUS_M
            ),
            "maximum_moisture_at_completion_kg_kg": float(np.max(moisture)),
            "minimum_moisture_at_completion_kg_kg": float(np.min(moisture)),
            "maximum_location_at_completion_cm": float(
                completion_nodes[maximum_index] * 100.0
            ),
            "all_nodes_at_or_below_threshold": bool(
                np.all(moisture <= config.threshold_kg_kg + 5.0e-10)
            ),
            "radius_data_end_time_h": float(radius_data.time_s[-1] / 3600.0),
            "radius_extrapolation_used": bool(
                current_time > radius_data.time_s[-1] + 1.0e-9
                and radius_data.mode == "measured"
            ),
            "plateau_temperature_c": boundary.plateau_temperature_c,
            "plateau_temperature_std_c": boundary.plateau_temperature_std_c,
            "plateau_moisture_kg_kg": boundary.plateau_moisture_kg_kg,
            "plateau_moisture_std_kg_kg": boundary.plateau_moisture_std_kg_kg,
            "runtime_s": time.perf_counter() - started,
            "stored_output_rows": len(output_times),
            "stored_fixed_radii": len(FIXED_OUTPUT_RADII_M),
            "surface_column_included": True,
            "latent_heat_included": False,
            "axial_shrinkage_included": False,
        }
    )
    return Q4Solution(
        times_s=np.asarray(output_times),
        radius_history_m=np.asarray(output_radii),
        temperature_output_c=np.asarray(output_temperatures),
        moisture_output_kg_kg=np.asarray(output_moistures),
        profile_times_s=np.asarray(profile_times),
        profile_radius_m=np.asarray(profile_radii),
        profile_temperature_c=np.asarray(profile_temperatures),
        profile_moisture_kg_kg=np.asarray(profile_moistures),
        completion_time_s=float(current_time),
        completion_radius_m=float(current_radius),
        completion_temperature_nodes_c=temperature.copy(),
        completion_moisture_nodes_kg_kg=moisture.copy(),
        completion_radius_nodes_m=completion_nodes,
        diagnostics=payload,
    )


def write_csv(
    path: Path, headers: Iterable[str], rows: Iterable[Iterable[object]]
) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(list(headers))
        writer.writerows(rows)


def numeric_or_blank(value: float) -> float | str:
    return "" if not np.isfinite(value) else float(value)


def output_headers() -> list[str]:
    fixed = [f"r_{radius * 100.0:.1f}_cm" for radius in FIXED_OUTPUT_RADII_M]
    return fixed + ["surface"]


def row_at_time(solution: Q4Solution, target_time_s: float) -> int:
    index = int(np.argmin(np.abs(solution.times_s - target_time_s)))
    if not math.isclose(
        float(solution.times_s[index]), target_time_s, abs_tol=1.0e-6
    ):
        raise ValueError(f"输出中缺少目标时刻{target_time_s:g} s")
    return index


def write_outputs(
    output_dir: Path,
    solution: Q4Solution,
    boundary: ExtendedBoundary,
    radius_data: RadiusData,
    config: Q4Config,
    params: Q4Parameters,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    headers = output_headers()
    result_rows = []
    temperature_rows = []
    for row_index, time_s in enumerate(solution.times_s):
        result_rows.append(
            [float(time_s)]
            + [numeric_or_blank(value) for value in solution.moisture_output_kg_kg[row_index]]
        )
        temperature_rows.append(
            [float(time_s)]
            + [numeric_or_blank(value) for value in solution.temperature_output_c[row_index]]
        )
    write_csv(
        output_dir / "result4_moisture.csv",
        ["time_s", *headers],
        result_rows,
    )
    write_csv(
        output_dir / "question4_temperature_history.csv",
        ["time_s", *headers],
        temperature_rows,
    )
    write_csv(
        output_dir / "question4_radius_history.csv",
        ["time_s", "time_h", "radius_cm", "radius_ratio"],
        (
            [time_s, time_s / 3600.0, radius_m * 100.0, radius_m / INITIAL_RADIUS_M]
            for time_s, radius_m in zip(
                solution.times_s, solution.radius_history_m
            )
        ),
    )

    paper_times = list(
        np.arange(
            config.paper_interval_s,
            solution.completion_time_s - 1.0e-8,
            config.paper_interval_s,
        )
    )
    paper_times.append(solution.completion_time_s)
    paper_rows: list[list[object]] = []
    for time_s in paper_times:
        index = row_at_time(solution, float(time_s))
        values = solution.moisture_output_kg_kg[index]
        fixed_indices = [0, 5, 10, 15, 20]
        paper_rows.append(
            [
                float(time_s),
                float(time_s / 3600.0),
                int(math.isclose(time_s, solution.completion_time_s, abs_tol=1.0e-6)),
                float(solution.radius_history_m[index] * 100.0),
                *[numeric_or_blank(values[i]) for i in fixed_indices],
                float(values[-1]),
            ]
        )
    write_csv(
        output_dir / "question4_table6.csv",
        [
            "time_s",
            "time_h",
            "is_completion_time",
            "surface_radius_cm",
            "r_0.0_cm",
            "r_0.5_cm",
            "r_1.0_cm",
            "r_1.5_cm",
            "r_2.0_cm",
            "surface",
        ],
        paper_rows,
    )

    profile_rows: list[list[float]] = []
    for time_index, time_s in enumerate(solution.profile_times_s):
        for radius_m, temperature_c, moisture_value in zip(
            solution.profile_radius_m[time_index],
            solution.profile_temperature_c[time_index],
            solution.profile_moisture_kg_kg[time_index],
        ):
            profile_rows.append(
                [
                    float(time_s),
                    float(time_s / 3600.0),
                    float(radius_m * 100.0),
                    float(radius_m / solution.radius_history_m[row_at_time(solution, float(time_s))]),
                    float(temperature_c),
                    float(moisture_value),
                ]
            )
    write_csv(
        output_dir / "question4_radial_profiles.csv",
        [
            "time_s",
            "time_h",
            "radius_cm",
            "xi",
            "temperature_c",
            "moisture_kg_kg",
        ],
        profile_rows,
    )

    history_rows = []
    stride = max(1, int(round(600.0 / config.output_interval_s)))
    selected_indices = list(range(0, len(solution.times_s), stride))
    if selected_indices[-1] != len(solution.times_s) - 1:
        selected_indices.append(len(solution.times_s) - 1)
    for index in selected_indices:
        values = solution.moisture_output_kg_kg[index]
        temperatures = solution.temperature_output_c[index]
        history_rows.append(
            [
                float(solution.times_s[index]),
                float(solution.times_s[index] / 3600.0),
                float(solution.radius_history_m[index] * 100.0),
                float(temperatures[0]),
                float(temperatures[-1]),
                float(values[0]),
                numeric_or_blank(values[5]),
                numeric_or_blank(values[10]),
                float(values[-1]),
                float(np.nanmax(values)),
            ]
        )
    write_csv(
        output_dir / "question4_plot_history.csv",
        [
            "time_s",
            "time_h",
            "radius_cm",
            "temperature_center_c",
            "temperature_surface_c",
            "moisture_center_kg_kg",
            "moisture_r0.5_kg_kg",
            "moisture_r1.0_kg_kg",
            "moisture_surface_kg_kg",
            "maximum_moisture_kg_kg",
        ],
        history_rows,
    )

    boundary_times = np.arange(
        0.0,
        solution.completion_time_s + config.output_interval_s,
        config.output_interval_s,
    )
    boundary_times = boundary_times[boundary_times <= solution.completion_time_s + 1.0e-8]
    if not math.isclose(
        float(boundary_times[-1]), solution.completion_time_s, abs_tol=1.0e-8
    ):
        boundary_times = np.append(boundary_times, solution.completion_time_s)
    write_csv(
        output_dir / "question4_boundary_and_radius.csv",
        [
            "time_s",
            "time_h",
            "ambient_temperature_c",
            "ambient_moisture_kg_kg",
            "radius_cm",
        ],
        (
            [
                float(time_s),
                float(time_s / 3600.0),
                float(boundary.temperature(time_s)),
                float(boundary.moisture(time_s)),
                float(radius_data.radius(time_s) * 100.0),
            ]
            for time_s in boundary_times
        ),
    )

    summary = {
        "main_result": {
            "drying_completion_time_s": solution.completion_time_s,
            "drying_completion_time_h": solution.completion_time_s / 3600.0,
            "drying_completion_time_d": solution.completion_time_s / 86400.0,
            "completion_radius_cm": solution.completion_radius_m * 100.0,
            "radius_reduction_percent": (
                1.0 - solution.completion_radius_m / INITIAL_RADIUS_M
            )
            * 100.0,
            "center_moisture_at_completion_kg_kg": float(
                solution.completion_moisture_nodes_kg_kg[0]
            ),
            "surface_moisture_at_completion_kg_kg": float(
                solution.completion_moisture_nodes_kg_kg[-1]
            ),
        },
        "model_and_assumptions": {
            "coordinate": "material coordinate xi=r/R(t)",
            "space": "node-centered conservative finite volume",
            "time": "backward Euler with piecewise fixed step",
            "nonlinear_solver": "coupled Picard iteration",
            "properties": "A题附录4",
            "radius": "附件2线性插值" if radius_data.mode == "measured" else radius_data.mode,
            "boundary_extension": (
                "附件1最后稳定时间窗均值"
                if boundary.plateau_mode == "window-mean"
                else "附件1末点保持"
            ),
            "latent_heat_included": False,
            "axial_shrinkage_included": False,
        },
        "parameters": asdict(params),
        "boundary_extension": {
            "plateau_mode": boundary.plateau_mode,
            "plateau_window_s": boundary.plateau_window_s,
            "plateau_temperature_c": boundary.plateau_temperature_c,
            "plateau_temperature_std_c": boundary.plateau_temperature_std_c,
            "plateau_moisture_kg_kg": boundary.plateau_moisture_kg_kg,
            "plateau_moisture_std_kg_kg": boundary.plateau_moisture_std_kg_kg,
        },
        "radius_data": {
            "measurement_count": int(len(radius_data.time_s)),
            "start_time_s": float(radius_data.time_s[0]),
            "end_time_s": float(radius_data.time_s[-1]),
            "initial_radius_cm": float(radius_data.measured_radius_m[0] * 100.0),
            "last_measured_radius_cm": float(radius_data.measured_radius_m[-1] * 100.0),
            "monotone_nonincreasing": bool(
                np.all(np.diff(radius_data.measured_radius_m) <= 1.0e-12)
            ),
            "mode": radius_data.mode,
            "extrapolation": radius_data.extrapolation,
        },
        "diagnostics": solution.diagnostics,
        "validation": {},
        "interpretation": (
            "烘干结束定义为移动药材域内全部节点含水率首次不高于"
            f"{config.threshold_kg_kg:g} kg/kg。计算网格固定在材料坐标xi上，"
            "实际半径由附件2驱动。"
        ),
    }
    with (output_dir / "question4_summary.json").open(
        "w", encoding="utf-8"
    ) as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="问题4收缩圆柱有限体积求解器")
    parser.add_argument(
        "--input",
        type=Path,
        default=SCRIPT_DIR / "附件1.xlsx",
        help="附件1路径；默认读取脚本同目录下的附件1.xlsx",
    )
    parser.add_argument(
        "--radius-input",
        type=Path,
        default=SCRIPT_DIR / "附件2.xlsx",
        help="附件2路径；默认读取脚本同目录下的附件2.xlsx",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "question4_results",
        help="输出目录；默认写入脚本同目录的question4_results",
    )
    parser.add_argument("--intervals", type=int, default=640)
    parser.add_argument("--threshold", type=float, default=0.15)
    parser.add_argument("--heat-transfer", type=float, default=25.0)
    parser.add_argument("--mass-transfer", type=float, default=8.0e-7)
    parser.add_argument("--early-dt", type=float, default=1.0)
    parser.add_argument("--late-dt", type=float, default=30.0)
    parser.add_argument("--transition-time", type=float, default=14400.0)
    parser.add_argument("--plateau-window", type=float, default=3600.0)
    parser.add_argument(
        "--plateau-mode",
        choices=("window-mean", "last-point"),
        default="window-mean",
    )
    parser.add_argument(
        "--radius-mode",
        choices=("measured", "fixed-initial", "fixed-final"),
        default="measured",
    )
    parser.add_argument("--max-time", type=float, default=604800.0)
    parser.add_argument("--progress", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    input_path = args.input.expanduser().resolve()
    radius_input_path = args.radius_input.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    config = Q4Config(
        intervals=args.intervals,
        threshold_kg_kg=args.threshold,
        transition_time_s=args.transition_time,
        plateau_window_s=args.plateau_window,
        plateau_mode=args.plateau_mode,
        early_dt_s=args.early_dt,
        late_dt_s=args.late_dt,
        max_time_s=args.max_time,
        radius_mode=args.radius_mode,
    )
    params = Q4Parameters(
        heat_transfer_w_m2_k=args.heat_transfer,
        mass_transfer_m_s=args.mass_transfer,
    )
    source_boundary = read_boundary_data(input_path, config.transition_time_s)
    boundary = build_extended_boundary(source_boundary, config)
    radius_data = read_radius_data(
        radius_input_path,
        mode=config.radius_mode,
        extrapolation=config.radius_extrapolation,
    )
    print(
        f"问题4求解：mode={config.radius_mode}, N={config.intervals}, "
        f"early_dt={config.early_dt_s:g}s, late_dt={config.late_dt_s:g}s, "
        f"plateau T={boundary.plateau_temperature_c:.6f}°C, "
        f"plateau C={boundary.plateau_moisture_kg_kg:.8f}",
        flush=True,
    )
    solution = solve_case(
        boundary, radius_data, config, params=params, progress=args.progress
    )
    write_outputs(output_dir, solution, boundary, radius_data, config, params)
    print(
        json.dumps(
            {
                "drying_completion_time_s": solution.completion_time_s,
                "drying_completion_time_h": solution.completion_time_s / 3600.0,
                "drying_completion_time_d": solution.completion_time_s / 86400.0,
                "completion_radius_cm": solution.completion_radius_m * 100.0,
                "center_moisture_kg_kg": float(
                    solution.completion_moisture_nodes_kg_kg[0]
                ),
                "surface_moisture_kg_kg": float(
                    solution.completion_moisture_nodes_kg_kg[-1]
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
