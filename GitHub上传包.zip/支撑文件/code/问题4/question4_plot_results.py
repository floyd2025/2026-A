#!/usr/bin/env python3
"""按 SciPilot Figure 工作流生成问题4论文图。"""

from __future__ import annotations

import argparse
import csv
import json
import os
import tempfile
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "cumcm_q4_mplconfig")
)

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from PIL import Image


COLORS = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#111111"]
LINE_STYLES = ["-", "--", "-.", ":", (0, (5, 2)), (0, (2, 1))]
MARKERS = ["o", "s", "^", "D", "v", "P"]


def setup_style(**_: object) -> dict[str, str]:
    """配置仅依赖Matplotlib的中文论文绘图样式。"""
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    candidates = [
        "Noto Serif CJK SC",
        "Source Han Serif SC",
        "SimSun",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Microsoft YaHei",
        "SimHei",
    ]
    selected = next((name for name in candidates if name in available), None)
    if selected is None:
        raise RuntimeError(
            "未检测到中文字体；请安装Noto Serif CJK SC、宋体、微软雅黑或黑体。"
        )
    mpl.rcParams.update(
        {
            "font.family": selected,
            "mathtext.fontset": "stix",
            "axes.unicode_minus": False,
            "font.size": 9,
            "axes.labelsize": 9.5,
            "axes.titlesize": 10,
            "xtick.labelsize": 8.5,
            "ytick.labelsize": 8.5,
            "legend.fontsize": 8,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "figure.constrained_layout.use": True,
        }
    )
    return {"font": selected, "palette": "Okabe-Ito", "raster_dpi": "600"}


def render_preview(fig: plt.Figure, path: str, dpi: int = 180) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=dpi, bbox_inches="tight", pad_inches=0.06)


def audit_layout(fig: plt.Figure) -> list[dict[str, str]]:
    """检查可见文字是否超出画布；返回可JSON序列化的问题清单。"""
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    issues: list[dict[str, str]] = []
    artists: list[mpl.text.Text] = []
    for ax in fig.axes:
        artists.extend([ax.title, ax.xaxis.label, ax.yaxis.label])
        artists.extend(ax.texts)
        legend = ax.get_legend()
        if legend is not None:
            artists.extend(legend.get_texts())
    for artist in artists:
        if not artist.get_visible() or not artist.get_text().strip():
            continue
        box = artist.get_window_extent(renderer=renderer)
        if box.x0 < -2 or box.y0 < -2 or box.x1 > width + 2 or box.y1 > height + 2:
            issues.append({"severity": "FAIL", "message": f"文字可能被裁切：{artist.get_text()}"})
    return issues


def print_layout_report(issues: list[dict[str, str]]) -> str:
    verdict = "FAIL" if any(item["severity"] == "FAIL" for item in issues) else "PASS"
    print(f"版面自检：{verdict}")
    for item in issues:
        print(f"  [{item['severity']}] {item['message']}")
    return verdict


def export_figure(
    fig: plt.Figure,
    basename: str,
    formats: tuple[str, ...],
    dpi: int,
    size_inches: tuple[float, float],
    grayscale_preview: bool,
    pad_inches: float,
) -> list[str]:
    """导出矢量图、600 dpi位图及灰度检查版。"""
    fig.set_size_inches(*size_inches)
    base = Path(basename)
    base.parent.mkdir(parents=True, exist_ok=True)
    exported: list[str] = []
    for suffix in formats:
        destination = base.with_suffix(f".{suffix}")
        options: dict[str, object] = {
            "bbox_inches": "tight",
            "pad_inches": pad_inches,
        }
        if suffix.lower() in {"png", "tif", "tiff"}:
            options["dpi"] = dpi
        fig.savefig(destination, **options)
        exported.append(str(destination))
    if grayscale_preview:
        png_path = base.with_suffix(".png")
        gray_path = base.parent / f"{base.name}_grayscale.png"
        with Image.open(png_path) as image:
            image.convert("L").save(gray_path, dpi=(dpi, dpi))
        exported.append(str(gray_path))
    return exported


def check_figure(path: str, min_dpi: int = 300) -> tuple[list[tuple[str, str]], dict]:
    """对导出文件做存在性、非空和位图DPI检查。"""
    figure_path = Path(path)
    issues: list[tuple[str, str]] = []
    info: dict[str, object] = {
        "path": str(figure_path),
        "size_bytes": figure_path.stat().st_size if figure_path.exists() else 0,
    }
    if not figure_path.exists() or figure_path.stat().st_size == 0:
        issues.append(("FAIL", "文件不存在或为空"))
        return issues, info
    if figure_path.suffix.lower() in {".png", ".tif", ".tiff"}:
        with Image.open(figure_path) as image:
            dpi = image.info.get("dpi", (0.0, 0.0))
            info.update({"pixels": image.size, "dpi": dpi})
            if min(float(dpi[0]), float(dpi[1])) < min_dpi - 1.0:
                issues.append(("FAIL", f"位图DPI低于{min_dpi}：{dpi}"))
    return issues, info


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="绘制问题4论文图")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=SCRIPT_DIR / "question4_final",
        help="问题4最终数据目录",
    )
    parser.add_argument(
        "--work-dir",
        type=Path,
        default=SCRIPT_DIR / "work",
        help="保留此参数以兼容原运行命令",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "question4_figures",
        help="论文图输出目录",
    )
    return parser.parse_args()


def read_numeric_csv(path: Path) -> dict[str, np.ndarray]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"绘图源数据为空：{path}")
    return {
        key: np.asarray(
            [float(row[key]) if row[key].strip() else np.nan for row in rows],
            dtype=float,
        )
        for key in rows[0]
    }


def style_axes(ax: plt.Axes) -> None:
    ax.grid(color="#D8D8D8", linewidth=0.55, alpha=0.7)
    ax.tick_params(direction="out", length=3.0, width=0.7)
    ax.margins(x=0.02)


def save_figure(
    fig: plt.Figure,
    output_dir: Path,
    name: str,
    claim: str,
    manifest: list[dict],
    size: tuple[float, float],
) -> None:
    fig.set_size_inches(*size)
    fig.canvas.draw()
    preview = output_dir / "_qa_previews" / f"{name}_preview.png"
    render_preview(fig, str(preview), dpi=180)
    issues = audit_layout(fig)
    verdict = print_layout_report(issues)
    if verdict == "FAIL":
        raise RuntimeError(f"{name}版面自检失败")
    exported = export_figure(
        fig,
        basename=str(output_dir / name),
        formats=("pdf", "svg", "png", "tiff"),
        dpi=600,
        size_inches=size,
        grayscale_preview=True,
        pad_inches=0.06,
    )
    manifest.append(
        {
            "name": name,
            "claim": claim,
            "preview": str(preview),
            "layout_verdict": verdict,
            "layout_issues": issues,
            "exported": exported,
        }
    )
    plt.close(fig)


def plot_conditions(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    fig, axes = plt.subplots(3, 1, sharex=True)
    time_h = data["time_h"]
    axes[0].plot(time_h, data["radius_cm"], color=COLORS[0], lw=1.5)
    axes[0].scatter(time_h[::30], data["radius_cm"][::30], color=COLORS[0], s=10)
    axes[0].set_ylabel("半径 / cm")
    axes[0].set_ylim(1.15, 2.05)
    axes[0].set_title("(a) 附件2驱动的收缩半径")
    axes[1].plot(time_h, data["ambient_temperature_c"], color=COLORS[3], lw=1.3)
    axes[1].set_ylabel("外界温度 / °C")
    axes[1].set_title("(b) 温度边界")
    axes[2].plot(time_h, data["ambient_moisture_kg_kg"], color=COLORS[2], lw=1.3)
    axes[2].set_ylabel("$C_\\infty$ / (kg/kg)")
    axes[2].set_title("(c) 水分边界")
    axes[2].set_xlabel("时间 / h")
    for ax in axes:
        ax.axvline(4.0, color="#777777", ls="--", lw=0.9)
        style_axes(ax)
    axes[0].annotate(
        "附件1结束",
        xy=(4.0, float(np.interp(4.0, time_h, data["radius_cm"]))),
        xytext=(15, 12),
        textcoords="offset points",
        arrowprops={"arrowstyle": "->", "lw": 0.7},
    )
    save_figure(
        fig,
        out,
        "q4_boundary_and_radius",
        "药材半径在前期快速收缩并于约36 h稳定在1.2 cm，附件1结束后边界进入稳定阶段",
        manifest,
        (7.2, 6.5),
    )


def plot_history(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    fig, ax = plt.subplots()
    series = [
        ("moisture_center_kg_kg", "中心"),
        ("moisture_r0.5_kg_kg", "r=0.5 cm"),
        ("moisture_r1.0_kg_kg", "r=1.0 cm"),
        ("moisture_surface_kg_kg", "瞬时表面"),
    ]
    for index, (key, label) in enumerate(series):
        ax.plot(
            data["time_h"], data[key], color=COLORS[index],
            ls=LINE_STYLES[index], lw=1.4, label=label,
        )
    completion = float(data["time_h"][-1])
    ax.axhline(0.15, color="#111111", ls=(0, (3, 2)), lw=1.0, label="终止阈值 0.15")
    ax.axvline(completion, color="#777777", ls=":", lw=1.0)
    ax.annotate(
        f"全域达标：{completion:.3f} h",
        xy=(completion, 0.15), xytext=(-120, 36), textcoords="offset points",
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": "#444444"},
    )
    ax.set_xlabel("时间 / h")
    ax.set_ylabel("C / (kg/kg)")
    ax.set_xlim(0.0, completion * 1.02)
    ax.set_ylim(0.0, 2.68)
    ax.legend(ncol=2, loc="upper right")
    ax.set_title("收缩药材典型位置的含水率演化")
    style_axes(ax)
    save_figure(
        fig,
        out,
        "q4_moisture_history",
        "表面先干、中心最慢，中心在51.120 h最后达到0.15并控制烘干终点",
        manifest,
        (7.2, 4.1),
    )


def plot_moisture_field(
    data: dict[str, np.ndarray],
    radius_data: dict[str, np.ndarray],
    out: Path,
    manifest: list[dict],
) -> None:
    radius_keys = [key for key in data if key.startswith("r_") and key.endswith("_cm")]
    radii = np.asarray([float(key[2:-3]) for key in radius_keys])
    values = np.column_stack([data[key] for key in radius_keys])
    time_h = data["time_s"] / 3600.0
    fig, ax = plt.subplots()
    mesh = ax.pcolormesh(
        time_h,
        radii,
        np.ma.masked_invalid(values.T),
        shading="auto",
        cmap="cividis",
        vmin=0.05,
        vmax=2.55,
    )
    radius_curve = np.interp(
        time_h, radius_data["time_h"], radius_data["radius_cm"]
    )
    ax.plot(time_h, radius_curve, color="white", lw=1.4, ls="--", label="瞬时外边界")
    ax.set_xlabel("时间 / h")
    ax.set_ylabel("物理半径 r / cm")
    ax.set_xlim(0.0, float(time_h[-1]))
    ax.set_ylim(0.0, 2.0)
    ax.set_title("收缩域内干基含水率时空分布")
    colorbar = fig.colorbar(mesh, ax=ax, pad=0.02)
    colorbar.set_label("C / (kg/kg)")
    ax.legend(loc="upper right")
    save_figure(
        fig,
        out,
        "q4_moisture_field",
        "白色边界内的水分由表及里下降，收缩使有效扩散距离由2.0 cm降至约1.2 cm",
        manifest,
        (7.2, 4.2),
    )


def plot_profiles(data: dict[str, np.ndarray], out: Path, manifest: list[dict]) -> None:
    times = np.unique(data["time_h"])
    selected = [value for value in times if value in {6.0, 12.0, 24.0, 36.0, 48.0}]
    selected.append(float(times[-1]))
    fig, ax = plt.subplots()
    for index, time_h in enumerate(selected):
        mask = np.isclose(data["time_h"], time_h, atol=1e-8)
        label = "终止时刻" if index == len(selected) - 1 else f"{time_h:.0f} h"
        ax.plot(
            data["radius_cm"][mask], data["moisture_kg_kg"][mask],
            color=COLORS[index], ls=LINE_STYLES[index], marker=MARKERS[index],
            markevery=8, ms=3.2, markerfacecolor="white", lw=1.25, label=label,
        )
    ax.axhline(0.15, color="#555555", ls=(0, (3, 2)), lw=1.0, label="终止阈值")
    ax.set_xlabel("物理半径 r / cm")
    ax.set_ylabel("C / (kg/kg)")
    ax.set_xlim(0.0, 1.42)
    ax.set_ylim(0.0, 1.82)
    ax.legend(ncol=2, loc="upper right")
    ax.set_title("移动物理域上的径向含水率剖面")
    style_axes(ax)
    save_figure(
        fig,
        out,
        "q4_radial_moisture_profiles",
        "各剖面右端随半径收缩左移，终止时中心恰达阈值而其余位置均已低于阈值",
        manifest,
        (7.2, 4.2),
    )


def plot_validation(
    convergence: dict[str, np.ndarray], validation: dict, out: Path, manifest: list[dict]
) -> None:
    fig, axes = plt.subplots(2, 2)
    x = convergence["intervals"]
    y = convergence["completion_time_h"]
    axes[0, 0].plot(x, y, color=COLORS[0], marker="o", lw=1.25)
    axes[0, 0].set_xscale("log", base=2)
    axes[0, 0].set_xticks(x, [f"{int(value)}" for value in x])
    axes[0, 0].set_xlabel("径向区间数 N")
    axes[0, 0].set_ylabel("结束时间 / h")
    axes[0, 0].set_title("(a) 空间收敛")
    axes[0, 0].text(0.97, 0.91, "观测阶次 2.133", transform=axes[0, 0].transAxes, ha="right")

    temporal = validation["temporal_convergence_n640"]
    dt = np.asarray([15.0, 30.0, 60.0])
    ty = np.asarray([temporal["completion_time_h_by_late_dt_s"][str(int(v))] for v in dt])
    axes[0, 1].plot(dt, ty, color=COLORS[1], marker="s", lw=1.25)
    axes[0, 1].set_xlabel("后期时间步长 / s")
    axes[0, 1].set_ylabel("结束时间 / h")
    axes[0, 1].set_title("(b) 时间收敛（N=640）")
    axes[0, 1].text(0.04, 0.91, "观测阶次 1.000", transform=axes[0, 1].transAxes)

    radius_test = validation["moving_boundary_necessity_n320"]
    radius_values = [
        radius_test["measured_radius_completion_time_h"],
        radius_test["fixed_initial_radius_completion_time_h"],
    ]
    for pos, value, color in zip([0, 1], radius_values, [COLORS[2], COLORS[3]]):
        axes[1, 0].vlines(pos, 0.0, value, color=color, lw=2.0)
        axes[1, 0].scatter(pos, value, color=color, s=42, zorder=3)
        shift = 12 if pos == 0 else -12
        align = "left" if pos == 0 else "right"
        axes[1, 0].annotate(f"{value:.1f} h", (pos, value), xytext=(shift, 5), textcoords="offset points", ha=align)
    axes[1, 0].set_xticks([0, 1], ["动态半径", "固定2 cm"])
    axes[1, 0].set_ylabel("结束时间 / h")
    axes[1, 0].set_ylim(0.0, 145.0)
    axes[1, 0].set_title("(c) 收缩效应（N=320）")

    sensitivity = validation["borrowed_parameter_sensitivity"]
    boundary = validation["boundary_extension_sensitivity_n320"]
    values = [
        sensitivity["mass_transfer_n320"]["minus_20_percent_relative_change_percent"],
        sensitivity["mass_transfer_n320"]["plus_20_percent_relative_change_percent"],
        sensitivity["heat_transfer_n160"]["minus_20_percent_relative_change_percent"],
        sensitivity["heat_transfer_n160"]["plus_20_percent_relative_change_percent"],
        -boundary["relative_difference_percent"],
    ]
    labels = ["hm: -20%", "hm: +20%", "h: -20%", "h: +20%", "边界末点"]
    positions = np.arange(len(values))
    axes[1, 1].axhline(0.0, color="#777777", lw=0.8)
    axes[1, 1].scatter(positions, values, color=COLORS[:5], s=38, zorder=3)
    for pos, value in zip(positions, values):
        offset_y = 6 if value >= 0 else -13
        offset_x = 12 if pos == 0 else 0
        align = "left" if pos == 0 else "center"
        axes[1, 1].annotate(f"{value:+.2f}%", (pos, value), xytext=(offset_x, offset_y), textcoords="offset points", ha=align)
    axes[1, 1].set_xticks(positions, labels, rotation=20, ha="right")
    axes[1, 1].set_ylabel("相对基准变化 / %")
    axes[1, 1].set_ylim(-1.1, 1.7)
    axes[1, 1].set_title("(d) 参数与延拓敏感性")
    for ax in axes.flat:
        style_axes(ax)
    save_figure(
        fig,
        out,
        "q4_validation",
        "格式分别达到二阶空间和一阶时间收敛；收缩效应远大于数值与借用参数的不确定性",
        manifest,
        (8.4, 6.4),
    )


def main() -> int:
    args = parse_args()
    data_dir = args.data_dir.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    if not data_dir.is_dir():
        raise FileNotFoundError(f"找不到问题4数据目录：{data_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_info = setup_style(
        journal="general", lang="zh", use_sciplots=False, constrained_layout=True
    )
    mpl.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "axes.titleweight": "semibold",
        }
    )
    validation = json.loads(
        (data_dir / "question4_validation_final.json").read_text(encoding="utf-8")
    )
    manifest: list[dict] = []
    plot_conditions(read_numeric_csv(data_dir / "question4_boundary_and_radius.csv"), output_dir, manifest)
    plot_history(read_numeric_csv(data_dir / "question4_plot_history.csv"), output_dir, manifest)
    boundary_radius = read_numeric_csv(data_dir / "question4_boundary_and_radius.csv")
    plot_moisture_field(
        read_numeric_csv(data_dir / "result4_moisture.csv"),
        boundary_radius,
        output_dir,
        manifest,
    )
    plot_profiles(read_numeric_csv(data_dir / "question4_radial_profiles.csv"), output_dir, manifest)
    plot_validation(
        read_numeric_csv(data_dir / "question4_completion_convergence.csv"),
        validation,
        output_dir,
        manifest,
    )

    compliance = []
    for figure in manifest:
        for path in figure["exported"]:
            issues, info = check_figure(path, min_dpi=300)
            compliance.append(
                {
                    "path": path,
                    "issues": issues,
                    "info": info,
                    "has_failure": any(level == "FAIL" for level, _ in issues),
                }
            )
    failures = [item for item in compliance if item["has_failure"]]
    if failures:
        raise RuntimeError(f"{len(failures)}个图文件未通过格式/DPI/字体审计")
    (output_dir / "figure_manifest.json").write_text(
        json.dumps(
            {
                "style": setup_info,
                "figures": manifest,
                "compliance_audit": compliance,
                "compliance_failures": len(failures),
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )
    print(f"共生成{len(manifest)}张问题4论文图：{output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
