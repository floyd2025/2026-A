
"""CUMCM A题问题1：圆柱药材温度与水分场数值求解。

空间离散：节点型守恒有限体积法（默认80个区间、81个节点）
时间离散：后向欧拉（默认1 s）
温度方程：固定三对角线性方程组，预分解后逐步求解
水分方程：Picard迭代更新非线性扩散系数

示例：
    python question1_fvm_backward_euler.py --input 附件1.xlsx --output-dir q1_output

依赖：numpy, openpyxl, pillow
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill


@dataclass(frozen=True)
class ModelParameters:
    radius_m: float = 0.02
    density_kg_m3: float = 820.0
    heat_capacity_j_kg_k: float = 2600.0
    thermal_conductivity_w_m_k: float = 0.36
    heat_transfer_w_m2_k: float = 25.0
    mass_transfer_m_s: float = 8.0e-7
    initial_temperature_c: float = 28.0
    initial_moisture_kg_kg: float = 2.55
    end_time_s: float = 1800.0
    intervals: int = 80
    time_step_s: float = 1.0
    picard_tolerance: float = 1.0e-10
    picard_residual_tolerance: float = 1.0e-10
    picard_max_iterations: int = 50
    picard_relaxation: float = 1.0


@dataclass
class BoundaryData:
    time_s: np.ndarray
    temperature_c: np.ndarray
    moisture_kg_kg: np.ndarray

    def temperature(self, time_s: float | np.ndarray) -> float | np.ndarray:
        return np.interp(time_s, self.time_s, self.temperature_c)

    def moisture(self, time_s: float | np.ndarray) -> float | np.ndarray:
        return np.interp(time_s, self.time_s, self.moisture_kg_kg)


@dataclass
class Geometry:
    radius_nodes_m: np.ndarray
    cell_volumes_m2: np.ndarray
    internal_face_areas_m: np.ndarray
    surface_area_m: float
    dr_m: float


@dataclass
class Solution:
    times_s: np.ndarray
    radius_nodes_m: np.ndarray
    temperature_c: np.ndarray
    moisture_kg_kg: np.ndarray
    diagnostics: dict


REPORT_TIMES_S = np.array([100, 300, 600, 900, 1200, 1500, 1800], dtype=float)
REPORT_RADII_M = np.array([0.0, 0.005, 0.010, 0.015, 0.020], dtype=float)
OUTPUT_RADII_M = np.linspace(0.0, 0.020, 21)


def parse_args() -> argparse.Namespace:
    from q3_paths import package_path
    parser = argparse.ArgumentParser(description="A题问题1有限体积-后向欧拉求解器")
    parser.add_argument("--input", type=package_path, default=package_path("附件1.xlsx"), help="附件1.xlsx路径，相对路径以代码文件夹为基准")
    parser.add_argument("--output-dir", type=package_path, default=package_path("q1_output"), help="输出目录")
    parser.add_argument("--intervals", type=int, default=80, help="径向区间数；80对应81个节点")
    parser.add_argument("--dt", type=float, default=1.0, help="后向欧拉时间步长/s")
    parser.add_argument("--skip-validation", action="store_true", help="跳过网格与时间步加密验证")
    parser.add_argument("--no-plots", action="store_true", help="不生成PNG诊断图")
    return parser.parse_args()


def read_boundary_data(path: Path, end_time_s: float) -> BoundaryData:
    if not path.exists():
        raise FileNotFoundError(f"找不到输入文件：{path}")

    workbook = load_workbook(path, data_only=True, read_only=True)
    worksheet = workbook.active
    raw_rows = list(worksheet.iter_rows(min_row=2, max_col=3, values_only=True))
    workbook.close()
    if not raw_rows:
        raise ValueError("附件1没有数据行")

    data = np.asarray(raw_rows, dtype=float)
    if data.ndim != 2 or data.shape[1] != 3:
        raise ValueError("附件1必须包含时间、温度、水分浓度三列")
    if not np.all(np.isfinite(data)):
        raise ValueError("附件1前三列存在缺失值或非数值")

    time_s, temperature_c, moisture = data.T
    if np.any(np.diff(time_s) <= 0):
        raise ValueError("附件1时间列必须严格递增且不得重复")
    if time_s[0] > 0 or time_s[-1] < end_time_s:
        raise ValueError(f"附件1必须覆盖0至{end_time_s:g} s")
    if temperature_c.min() < -100 or temperature_c.max() > 200:
        raise ValueError("附件1温度超出预期范围，请检查单位是否为摄氏度")
    if np.any(moisture < 0):
        raise ValueError("附件1水分浓度不得为负")

    mask = time_s <= end_time_s
    if time_s[mask][-1] < end_time_s:
        raise ValueError(f"附件1在{end_time_s:g} s处缺少可用边界数据")
    return BoundaryData(time_s[mask], temperature_c[mask], moisture[mask])


def build_geometry(radius_m: float, intervals: int) -> Geometry:
    if intervals < 4:
        raise ValueError("径向区间数至少为4")
    dr = radius_m / intervals
    nodes = np.linspace(0.0, radius_m, intervals + 1)
    left = nodes - 0.5 * dr
    right = nodes + 0.5 * dr
    left[0] = 0.0
    right[-1] = radius_m
    volumes = math.pi * (right**2 - left**2)  # 单位轴向长度下的体积/m^2
    face_radii = 0.5 * (nodes[:-1] + nodes[1:])
    face_areas = 2.0 * math.pi * face_radii  # 单位轴向长度下的面积/m
    surface_area = 2.0 * math.pi * radius_m

    if not np.all(volumes > 0) or not np.all(face_areas > 0):
        raise AssertionError("有限体积几何量必须为正")
    return Geometry(nodes, volumes, face_areas, surface_area, dr)


def factorize_tridiagonal(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Thomas算法的LU分解；lower[0]和upper[-1]不使用。"""
    multipliers = lower.astype(float, copy=True)
    pivots = diagonal.astype(float, copy=True)
    superdiag = upper.astype(float, copy=True)
    scale = max(float(np.max(np.abs(pivots))), 1.0)
    for i in range(1, len(pivots)):
        if abs(pivots[i - 1]) <= np.finfo(float).eps * scale:
            raise np.linalg.LinAlgError(f"三对角矩阵在第{i - 1}个主元处接近奇异")
        multipliers[i] /= pivots[i - 1]
        pivots[i] -= multipliers[i] * superdiag[i - 1]
    if abs(pivots[-1]) <= np.finfo(float).eps * scale:
        raise np.linalg.LinAlgError("三对角矩阵末主元接近奇异")
    return multipliers, pivots, superdiag


def solve_tridiagonal_factored(
    factors: tuple[np.ndarray, np.ndarray, np.ndarray],
    rhs: np.ndarray,
) -> np.ndarray:
    multipliers, pivots, superdiag = factors
    work = rhs.astype(float, copy=True)
    for i in range(1, len(work)):
        work[i] -= multipliers[i] * work[i - 1]
    solution = np.empty_like(work)
    solution[-1] = work[-1] / pivots[-1]
    for i in range(len(work) - 2, -1, -1):
        solution[i] = (work[i] - superdiag[i] * solution[i + 1]) / pivots[i]
    return solution


def solve_tridiagonal(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
    rhs: np.ndarray,
) -> np.ndarray:
    return solve_tridiagonal_factored(
        factorize_tridiagonal(lower, diagonal, upper), rhs
    )


def tridiagonal_matvec(
    lower: np.ndarray,
    diagonal: np.ndarray,
    upper: np.ndarray,
    vector: np.ndarray,
) -> np.ndarray:
    result = diagonal * vector
    result[1:] += lower[1:] * vector[:-1]
    result[:-1] += upper[:-1] * vector[1:]
    return result


def temperature_matrix(
    geometry: Geometry,
    params: ModelParameters,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = len(geometry.radius_nodes_m)
    capacity = (
        params.density_kg_m3
        * params.heat_capacity_j_kg_k
        * geometry.cell_volumes_m2
        / params.time_step_s
    )
    conductance = (
        params.thermal_conductivity_w_m_k
        * geometry.internal_face_areas_m
        / geometry.dr_m
    )
    lower = np.zeros(n)
    diagonal = capacity.copy()
    upper = np.zeros(n)

    diagonal[0] += conductance[0]
    upper[0] = -conductance[0]
    for i in range(1, n - 1):
        lower[i] = -conductance[i - 1]
        diagonal[i] += conductance[i - 1] + conductance[i]
        upper[i] = -conductance[i]
    lower[-1] = -conductance[-1]
    diagonal[-1] += conductance[-1] + params.heat_transfer_w_m2_k * geometry.surface_area_m
    return lower, diagonal, upper, capacity


def moisture_diffusivity(moisture: np.ndarray) -> np.ndarray:
    if np.any(~np.isfinite(moisture)) or np.any(moisture <= 0):
        raise FloatingPointError("计算D(C)时含水率必须为有限正数")
    diffusivity = 7.0e-9 * np.exp(-0.89 / moisture)
    if np.any(~np.isfinite(diffusivity)) or np.any(diffusivity <= 0):
        raise FloatingPointError("扩散系数出现非有限值或非正值")
    return diffusivity


def moisture_matrix(
    geometry: Geometry,
    params: ModelParameters,
    moisture_guess: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = len(geometry.radius_nodes_m)
    capacity = geometry.cell_volumes_m2 / params.time_step_s
    node_d = moisture_diffusivity(moisture_guess)
    face_d = 2.0 * node_d[:-1] * node_d[1:] / (node_d[:-1] + node_d[1:])
    conductance = face_d * geometry.internal_face_areas_m / geometry.dr_m

    lower = np.zeros(n)
    diagonal = capacity.copy()
    upper = np.zeros(n)
    diagonal[0] += conductance[0]
    upper[0] = -conductance[0]
    for i in range(1, n - 1):
        lower[i] = -conductance[i - 1]
        diagonal[i] += conductance[i - 1] + conductance[i]
        upper[i] = -conductance[i]
    lower[-1] = -conductance[-1]
    diagonal[-1] += conductance[-1] + params.mass_transfer_m_s * geometry.surface_area_m
    return lower, diagonal, upper, capacity


def relative_residual(residual: np.ndarray, rhs: np.ndarray) -> float:
    return float(np.max(np.abs(residual)) / max(np.max(np.abs(rhs)), 1.0e-30))


def solve_case(boundary: BoundaryData, params: ModelParameters) -> Solution:
    geometry = build_geometry(params.radius_m, params.intervals)
    steps_float = params.end_time_s / params.time_step_s
    steps = int(round(steps_float))
    if not math.isclose(steps_float, steps, rel_tol=0.0, abs_tol=1.0e-12):
        raise ValueError("end_time_s必须是time_step_s的整数倍")
    times = np.linspace(0.0, params.end_time_s, steps + 1)
    node_count = params.intervals + 1

    temperature = np.empty((steps + 1, node_count), dtype=float)
    moisture = np.empty((steps + 1, node_count), dtype=float)
    temperature[0, :] = params.initial_temperature_c
    moisture[0, :] = params.initial_moisture_kg_kg

    lower_t, diag_t, upper_t, capacity_t = temperature_matrix(geometry, params)
    temperature_factors = factorize_tridiagonal(lower_t, diag_t, upper_t)

    max_temp_linear_residual = 0.0
    max_heat_balance_residual = 0.0
    max_moisture_balance_residual = 0.0
    max_picard_residual = 0.0
    picard_iterations: list[int] = []

    for step in range(steps):
        next_time = times[step + 1]

        rhs_t = capacity_t * temperature[step]
        rhs_t[-1] += (
            params.heat_transfer_w_m2_k
            * geometry.surface_area_m
            * float(boundary.temperature(next_time))
        )
        next_temperature = solve_tridiagonal_factored(temperature_factors, rhs_t)
        linear_residual = tridiagonal_matvec(lower_t, diag_t, upper_t, next_temperature) - rhs_t
        max_temp_linear_residual = max(
            max_temp_linear_residual,
            relative_residual(linear_residual, rhs_t),
        )
        temperature[step + 1] = next_temperature

        heat_change = float(
            np.sum(
                params.density_kg_m3
                * params.heat_capacity_j_kg_k
                * geometry.cell_volumes_m2
                * (temperature[step + 1] - temperature[step])
            )
        )
        heat_boundary = float(
            params.time_step_s
            * params.heat_transfer_w_m2_k
            * geometry.surface_area_m
            * (float(boundary.temperature(next_time)) - temperature[step + 1, -1])
        )
        max_heat_balance_residual = max(
            max_heat_balance_residual,
            abs(heat_change - heat_boundary) / max(abs(heat_change), abs(heat_boundary), 1.0e-30),
        )

        old_moisture = moisture[step]
        guess = old_moisture.copy()
        converged = False
        final_picard_residual = math.inf
        next_moisture = guess
        for iteration in range(1, params.picard_max_iterations + 1):
            lower_c, diag_c, upper_c, capacity_c = moisture_matrix(geometry, params, guess)
            rhs_c = capacity_c * old_moisture
            rhs_c[-1] += (
                params.mass_transfer_m_s
                * geometry.surface_area_m
                * float(boundary.moisture(next_time))
            )
            candidate = solve_tridiagonal(lower_c, diag_c, upper_c, rhs_c)
            if np.any(~np.isfinite(candidate)) or np.any(candidate <= 0):
                raise FloatingPointError(f"t={next_time:g} s时Picard迭代产生非正或非有限含水率")

            delta = candidate - guess
            delta_relative = float(
                np.max(np.abs(delta)) / max(1.0, np.max(np.abs(candidate)))
            )
            lower_r, diag_r, upper_r, _ = moisture_matrix(geometry, params, candidate)
            nonlinear_residual = (
                tridiagonal_matvec(lower_r, diag_r, upper_r, candidate) - rhs_c
            )
            final_picard_residual = relative_residual(nonlinear_residual, rhs_c)
            if (
                delta_relative <= params.picard_tolerance
                and final_picard_residual <= params.picard_residual_tolerance
            ):
                next_moisture = candidate
                converged = True
                picard_iterations.append(iteration)
                break
            guess = (
                params.picard_relaxation * candidate
                + (1.0 - params.picard_relaxation) * guess
            )

        if not converged:
            raise RuntimeError(
                f"t={next_time:g} s时Picard迭代未在"
                f"{params.picard_max_iterations}次内收敛；末次相对残差="
                f"{final_picard_residual:.3e}"
            )
        max_picard_residual = max(max_picard_residual, final_picard_residual)
        moisture[step + 1] = next_moisture

        moisture_change = float(
            np.sum(geometry.cell_volumes_m2 * (moisture[step + 1] - moisture[step]))
        )
        moisture_boundary = float(
            params.time_step_s
            * params.mass_transfer_m_s
            * geometry.surface_area_m
            * (float(boundary.moisture(next_time)) - moisture[step + 1, -1])
        )
        max_moisture_balance_residual = max(
            max_moisture_balance_residual,
            abs(moisture_change - moisture_boundary)
            / max(abs(moisture_change), abs(moisture_boundary), 1.0e-30),
        )

    diagnostics = {
        "intervals": params.intervals,
        "nodes": node_count,
        "dr_m": geometry.dr_m,
        "dt_s": params.time_step_s,
        "max_temperature_linear_relative_residual": max_temp_linear_residual,
        "max_heat_balance_relative_residual": max_heat_balance_residual,
        "max_moisture_balance_relative_residual": max_moisture_balance_residual,
        "max_picard_nonlinear_relative_residual": max_picard_residual,
        "picard_iterations_max": int(max(picard_iterations)),
        "picard_iterations_mean": float(np.mean(picard_iterations)),
        "temperature_min_c": float(np.min(temperature)),
        "temperature_max_c": float(np.max(temperature)),
        "moisture_min_kg_kg": float(np.min(moisture)),
        "moisture_max_kg_kg": float(np.max(moisture)),
        "temperature_radial_order_violations": int(np.sum(np.diff(temperature, axis=1) < -1.0e-10)),
        "moisture_radial_order_violations": int(np.sum(np.diff(moisture, axis=1) > 1.0e-10)),
    }
    return Solution(times, geometry.radius_nodes_m, temperature, moisture, diagnostics)


def sample_field(
    solution: Solution,
    field: np.ndarray,
    target_times_s: Iterable[float],
    target_radii_m: Iterable[float],
) -> np.ndarray:
    target_times = np.asarray(list(target_times_s), dtype=float)
    target_radii = np.asarray(list(target_radii_m), dtype=float)
    radial_samples = np.vstack(
        [np.interp(target_radii, solution.radius_nodes_m, row) for row in field]
    )
    output = np.empty((len(target_times), len(target_radii)), dtype=float)
    for j in range(len(target_radii)):
        output[:, j] = np.interp(target_times, solution.times_s, radial_samples[:, j])
    return output


def compare_solutions(reference: Solution, candidate: Solution) -> dict:
    target_times = np.arange(0.0, reference.times_s[-1] + 0.5, 1.0)
    ref_t = sample_field(reference, reference.temperature_c, target_times, OUTPUT_RADII_M)
    can_t = sample_field(candidate, candidate.temperature_c, target_times, OUTPUT_RADII_M)
    ref_c = sample_field(reference, reference.moisture_kg_kg, target_times, OUTPUT_RADII_M)
    can_c = sample_field(candidate, candidate.moisture_kg_kg, target_times, OUTPUT_RADII_M)

    report_ref_t = sample_field(reference, reference.temperature_c, REPORT_TIMES_S, REPORT_RADII_M)
    report_can_t = sample_field(candidate, candidate.temperature_c, REPORT_TIMES_S, REPORT_RADII_M)
    report_ref_c = sample_field(reference, reference.moisture_kg_kg, REPORT_TIMES_S, REPORT_RADII_M)
    report_can_c = sample_field(candidate, candidate.moisture_kg_kg, REPORT_TIMES_S, REPORT_RADII_M)
    return {
        "full_output_max_abs_temperature_c": float(np.max(np.abs(ref_t - can_t))),
        "full_output_max_abs_moisture_kg_kg": float(np.max(np.abs(ref_c - can_c))),
        "report_table_max_abs_temperature_c": float(np.max(np.abs(report_ref_t - report_can_t))),
        "report_table_max_abs_moisture_kg_kg": float(np.max(np.abs(report_ref_c - report_can_c))),
        "full_output_four_decimal_equal_temperature": bool(np.array_equal(np.round(ref_t, 4), np.round(can_t, 4))),
        "full_output_four_decimal_equal_moisture": bool(np.array_equal(np.round(ref_c, 4), np.round(can_c, 4))),
        "report_table_four_decimal_equal_temperature": bool(
            np.array_equal(np.round(report_ref_t, 4), np.round(report_can_t, 4))
        ),
        "report_table_four_decimal_equal_moisture": bool(
            np.array_equal(np.round(report_ref_c, 4), np.round(report_can_c, 4))
        ),
    }


def run_validation(boundary: BoundaryData, main: Solution, params: ModelParameters) -> dict:
    cases = {
        "coarse_space_40_intervals_dt1": ModelParameters(
            **{**asdict(params), "intervals": 40, "time_step_s": 1.0}
        ),
        "fine_space_160_intervals_dt1": ModelParameters(
            **{**asdict(params), "intervals": 160, "time_step_s": 1.0}
        ),
        "fine_time_80_intervals_dt0_5": ModelParameters(
            **{**asdict(params), "intervals": 80, "time_step_s": 0.5}
        ),
    }
    solved = {name: solve_case(boundary, case_params) for name, case_params in cases.items()}
    return {
        "main_diagnostics": main.diagnostics,
        "coarse_40_vs_main_80": compare_solutions(main, solved["coarse_space_40_intervals_dt1"]),
        "main_80_vs_fine_160": compare_solutions(main, solved["fine_space_160_intervals_dt1"]),
        "dt1_vs_dt0_5": compare_solutions(main, solved["fine_time_80_intervals_dt0_5"]),
        "auxiliary_diagnostics": {name: sol.diagnostics for name, sol in solved.items()},
        "interpretation": (
            "四位小数相等字段是直接的提交精度检查；若为false，应报告差异，"
            "不能仅凭后向欧拉无条件稳定宣称四位小数已经收敛。"
        ),
    }


def write_result_workbook(path: Path, solution: Solution) -> None:
    target_times = np.arange(0.0, solution.times_s[-1] + 0.5, 1.0)
    temperature_output = sample_field(
        solution, solution.temperature_c, target_times, OUTPUT_RADII_M
    )
    moisture_output = sample_field(
        solution, solution.moisture_kg_kg, target_times, OUTPUT_RADII_M
    )

    workbook = Workbook()
    temperature_sheet = workbook.active
    temperature_sheet.title = "温度"
    moisture_sheet = workbook.create_sheet("水分浓度")

    for worksheet, values in (
        (temperature_sheet, temperature_output),
        (moisture_sheet, moisture_output),
    ):
        worksheet.cell(1, 1, "时间/s")
        for column, radius_m in enumerate(OUTPUT_RADII_M, start=2):
            worksheet.cell(1, column, float(radius_m * 100.0))
        for row, time_s in enumerate(target_times, start=2):
            worksheet.cell(row, 1, int(round(time_s)))
            for column, value in enumerate(values[row - 2], start=2):
                worksheet.cell(row, column, round(float(value), 4))

        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(name="Microsoft YaHei", size=10, bold=True, color="FFFFFF")
        body_font = Font(name="Microsoft YaHei", size=9)
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for row in worksheet.iter_rows(min_row=2):
            for cell in row:
                cell.font = body_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
        for cell in worksheet["A"][1:]:
            cell.number_format = "0"
        for row in worksheet.iter_rows(min_row=2, min_col=2):
            for cell in row:
                cell.number_format = "0.0000"
        for cell in worksheet[1][1:]:
            cell.number_format = "0.0"
        worksheet.column_dimensions["A"].width = 12
        for column_index in range(2, 23):
            worksheet.column_dimensions[worksheet.cell(1, column_index).column_letter].width = 11
        worksheet.freeze_panes = "B2"
        worksheet.auto_filter.ref = f"A1:V{len(target_times) + 1}"
        worksheet.sheet_view.showGridLines = True

    workbook.save(path)


def _load_plot_font(size: int, bold: bool = False):
    from PIL import ImageFont
    from matplotlib import font_manager

    properties = font_manager.FontProperties(
        family=["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "DejaVu Sans"],
        weight="bold" if bold else "normal",
    )
    font_path = font_manager.findfont(properties, fallback_to_default=True)
    return ImageFont.truetype(font_path, size=size)


def _save_line_chart(
    path: Path,
    x: np.ndarray,
    series: list[tuple[str, np.ndarray, str]],
    title: str,
    x_label: str,
    y_label: str,
) -> None:
    from PIL import Image, ImageDraw

    width, height = 1500, 900
    left, right, top, bottom = 155, 70, 115, 135
    plot_width = width - left - right
    plot_height = height - top - bottom
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    title_font = _load_plot_font(34, bold=True)
    label_font = _load_plot_font(23)
    tick_font = _load_plot_font(19)
    legend_font = _load_plot_font(19)

    x = np.asarray(x, dtype=float)
    all_y = np.concatenate([np.asarray(values, dtype=float) for _, values, _ in series])
    x_min, x_max = float(np.min(x)), float(np.max(x))
    y_min, y_max = float(np.min(all_y)), float(np.max(all_y))
    if math.isclose(x_min, x_max):
        x_max = x_min + 1.0
    if math.isclose(y_min, y_max):
        y_min -= 0.5
        y_max += 0.5
    y_padding = 0.06 * (y_max - y_min)
    y_min -= y_padding
    y_max += y_padding

    def px(value: float) -> float:
        return left + (value - x_min) / (x_max - x_min) * plot_width

    def py(value: float) -> float:
        return top + (y_max - value) / (y_max - y_min) * plot_height

    for tick in np.linspace(x_min, x_max, 6):
        position = px(float(tick))
        draw.line((position, top, position, top + plot_height), fill="#E5E7EB", width=1)
        text_value = f"{tick:.2f}" if x_max <= 3 else f"{tick:.0f}"
        draw.text((position - 25, top + plot_height + 16), text_value, fill="#374151", font=tick_font)
    for tick in np.linspace(y_min, y_max, 6):
        position = py(float(tick))
        draw.line((left, position, left + plot_width, position), fill="#E5E7EB", width=1)
        draw.text((18, position - 12), f"{tick:.4g}", fill="#374151", font=tick_font)

    draw.line((left, top, left, top + plot_height), fill="#111827", width=2)
    draw.line((left, top + plot_height, left + plot_width, top + plot_height), fill="#111827", width=2)
    for label, values, color in series:
        values = np.asarray(values, dtype=float)
        points = [(px(float(xv)), py(float(yv))) for xv, yv in zip(x, values)]
        draw.line(points, fill=color, width=4, joint="curve")

    title_box = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((width - (title_box[2] - title_box[0])) / 2, 28), title, fill="#111827", font=title_font)
    x_box = draw.textbbox((0, 0), x_label, font=label_font)
    draw.text(((width - (x_box[2] - x_box[0])) / 2, height - 62), x_label, fill="#111827", font=label_font)
    draw.text((18, 70), y_label, fill="#111827", font=label_font)

    legend_x = left + 15
    legend_y = top + 15
    for label, _, color in series:
        draw.line((legend_x, legend_y + 11, legend_x + 42, legend_y + 11), fill=color, width=4)
        draw.text((legend_x + 52, legend_y), label, fill="#111827", font=legend_font)
        legend_x += 145
        if legend_x > width - 220:
            legend_x = left + 15
            legend_y += 34
    image.save(path, format="PNG")


def save_plots(output_dir: Path, boundary: BoundaryData, solution: Solution) -> list[str]:
    colors = ["#0F766E", "#2563EB", "#7C3AED", "#C2410C", "#BE123C", "#4D7C0F", "#111827"]
    created: list[str] = []

    charts = [
        (
            "q1_boundary_temperature.png",
            boundary.time_s,
            [("烘房温度", boundary.temperature_c, "#C2410C")],
            "问题1的烘房温度边界",
            "时间 / s",
            "温度 / °C",
        ),
        (
            "q1_boundary_moisture.png",
            boundary.time_s,
            [("烘房水分", boundary.moisture_kg_kg, "#0369A1")],
            "问题1的烘房水分边界",
            "时间 / s",
            "水分浓度 / (kg/kg)",
        ),
    ]

    temperature_profiles = sample_field(
        solution, solution.temperature_c, REPORT_TIMES_S, solution.radius_nodes_m
    )
    moisture_profiles = sample_field(
        solution, solution.moisture_kg_kg, REPORT_TIMES_S, solution.radius_nodes_m
    )
    charts.extend(
        [
            (
                "q1_temperature_profiles.png",
                solution.radius_nodes_m * 100.0,
                [
                    (f"{time_s:g}s", profile, colors[index])
                    for index, (time_s, profile) in enumerate(zip(REPORT_TIMES_S, temperature_profiles))
                ],
                "药材径向温度分布",
                "到药材中心的距离 / cm",
                "温度 / °C",
            ),
            (
                "q1_moisture_profiles.png",
                solution.radius_nodes_m * 100.0,
                [
                    (f"{time_s:g}s", profile, colors[index])
                    for index, (time_s, profile) in enumerate(zip(REPORT_TIMES_S, moisture_profiles))
                ],
                "药材径向水分浓度分布",
                "到药材中心的距离 / cm",
                "水分浓度 / (kg/kg)",
            ),
            (
                "q1_center_surface_temperature.png",
                solution.times_s,
                [
                    ("中心", solution.temperature_c[:, 0], "#1D4ED8"),
                    ("表面", solution.temperature_c[:, -1], "#DC2626"),
                ],
                "中心与表面温度随时间变化",
                "时间 / s",
                "温度 / °C",
            ),
            (
                "q1_center_surface_moisture.png",
                solution.times_s,
                [
                    ("中心", solution.moisture_kg_kg[:, 0], "#1D4ED8"),
                    ("表面", solution.moisture_kg_kg[:, -1], "#DC2626"),
                ],
                "中心与表面水分浓度随时间变化",
                "时间 / s",
                "水分浓度 / (kg/kg)",
            ),
        ]
    )

    for filename, x_values, series, title, x_label, y_label in charts:
        _save_line_chart(output_dir / filename, x_values, series, title, x_label, y_label)
        created.append(filename)
    return created


def write_report_tables(path: Path, solution: Solution) -> None:
    temperature = sample_field(
        solution, solution.temperature_c, REPORT_TIMES_S, REPORT_RADII_M
    )
    moisture = sample_field(
        solution, solution.moisture_kg_kg, REPORT_TIMES_S, REPORT_RADII_M
    )
    payload = {
        "times_s": REPORT_TIMES_S.astype(int).tolist(),
        "radii_cm": (REPORT_RADII_M * 100.0).tolist(),
        "temperature_c": np.round(temperature, 4).tolist(),
        "moisture_kg_kg": np.round(moisture, 4).tolist(),
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    args = parse_args()
    params = ModelParameters(intervals=args.intervals, time_step_s=args.dt)
    if params.intervals != 80 or not math.isclose(params.time_step_s, 1.0):
        print(
            "提示：当前参数不是商定的主设置（80个区间、81个节点、dt=1 s），"
            "将按命令行参数执行。",
            file=sys.stderr,
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)

    boundary = read_boundary_data(args.input, params.end_time_s)
    solution = solve_case(boundary, params)

    result_path = args.output_dir / "result1.xlsx"
    write_result_workbook(result_path, solution)
    write_report_tables(args.output_dir / "q1_report_values.json", solution)

    validation = {"main_diagnostics": solution.diagnostics}
    if not args.skip_validation:
        validation = run_validation(boundary, solution, params)
    (args.output_dir / "q1_validation_summary.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    plot_files: list[str] = []
    if not args.no_plots:
        plot_files = save_plots(args.output_dir, boundary, solution)

    run_summary = {
        "input": str(args.input.resolve()),
        "output_directory": str(args.output_dir.resolve()),
        "parameters": asdict(params),
        "result_workbook": result_path.name,
        "report_values": "q1_report_values.json",
        "validation_summary": "q1_validation_summary.json",
        "plots": plot_files,
    }
    (args.output_dir / "q1_run_summary.json").write_text(
        json.dumps(run_summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(run_summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
