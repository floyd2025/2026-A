"""Export Q3 CSV results to ordinary Excel files using openpyxl."""
from __future__ import annotations

import argparse
import csv
import math
import re
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from q3_paths import package_path, require_file


def read_rows(path: Path) -> tuple[list[str], list[list[float]]]:
    with require_file(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream)
        header = next(reader)
        rows = [[float(value) for value in row] for row in reader if row]
    if not rows or any(len(row) != len(header) for row in rows):
        raise ValueError(f"CSV行列不完整：{path.name}")
    if not all(math.isfinite(value) for row in rows for value in row):
        raise ValueError(f"CSV含非有限值：{path.name}")
    times = [row[0] for row in rows]
    if any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError(f"时间必须严格递增：{path.name}")
    return header, rows


def style_sheet(sheet, first_data_row: int) -> None:
    fill = PatternFill("solid", fgColor="1F4E78")
    line = Side(style="thin", color="D9E2F3")
    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.font = Font(name="Arial", size=10)
            if cell.row < first_data_row:
                cell.fill = fill
                cell.font = Font(name="Arial", size=10, color="FFFFFF", bold=True)
                cell.border = Border(left=line, right=line, top=line, bottom=line)
            elif cell.column == 1:
                cell.number_format = "0.####"
            else:
                cell.number_format = "0.0000"
    for index in range(1, sheet.max_column + 1):
        sheet.column_dimensions[get_column_letter(index)].width = 14 if index == 1 else 12
    sheet.freeze_panes = f"B{first_data_row}"
    sheet.sheet_view.showGridLines = True


def export_workbooks(data_dir: Path, output_dir: Path | None = None) -> list[Path]:
    data_dir = Path(data_dir)
    output_dir = data_dir if output_dir is None else Path(output_dir)
    header, rows = read_rows(data_dir / "result3_moisture.csv")
    if header[0] != "time_s":
        raise ValueError("完整结果首列必须为time_s")
    radii = []
    for name in header[1:]:
        match = re.fullmatch(r"r_([0-9.]+)_cm", name)
        if match is None:
            raise ValueError(f"无法识别半径列：{name}")
        radii.append(float(match.group(1)))
    expected = [index / 10 for index in range(21)]
    if len(radii) != 21 or any(abs(a-b) > 1e-9 for a, b in zip(radii, expected)):
        raise ValueError("完整结果应包含0到2 cm、间隔0.1 cm的21列半径")

    paper_header, paper_rows = read_rows(data_dir / "question3_table5.csv")
    wanted = ["r_0.0_cm", "r_0.5_cm", "r_1.0_cm", "r_1.5_cm", "r_2.0_cm"]
    required = ["time_s", "time_h", "is_completion_time", *wanted]
    if any(name not in paper_header for name in required):
        raise ValueError("表5的CSV缺少时间、终止标记或半径列")
    if not math.isclose(paper_rows[-1][paper_header.index("time_s")], rows[-1][0], abs_tol=1e-5):
        raise ValueError("完整结果与表5的终止时间不一致，请使用同一次计算的文件")

    output_dir.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    sheet = wb.active
    sheet.title = "水分浓度"
    sheet.append(["时间/s", *radii])
    for row in rows:
        sheet.append([row[0], *[round(value, 4) for value in row[1:]]])
    style_sheet(sheet, 2)
    for cell in sheet[1][1:]:
        cell.number_format = "0.0"
    result_path = output_dir / "result3.xlsx"
    wb.save(result_path)

    report = Workbook()
    sheet = report.active
    sheet.title = "表5_水分浓度"
    sheet.append(["时间/h", "到药材中心的距离/cm"])
    sheet.append([None, 0, 0.5, 1, 1.5, 2])
    sheet.merge_cells("A1:A2")
    sheet.merge_cells("B1:F1")
    time_index = paper_header.index("time_h")
    flag_index = paper_header.index("is_completion_time")
    indices = [paper_header.index(name) for name in wanted]
    for row in paper_rows:
        label = f"烘干结束 {row[time_index]:.4f}" if row[flag_index] else row[time_index]
        sheet.append([label, *[round(row[index], 4) for index in indices]])
    style_sheet(sheet, 3)
    sheet.column_dimensions["A"].width = 24
    sheet.row_dimensions[1].height = 24
    report_path = output_dir / "问题3_表5.xlsx"
    report.save(report_path)
    return [result_path, report_path]


def main() -> None:
    parser = argparse.ArgumentParser(description="将本次Q3计算结果导出为result3.xlsx及论文表5")
    parser.add_argument("--data-dir", default="results")
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()
    data_dir = package_path(args.data_dir)
    output_dir = package_path(args.output_dir) if args.output_dir else data_dir
    for path in export_workbooks(data_dir, output_dir):
        print(f"已导出：{path}")


if __name__ == "__main__":
    main()
