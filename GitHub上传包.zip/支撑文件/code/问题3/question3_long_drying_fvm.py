
"""CUMCM A题问题3：长时间烘干与终止时间预测。

模型沿用问题2：一维轴对称圆柱、节点型守恒有限体积法、后向欧拉、
温湿度耦合Picard迭代及附录3变物性关系。本程序只对问题3新增：

1. 附件1覆盖0~4 h，4 h后把最后稳定时间窗均值作为恒温干燥边界；
2. 0~4 h采用1 s步长，4 h后采用较大的固定步长（默认30 s）；
3. 当全部空间节点C<0.15 kg/kg时自动停止，并以1 s子步精化末端；
4. 内存只保存当前节点状态，每60 s保存21个题目要求位置；
5. 可选执行时间步、80/160/320/640区间及边界延拓敏感性验证。

题目严格模型不包含汽化潜热。潜热模型已在问题2对照中单独讨论；若要把
潜热纳入问题3，应保持问题2和问题3的模型口径一致后另行计算。
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import numpy as np

import question2_coupled_fvm as q2
from q3_paths import package_path, require_file, write_reproduction_info


SECONDS_PER_HOUR = 3600.0
DEFAULT_TRANSITION_S = 4.0 * SECONDS_PER_HOUR
OUTPUT_RADII_M = np.linspace(0.0, 0.020, 21)
PAPER_RADII_M = np.asarray([0.0, 0.005, 0.010, 0.015, 0.020])


@dataclass(frozen=True)
class Q3Config:
    threshold_kg_kg: float = 0.15
    transition_time_s: float = DEFAULT_TRANSITION_S
    plateau_window_s: float = SECONDS_PER_HOUR
    plateau_mode: str = "window-mean"
    early_dt_s: float = 1.0
    late_dt_s: float = 30.0
    final_refine_dt_s: float = 1.0
    output_interval_s: float = 60.0
    paper_interval_s: float = 6.0 * SECONDS_PER_HOUR
    max_time_s: float = 7.0 * 24.0 * SECONDS_PER_HOUR
    progress_interval_s: float = 6.0 * SECONDS_PER_HOUR


@dataclass(frozen=True)
class ExtendedBoundary:
    source: q2.BoundaryData
    transition_time_s: float
    plateau_temperature_c: float
    plateau_moisture_kg_kg: float
    plateau_window_s: float
    plateau_mode: str
    plateau_temperature_std_c: float
    plateau_moisture_std_kg_kg: float

    def temperature(self, time_s: float | np.ndarray):
        time = np.asarray(time_s, dtype=float)
        original = np.interp(
            np.minimum(time, self.transition_time_s),
            self.source.time_s,
            self.source.temperature_c,
        )
        value = np.where(
            time <= self.transition_time_s,
            original,
            self.plateau_temperature_c,
        )
        return float(value) if np.ndim(value) == 0 else value

    def moisture(self, time_s: float | np.ndarray):
        time = np.asarray(time_s, dtype=float)
        original = np.interp(
            np.minimum(time, self.transition_time_s),
            self.source.time_s,
            self.source.moisture_kg_kg,
        )
        value = np.where(
            time <= self.transition_time_s,
            original,
            self.plateau_moisture_kg_kg,
        )
        return float(value) if np.ndim(value) == 0 else value


@dataclass
class DiagnosticAccumulator:
    max_temperature_linear_relative_residual: float = 0.0
    max_moisture_linear_relative_residual: float = 0.0
    max_temperature_nonlinear_relative_residual: float = 0.0
    max_moisture_nonlinear_relative_residual: float = 0.0
    max_picard_relative_update_encountered: float = 0.0
    max_final_picard_relative_update: float = 0.0
    max_heat_balance_relative_residual: float = 0.0
    max_moisture_balance_relative_residual: float = 0.0
    max_heat_balance_absolute_residual_j_per_m: float = 0.0
    max_moisture_balance_absolute_residual_m2_kg_per_kg: float = 0.0
    picard_iterations_max: int = 0
    picard_iterations_sum: int = 0
    accepted_steps: int = 0
    early_steps: int = 0
    late_steps: int = 0
    refined_steps: int = 0
    min_dt_s: float = math.inf
    max_dt_s: float = 0.0
    temperature_min_c: float = math.inf
    temperature_max_c: float = -math.inf
    moisture_min_kg_kg: float = math.inf
    moisture_max_kg_kg: float = -math.inf
    temperature_radial_order_violations: int = 0
    moisture_radial_order_violations: int = 0

    def absorb(self, step: dict, dt_s: float, stage: str) -> None:
        maximum_fields = (
            "max_temperature_linear_relative_residual",
            "max_moisture_linear_relative_residual",
            "max_temperature_nonlinear_relative_residual",
            "max_moisture_nonlinear_relative_residual",
            "max_picard_relative_update_encountered",
            "max_final_picard_relative_update",
            "max_heat_balance_relative_residual",
            "max_moisture_balance_relative_residual",
            "max_heat_balance_absolute_residual_j_per_m",
            "max_moisture_balance_absolute_residual_m2_kg_per_kg",
        )
        for field in maximum_fields:
            setattr(self, field, max(getattr(self, field), float(step[field])))
        self.picard_iterations_max = max(
            self.picard_iterations_max, int(step["picard_iterations"])
        )
        self.picard_iterations_sum += int(step["picard_iterations"])
        self.accepted_steps += 1
        if stage == "early":
            self.early_steps += 1
        elif stage == "late":
            self.late_steps += 1
        elif stage == "refined":
            self.refined_steps += 1
        else:
            raise ValueError(f"未知时间阶段：{stage}")
        self.min_dt_s = min(self.min_dt_s, float(dt_s))
        self.max_dt_s = max(self.max_dt_s, float(dt_s))
        self.temperature_min_c = min(
            self.temperature_min_c, float(step["temperature_min_c"])
        )
        self.temperature_max_c = max(
            self.temperature_max_c, float(step["temperature_max_c"])
        )
        self.moisture_min_kg_kg = min(
            self.moisture_min_kg_kg, float(step["moisture_min_kg_kg"])
        )
        self.moisture_max_kg_kg = max(
            self.moisture_max_kg_kg, float(step["moisture_max_kg_kg"])
        )
        self.temperature_radial_order_violations += int(
            step["temperature_radial_order_violations"]
        )
        self.moisture_radial_order_violations += int(
            step["moisture_radial_order_violations"]
        )

    def as_dict(self) -> dict:
        payload = asdict(self)
        payload["picard_iterations_mean"] = (
            self.picard_iterations_sum / self.accepted_steps
            if self.accepted_steps
            else math.nan
        )
        if not math.isfinite(payload["min_dt_s"]):
            payload["min_dt_s"] = math.nan
        return payload


@dataclass
class Q3Solution:
    times_s: np.ndarray
    radius_output_m: np.ndarray
    temperature_output_c: np.ndarray
    moisture_output_kg_kg: np.ndarray
    completion_time_s: float
    completion_temperature_nodes_c: np.ndarray
    completion_moisture_nodes_kg_kg: np.ndarray
    radius_nodes_m: np.ndarray
    diagnostics: dict


def build_extended_boundary(
    source: q2.BoundaryData,
    config: Q3Config,
) -> ExtendedBoundary:
    if source.time_s[0] > 0.0 or source.time_s[-1] < config.transition_time_s:
        raise ValueError(
            f"附件1必须覆盖0至{config.transition_time_s:g} s，"
            f"当前覆盖至{source.time_s[-1]:g} s"
        )
    if config.plateau_mode not in {"window-mean", "last-point"}:
        raise ValueError("plateau_mode必须为window-mean或last-point")
    if config.plateau_mode == "last-point":
        temperature = float(np.interp(
            config.transition_time_s, source.time_s, source.temperature_c
        ))
        moisture = float(np.interp(
            config.transition_time_s, source.time_s, source.moisture_kg_kg
        ))
        temperature_std = 0.0
        moisture_std = 0.0
        window_s = 0.0
    else:
        start = config.transition_time_s - config.plateau_window_s
        mask = (source.time_s >= start) & (
            source.time_s <= config.transition_time_s
        )
        if np.count_nonzero(mask) < 2:
            raise ValueError("平台均值时间窗内至少需要两个附件测点")
        temperature = float(np.mean(source.temperature_c[mask]))
        moisture = float(np.mean(source.moisture_kg_kg[mask]))
        temperature_std = float(np.std(source.temperature_c[mask], ddof=1))
        moisture_std = float(np.std(source.moisture_kg_kg[mask], ddof=1))
        window_s = config.plateau_window_s
    return ExtendedBoundary(
        source=source,
        transition_time_s=config.transition_time_s,
        plateau_temperature_c=temperature,
        plateau_moisture_kg_kg=moisture,
        plateau_window_s=window_s,
        plateau_mode=config.plateau_mode,
        plateau_temperature_std_c=temperature_std,
        plateau_moisture_std_kg_kg=moisture_std,
    )


def normalized_update(
    new_t: np.ndarray,
    old_t: np.ndarray,
    new_c: np.ndarray,
    old_c: np.ndarray,
) -> float:
    return max(
        float(np.linalg.norm(new_t - old_t, ord=np.inf))
        / max(float(np.linalg.norm(new_t, ord=np.inf)), 1.0),
        float(np.linalg.norm(new_c - old_c, ord=np.inf))
        / max(float(np.linalg.norm(new_c, ord=np.inf)), 1.0),
    )


def coupled_backward_euler_step(
    geometry,
    base_params: q2.Q2Parameters,
    old_temperature_c: np.ndarray,
    old_moisture_kg_kg: np.ndarray,
    next_time_s: float,
    dt_s: float,
    boundary: ExtendedBoundary,
) -> tuple[np.ndarray, np.ndarray, dict]:
    params = replace(base_params, time_step_s=float(dt_s), end_time_s=float(dt_s))
    ambient_temperature = float(boundary.temperature(next_time_s))
    ambient_moisture = float(boundary.moisture(next_time_s))
    guess_t = old_temperature_c.copy()
    guess_c = old_moisture_kg_kg.copy()

    heat_linear_max = 0.0
    moisture_linear_max = 0.0
    update_seen_max = 0.0
    converged = False

    for iteration in range(1, params.picard_max_iterations + 1):
        lower_t, diag_t, upper_t, rhs_t, _ = q2._heat_system(
            geometry,
            params,
            old_temperature_c,
            guess_c,
            ambient_temperature,
        )
        candidate_t = q2.solve_tridiagonal(lower_t, diag_t, upper_t, rhs_t)
        heat_linear = q2.relative_residual(
            q2.tridiagonal_matvec(lower_t, diag_t, upper_t, candidate_t) - rhs_t,
            rhs_t,
        )
        heat_linear_max = max(heat_linear_max, heat_linear)

        lower_c, diag_c, upper_c, rhs_c, _ = q2._moisture_system(
            geometry,
            params,
            old_moisture_kg_kg,
            guess_c,
            candidate_t,
            ambient_moisture,
        )
        candidate_c = q2.solve_tridiagonal(lower_c, diag_c, upper_c, rhs_c)
        moisture_linear = q2.relative_residual(
            q2.tridiagonal_matvec(lower_c, diag_c, upper_c, candidate_c) - rhs_c,
            rhs_c,
        )
        moisture_linear_max = max(moisture_linear_max, moisture_linear)

        if (
            np.any(~np.isfinite(candidate_t))
            or np.any(~np.isfinite(candidate_c))
            or np.any(candidate_c <= 0.0)
        ):
            raise FloatingPointError(
                f"t={next_time_s:g} s时产生非法温湿状态"
            )
        q2._validate_properties(candidate_c, candidate_t)

        update = normalized_update(candidate_t, guess_t, candidate_c, guess_c)
        update_seen_max = max(update_seen_max, update)

        lower_tr, diag_tr, upper_tr, rhs_tr, _ = q2._heat_system(
            geometry,
            params,
            old_temperature_c,
            candidate_c,
            ambient_temperature,
        )
        heat_nonlinear = q2.relative_residual(
            q2.tridiagonal_matvec(lower_tr, diag_tr, upper_tr, candidate_t)
            - rhs_tr,
            rhs_tr,
        )
        lower_cr, diag_cr, upper_cr, rhs_cr, _ = q2._moisture_system(
            geometry,
            params,
            old_moisture_kg_kg,
            candidate_c,
            candidate_t,
            ambient_moisture,
        )
        moisture_nonlinear = q2.relative_residual(
            q2.tridiagonal_matvec(lower_cr, diag_cr, upper_cr, candidate_c)
            - rhs_cr,
            rhs_cr,
        )

        if (
            update <= params.picard_update_tolerance
            and heat_nonlinear <= params.picard_residual_tolerance
            and moisture_nonlinear <= params.picard_residual_tolerance
        ):
            converged = True
            break

        omega = params.picard_relaxation
        guess_t = omega * candidate_t + (1.0 - omega) * guess_t
        guess_c = omega * candidate_c + (1.0 - omega) * guess_c

    if not converged:
        raise RuntimeError(
            f"t={next_time_s:g} s、dt={dt_s:g} s时Picard未在"
            f"{params.picard_max_iterations}次内收敛；update={update:.3e}, "
            f"heat_res={heat_nonlinear:.3e}, moisture_res={moisture_nonlinear:.3e}"
        )

    volumetric_capacity = (
        q2.density_kg_m3(candidate_c)
        * q2.heat_capacity_j_kg_k(candidate_c)
    )
    heat_cell_changes = (
        volumetric_capacity
        * geometry.cell_volumes_m2
        * (candidate_t - old_temperature_c)
    )
    heat_change = float(np.sum(heat_cell_changes))
    heat_boundary = float(
        dt_s
        * params.heat_transfer_w_m2_k
        * geometry.surface_area_m
        * (ambient_temperature - candidate_t[-1])
    )
    heat_balance_absolute = abs(heat_change - heat_boundary)
    heat_balance_scale = max(
        float(np.sum(np.abs(heat_cell_changes))) + abs(heat_boundary), 1.0e-30
    )

    moisture_cell_changes = geometry.cell_volumes_m2 * (
        candidate_c - old_moisture_kg_kg
    )
    moisture_change = float(np.sum(moisture_cell_changes))
    moisture_boundary = float(
        dt_s
        * params.mass_transfer_m_s
        * geometry.surface_area_m
        * (ambient_moisture - candidate_c[-1])
    )
    moisture_balance_absolute = abs(moisture_change - moisture_boundary)
    moisture_balance_scale = max(
        float(np.sum(np.abs(moisture_cell_changes))) + abs(moisture_boundary),
        1.0e-30,
    )

    step_diagnostics = {
        "max_temperature_linear_relative_residual": heat_linear_max,
        "max_moisture_linear_relative_residual": moisture_linear_max,
        "max_temperature_nonlinear_relative_residual": heat_nonlinear,
        "max_moisture_nonlinear_relative_residual": moisture_nonlinear,
        "max_picard_relative_update_encountered": update_seen_max,
        "max_final_picard_relative_update": update,
        # 长时间恒温阶段热通量和温度变化同时趋近机器零。此时二者之比
        # 没有物理意义，保留绝对残差并只对活动量>=1e-6 J/m的步报告相对值。
        "max_heat_balance_relative_residual": (
            heat_balance_absolute / heat_balance_scale
            if heat_balance_scale >= 1.0e-6
            else 0.0
        ),
        "max_moisture_balance_relative_residual": (
            moisture_balance_absolute / moisture_balance_scale
        ),
        "max_heat_balance_absolute_residual_j_per_m": heat_balance_absolute,
        "max_moisture_balance_absolute_residual_m2_kg_per_kg": (
            moisture_balance_absolute
        ),
        "picard_iterations": iteration,
        "temperature_min_c": float(np.min(candidate_t)),
        "temperature_max_c": float(np.max(candidate_t)),
        "moisture_min_kg_kg": float(np.min(candidate_c)),
        "moisture_max_kg_kg": float(np.max(candidate_c)),
        "temperature_radial_order_violations": int(
            np.count_nonzero(np.diff(candidate_t) < -1.0e-10)
        ),
        "moisture_radial_order_violations": int(
            np.count_nonzero(np.diff(candidate_c) > 1.0e-10)
        ),
    }
    return candidate_t, candidate_c, step_diagnostics


def _append_output(
    time_s: float,
    temperature_nodes_c: np.ndarray,
    moisture_nodes_kg_kg: np.ndarray,
    radius_nodes_m: np.ndarray,
    times: list[float],
    temperatures: list[np.ndarray],
    moistures: list[np.ndarray],
) -> None:
    if times and math.isclose(time_s, times[-1], abs_tol=1.0e-8):
        times[-1] = float(time_s)
        temperatures[-1] = np.interp(
            OUTPUT_RADII_M, radius_nodes_m, temperature_nodes_c
        )
        moistures[-1] = np.interp(
            OUTPUT_RADII_M, radius_nodes_m, moisture_nodes_kg_kg
        )
        return
    times.append(float(time_s))
    temperatures.append(
        np.interp(OUTPUT_RADII_M, radius_nodes_m, temperature_nodes_c)
    )
    moistures.append(
        np.interp(OUTPUT_RADII_M, radius_nodes_m, moisture_nodes_kg_kg)
    )


def solve_long_drying(
    boundary: ExtendedBoundary,
    config: Q3Config,
    intervals: int = 80,
    progress: bool = False,
) -> Q3Solution:
    if not (
        0.0
        < config.threshold_kg_kg
        < q2.Q2Parameters().initial_moisture_kg_kg
    ):
        raise ValueError("终止含水率阈值必须为正且低于初始含水率")
    for name in (
        "early_dt_s",
        "late_dt_s",
        "final_refine_dt_s",
        "output_interval_s",
    ):
        if getattr(config, name) <= 0.0:
            raise ValueError(f"{name}必须为正")
    if config.max_time_s <= config.transition_time_s:
        raise ValueError("max_time_s必须大于边界切换时刻")

    base_params = q2.Q2Parameters(
        intervals=intervals,
        time_step_s=config.early_dt_s,
        end_time_s=config.max_time_s,
        picard_max_iterations=200,
    )
    geometry = q2.build_geometry(base_params.radius_m, intervals)
    temperature = np.full(
        intervals + 1, base_params.initial_temperature_c, dtype=float
    )
    moisture = np.full(
        intervals + 1, base_params.initial_moisture_kg_kg, dtype=float
    )
    current_time = 0.0
    output_times: list[float] = []
    output_temperatures: list[np.ndarray] = []
    output_moistures: list[np.ndarray] = []
    _append_output(
        current_time,
        temperature,
        moisture,
        geometry.radius_nodes_m,
        output_times,
        output_temperatures,
        output_moistures,
    )
    next_output = config.output_interval_s
    next_progress = config.progress_interval_s
    diagnostics = DiagnosticAccumulator(
        temperature_min_c=float(np.min(temperature)),
        temperature_max_c=float(np.max(temperature)),
        moisture_min_kg_kg=float(np.min(moisture)),
        moisture_max_kg_kg=float(np.max(moisture)),
    )
    started = time.perf_counter()

    while current_time < config.max_time_s - 1.0e-9:
        in_early_stage = current_time < config.transition_time_s - 1.0e-9
        nominal_dt = config.early_dt_s if in_early_stage else config.late_dt_s
        dt_s = min(nominal_dt, config.max_time_s - current_time)
        if in_early_stage:
            dt_s = min(dt_s, config.transition_time_s - current_time)
        if next_output > current_time + 1.0e-9:
            dt_s = min(dt_s, next_output - current_time)
        if dt_s <= 1.0e-10:
            raise RuntimeError("时间推进出现非正步长")

        next_time = current_time + dt_s
        candidate_t, candidate_c, step_info = coupled_backward_euler_step(
            geometry,
            base_params,
            temperature,
            moisture,
            next_time,
            dt_s,
            boundary,
        )

        old_max = float(np.max(moisture))
        new_max = float(np.max(candidate_c))
        crossing = (
            old_max > config.threshold_kg_kg
            and new_max <= config.threshold_kg_kg
        )

        if crossing and dt_s > config.final_refine_dt_s + 1.0e-9:
            refined_t = temperature.copy()
            refined_c = moisture.copy()
            refined_time = current_time
            while refined_time < next_time - 1.0e-10:
                sub_dt = min(
                    config.final_refine_dt_s, next_time - refined_time
                )
                sub_next = refined_time + sub_dt
                sub_t, sub_c, sub_info = coupled_backward_euler_step(
                    geometry,
                    base_params,
                    refined_t,
                    refined_c,
                    sub_next,
                    sub_dt,
                    boundary,
                )
                previous_max = float(np.max(refined_c))
                sub_max = float(np.max(sub_c))
                if (
                    previous_max > config.threshold_kg_kg
                    and sub_max <= config.threshold_kg_kg
                ):
                    fraction = (previous_max - config.threshold_kg_kg) / max(
                        previous_max - sub_max, 1.0e-30
                    )
                    fraction = float(np.clip(fraction, 0.0, 1.0))
                    completion_time = refined_time + fraction * sub_dt
                    completion_t = refined_t + fraction * (sub_t - refined_t)
                    completion_c = refined_c + fraction * (sub_c - refined_c)
                    diagnostics.absorb(sub_info, sub_dt, "refined")
                    current_time = completion_time
                    temperature = completion_t
                    moisture = completion_c
                    break
                diagnostics.absorb(sub_info, sub_dt, "refined")
                refined_time = sub_next
                refined_t = sub_t
                refined_c = sub_c
                if math.isclose(
                    refined_time, next_output, abs_tol=1.0e-8
                ):
                    _append_output(
                        refined_time,
                        refined_t,
                        refined_c,
                        geometry.radius_nodes_m,
                        output_times,
                        output_temperatures,
                        output_moistures,
                    )
                    next_output += config.output_interval_s
            else:
                raise RuntimeError("末端1 s精化未能复现阈值穿越")
            _append_output(
                current_time,
                temperature,
                moisture,
                geometry.radius_nodes_m,
                output_times,
                output_temperatures,
                output_moistures,
            )
            break

        stage = "early" if in_early_stage else "late"
        diagnostics.absorb(step_info, dt_s, stage)
        current_time = next_time
        temperature = candidate_t
        moisture = candidate_c

        if math.isclose(current_time, next_output, abs_tol=1.0e-8):
            _append_output(
                current_time,
                temperature,
                moisture,
                geometry.radius_nodes_m,
                output_times,
                output_temperatures,
                output_moistures,
            )
            next_output += config.output_interval_s

        if progress and current_time + 1.0e-9 >= next_progress:
            print(
                f"N={intervals}, late_dt={config.late_dt_s:g}s, "
                f"t={current_time / SECONDS_PER_HOUR:.1f}h, "
                f"maxC={np.max(moisture):.6f}, "
                f"wall={time.perf_counter() - started:.1f}s",
                flush=True,
            )
            next_progress += config.progress_interval_s

        if float(np.max(moisture)) <= config.threshold_kg_kg:
            _append_output(
                current_time,
                temperature,
                moisture,
                geometry.radius_nodes_m,
                output_times,
                output_temperatures,
                output_moistures,
            )
            break
    else:
        raise RuntimeError(
            f"计算至{config.max_time_s / SECONDS_PER_HOUR:.1f} h仍未达到"
            f"C<{config.threshold_kg_kg:g}；maxC={np.max(moisture):.6f}"
        )

    max_index = int(np.argmax(moisture))
    diagnostic_payload = diagnostics.as_dict()
    diagnostic_payload.update(
        {
            "config": asdict(config),
            "intervals": intervals,
            "nodes": intervals + 1,
            "dr_m": geometry.dr_m,
            "completion_time_s": float(current_time),
            "completion_time_h": float(current_time / SECONDS_PER_HOUR),
            "threshold_kg_kg": config.threshold_kg_kg,
            "maximum_moisture_at_completion_kg_kg": float(np.max(moisture)),
            "minimum_moisture_at_completion_kg_kg": float(np.min(moisture)),
            "maximum_location_at_completion_cm": float(
                geometry.radius_nodes_m[max_index] * 100.0
            ),
            "all_nodes_at_or_below_threshold": bool(
                np.all(moisture <= config.threshold_kg_kg + 5.0e-10)
            ),
            "plateau_temperature_c": boundary.plateau_temperature_c,
            "plateau_temperature_std_c": boundary.plateau_temperature_std_c,
            "plateau_moisture_kg_kg": boundary.plateau_moisture_kg_kg,
            "plateau_moisture_std_kg_kg": boundary.plateau_moisture_std_kg_kg,
            "runtime_s": time.perf_counter() - started,
            "stored_output_rows": len(output_times),
            "stored_output_radii": len(OUTPUT_RADII_M),
            "latent_heat_included": False,
        }
    )
    return Q3Solution(
        times_s=np.asarray(output_times),
        radius_output_m=OUTPUT_RADII_M.copy(),
        temperature_output_c=np.asarray(output_temperatures),
        moisture_output_kg_kg=np.asarray(output_moistures),
        completion_time_s=float(current_time),
        completion_temperature_nodes_c=temperature.copy(),
        completion_moisture_nodes_kg_kg=moisture.copy(),
        radius_nodes_m=geometry.radius_nodes_m.copy(),
        diagnostics=diagnostic_payload,
    )


def interpolate_time_fields(
    solution: Q3Solution, target_times_s: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    target_times = np.asarray(target_times_s, dtype=float)
    if np.any(target_times < -1.0e-9) or np.any(
        target_times > solution.completion_time_s + 1.0e-6
    ):
        raise ValueError("目标时刻超出数值解时间范围")
    temperatures = np.column_stack(
        [
            np.interp(target_times, solution.times_s, column)
            for column in solution.temperature_output_c.T
        ]
    )
    moistures = np.column_stack(
        [
            np.interp(target_times, solution.times_s, column)
            for column in solution.moisture_output_kg_kg.T
        ]
    )
    return temperatures, moistures


def compare_solutions(
    candidate: Q3Solution,
    reference: Q3Solution,
    paper_interval_s: float,
) -> dict:
    common_end = min(candidate.completion_time_s, reference.completion_time_s)
    report_times = np.arange(
        paper_interval_s,
        math.floor(common_end / paper_interval_s) * paper_interval_s + 1.0,
        paper_interval_s,
    )
    if report_times.size == 0:
        report_times = np.asarray([common_end])
    candidate_t, candidate_c = interpolate_time_fields(candidate, report_times)
    reference_t, reference_c = interpolate_time_fields(reference, report_times)
    return {
        "candidate_completion_time_h": (
            candidate.completion_time_s / SECONDS_PER_HOUR
        ),
        "reference_completion_time_h": (
            reference.completion_time_s / SECONDS_PER_HOUR
        ),
        "completion_time_difference_s": (
            candidate.completion_time_s - reference.completion_time_s
        ),
        "completion_time_absolute_difference_min": abs(
            candidate.completion_time_s - reference.completion_time_s
        ) / 60.0,
        "completion_time_relative_difference_percent": 100.0
        * abs(candidate.completion_time_s - reference.completion_time_s)
        / reference.completion_time_s,
        "common_report_time_count": int(report_times.size),
        "report_max_abs_temperature_c": float(
            np.max(np.abs(candidate_t - reference_t))
        ),
        "report_max_abs_moisture_kg_kg": float(
            np.max(np.abs(candidate_c - reference_c))
        ),
    }


def _write_csv(path: Path, header: str, rows: np.ndarray) -> None:
    np.savetxt(
        path,
        rows,
        delimiter=",",
        header=header,
        comments="",
        fmt="%.12g",
    )


def write_main_outputs(
    output_dir: Path,
    solution: Q3Solution,
    boundary: ExtendedBoundary,
    config: Q3Config,
    validation: dict,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    radius_headers = [
        f"r_{radius_m * 100.0:.1f}_cm" for radius_m in solution.radius_output_m
    ]
    moisture_rows = np.column_stack(
        [solution.times_s, solution.moisture_output_kg_kg]
    )
    _write_csv(
        output_dir / "result3_moisture.csv",
        ",".join(["time_s", *radius_headers]),
        moisture_rows,
    )

    temperature_rows = np.column_stack(
        [solution.times_s, solution.temperature_output_c]
    )
    _write_csv(
        output_dir / "question3_temperature_history.csv",
        ",".join(["time_s", *radius_headers]),
        temperature_rows,
    )

    regular_report_times = np.arange(
        config.paper_interval_s,
        math.floor(solution.completion_time_s / config.paper_interval_s)
        * config.paper_interval_s
        + 1.0,
        config.paper_interval_s,
    )
    report_times = regular_report_times
    if (
        report_times.size == 0
        or not math.isclose(
            report_times[-1], solution.completion_time_s, abs_tol=1.0e-8
        )
    ):
        report_times = np.append(report_times, solution.completion_time_s)
    _, report_moisture_all = interpolate_time_fields(solution, report_times)
    radius_indices = [
        int(np.argmin(np.abs(solution.radius_output_m - radius)))
        for radius in PAPER_RADII_M
    ]
    report_moisture = report_moisture_all[:, radius_indices]
    labels = np.zeros(len(report_times), dtype=float)
    labels[-1] = 1.0
    report_rows = np.column_stack(
        [
            report_times,
            report_times / SECONDS_PER_HOUR,
            labels,
            report_moisture,
        ]
    )
    _write_csv(
        output_dir / "question3_table5.csv",
        "time_s,time_h,is_completion_time,"
        "r_0.0_cm,r_0.5_cm,r_1.0_cm,r_1.5_cm,r_2.0_cm",
        report_rows,
    )

    history_indices = np.arange(0, len(solution.times_s), 10, dtype=int)
    if history_indices[-1] != len(solution.times_s) - 1:
        history_indices = np.append(history_indices, len(solution.times_s) - 1)
    history_rows = np.column_stack(
        [
            solution.times_s[history_indices],
            solution.times_s[history_indices] / SECONDS_PER_HOUR,
            solution.temperature_output_c[history_indices, 0],
            solution.temperature_output_c[history_indices, -1],
            solution.moisture_output_kg_kg[history_indices, 0],
            solution.moisture_output_kg_kg[history_indices, 5],
            solution.moisture_output_kg_kg[history_indices, 10],
            solution.moisture_output_kg_kg[history_indices, 15],
            solution.moisture_output_kg_kg[history_indices, -1],
            np.max(solution.moisture_output_kg_kg[history_indices], axis=1),
        ]
    )
    _write_csv(
        output_dir / "question3_plot_history.csv",
        "time_s,time_h,temperature_center_c,temperature_surface_c,"
        "moisture_r0_kg_kg,moisture_r0.5_kg_kg,moisture_r1.0_kg_kg,"
        "moisture_r1.5_kg_kg,moisture_r2.0_kg_kg,maximum_moisture_kg_kg",
        history_rows,
    )

    candidate_hours = [6.0, 12.0, 24.0, 48.0]
    profile_hours = [
        value
        for value in candidate_hours
        if value * SECONDS_PER_HOUR < solution.completion_time_s - 1.0e-6
    ]
    completion_h = solution.completion_time_s / SECONDS_PER_HOUR
    if not profile_hours or not math.isclose(
        profile_hours[-1], completion_h, abs_tol=1.0e-8
    ):
        profile_hours.append(completion_h)
    profile_times = np.asarray(profile_hours) * SECONDS_PER_HOUR
    profile_t, profile_c = interpolate_time_fields(solution, profile_times)
    profile_rows: list[list[float]] = []
    for row_index, target_time in enumerate(profile_times):
        for radius_index, radius_m in enumerate(solution.radius_output_m):
            profile_rows.append(
                [
                    target_time,
                    target_time / SECONDS_PER_HOUR,
                    radius_m * 100.0,
                    profile_t[row_index, radius_index],
                    profile_c[row_index, radius_index],
                ]
            )
    _write_csv(
        output_dir / "question3_radial_profiles.csv",
        "time_s,time_h,radius_cm,temperature_c,moisture_kg_kg",
        np.asarray(profile_rows),
    )

    boundary_times = np.arange(
        0.0, solution.completion_time_s + config.output_interval_s,
        config.output_interval_s,
    )
    boundary_times = boundary_times[boundary_times <= solution.completion_time_s]
    boundary_rows = np.column_stack(
        [
            boundary_times,
            boundary_times / SECONDS_PER_HOUR,
            boundary.temperature(boundary_times),
            boundary.moisture(boundary_times),
        ]
    )
    _write_csv(
        output_dir / "question3_boundary.csv",
        "time_s,time_h,ambient_temperature_c,ambient_moisture_kg_kg",
        boundary_rows,
    )

    summary = {
        "main_result": {
            "drying_completion_time_s": solution.completion_time_s,
            "drying_completion_time_h": (
                solution.completion_time_s / SECONDS_PER_HOUR
            ),
            "drying_completion_time_d": (
                solution.completion_time_s / (24.0 * SECONDS_PER_HOUR)
            ),
            "threshold_kg_kg": config.threshold_kg_kg,
            "maximum_moisture_at_completion_kg_kg": float(
                np.max(solution.completion_moisture_nodes_kg_kg)
            ),
            "minimum_moisture_at_completion_kg_kg": float(
                np.min(solution.completion_moisture_nodes_kg_kg)
            ),
            "center_moisture_at_completion_kg_kg": float(
                solution.completion_moisture_nodes_kg_kg[0]
            ),
            "surface_moisture_at_completion_kg_kg": float(
                solution.completion_moisture_nodes_kg_kg[-1]
            ),
            "center_temperature_at_completion_c": float(
                solution.completion_temperature_nodes_c[0]
            ),
            "surface_temperature_at_completion_c": float(
                solution.completion_temperature_nodes_c[-1]
            ),
            "last_regular_output_time_s": float(
                solution.times_s[-2]
                if not math.isclose(
                    solution.times_s[-1] % config.output_interval_s,
                    0.0,
                    abs_tol=1.0e-8,
                )
                else solution.times_s[-1]
            ),
        },
        "model_and_assumptions": {
            "space": "node-centered conservative finite volume",
            "time": "backward Euler with piecewise fixed step",
            "nonlinear_solver": "coupled Picard iteration",
            "initial_and_material_parameters": "A题问题2及附录3",
            "boundary_extension": (
                "附件1结束后使用末段稳定时间窗均值"
                if config.plateau_mode == "window-mean"
                else "附件1结束后保持最后一个测点"
            ),
            "latent_heat_included": False,
            "radius_change_included": False,
        },
        "boundary_extension": {
            "attachment_end_time_s": config.transition_time_s,
            "plateau_mode": boundary.plateau_mode,
            "plateau_window_s": boundary.plateau_window_s,
            "plateau_temperature_c": boundary.plateau_temperature_c,
            "plateau_temperature_std_c": boundary.plateau_temperature_std_c,
            "plateau_moisture_kg_kg": boundary.plateau_moisture_kg_kg,
            "plateau_moisture_std_kg_kg": (
                boundary.plateau_moisture_std_kg_kg
            ),
        },
        "diagnostics": solution.diagnostics,
        "validation": validation,
        "interpretation": (
            "烘干结束定义为全部空间节点含水率首次不高于0.15 kg/kg。"
            f"本次结果采用{solution.diagnostics['intervals']}区间、"
            f"前4 h步长{config.early_dt_s:g} s、"
            f"后期步长{config.late_dt_s:g} s；"
            "需结合时间、空间及边界延拓敏感性共同解释。"
        ),
    }
    with (output_dir / "question3_summary.json").open(
        "w", encoding="utf-8"
    ) as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2)
    with (output_dir / "question3_validation.json").open(
        "w", encoding="utf-8"
    ) as stream:
        json.dump(validation, stream, ensure_ascii=False, indent=2)


def run_validation(
    source: q2.BoundaryData,
    main_solution: Q3Solution,
    main_config: Q3Config,
) -> dict:
    main_intervals = int(main_solution.diagnostics["intervals"])
    result: dict[str, dict] = {}
    # Keep the validation experiment fixed even if the main-case settings differ.
    validation_config = replace(
        main_config, early_dt_s=1.0, late_dt_s=30.0,
        plateau_window_s=3600.0, plateau_mode="window-mean",
    )
    cache: dict[tuple[int, float, float, float, str], Q3Solution] = {
        (
            main_intervals,
            main_config.early_dt_s,
            main_config.late_dt_s,
            main_config.plateau_window_s,
            main_config.plateau_mode,
        ): main_solution
    }

    def get_case(config: Q3Config, intervals: int, name: str) -> Q3Solution:
        key = (
            intervals,
            config.early_dt_s,
            config.late_dt_s,
            config.plateau_window_s,
            config.plateau_mode,
        )
        if key not in cache:
            print(f"开始验证算例：{name}", flush=True)
            case_boundary = build_extended_boundary(source, config)
            cache[key] = solve_long_drying(
                case_boundary, config, intervals=intervals, progress=False
            )
            print(
                f"完成验证算例：{name}，结束时间="
                f"{cache[key].completion_time_s / SECONDS_PER_HOUR:.6f} h",
                flush=True,
            )
        return cache[key]

    # 时间步和边界延拓敏感性固定在N=80，避免与空间误差混杂。
    anchor_80 = get_case(validation_config, 80, "anchor_80")
    for name, config in {
        "time_N80_dt15_vs_dt30": replace(validation_config, late_dt_s=15.0),
        "time_N80_dt60_vs_dt30": replace(validation_config, late_dt_s=60.0),
        "boundary_N80_last30min_vs_last1h": replace(
            validation_config, plateau_window_s=1800.0
        ),
        "boundary_N80_lastpoint_vs_last1h": replace(
            validation_config, plateau_mode="last-point"
        ),
    }.items():
        solution = get_case(config, 80, name)
        result[name] = {
            "comparison_with_N80_dt30_last1h_mean": compare_solutions(
                solution, anchor_80, main_config.paper_interval_s
            ),
            "diagnostics": solution.diagnostics,
        }

    # 空间验证统一使用dt=30 s、最后1 h均值，形成80/160/320/640序列。
    spatial: dict[int, Q3Solution] = {80: anchor_80}
    for intervals in (160, 320, 640):
        spatial[intervals] = get_case(
            validation_config, intervals, f"space_{intervals}_intervals"
        )
    for coarse, fine in ((80, 160), (160, 320), (320, 640)):
        result[f"space_N{coarse}_vs_N{fine}"] = {
            "comparison": compare_solutions(
                spatial[coarse], spatial[fine], main_config.paper_interval_s
            ),
            "coarse_diagnostics": spatial[coarse].diagnostics,
            "fine_diagnostics": spatial[fine].diagnostics,
        }
    # The original report also compared dt=30/60 s on the final N=640 grid.
    time_640 = get_case(replace(validation_config, late_dt_s=60.0), 640, "time_N640_dt60")
    result["time_N640_dt60_vs_dt30"] = {
        "reference_late_dt_s": 30.0, "candidate_late_dt_s": 60.0,
        "comparison": compare_solutions(time_640, spatial[640], main_config.paper_interval_s),
        "diagnostics": time_640.diagnostics,
    }
    common_times = np.intersect1d(spatial[320].times_s, spatial[640].times_s)
    t320, c320 = interpolate_time_fields(spatial[320], common_times)
    t640, c640 = interpolate_time_fields(spatial[640], common_times)
    result["space_N320_vs_N640"]["full_output_difference"] = {
        "common_time_count": int(len(common_times)),
        "max_abs_temperature_c": float(np.max(np.abs(t320 - t640))),
        "max_abs_moisture_kg_kg": float(np.max(np.abs(c320 - c640))),
    }
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="问题3长时间烘干求解器")
    parser.add_argument("--input", type=package_path, default=package_path("附件1.xlsx"), help="输入附件；相对路径以代码文件夹为基准")
    parser.add_argument("--output-dir", type=package_path, default=package_path("results"), help="本次计算的CSV、JSON和Excel目录")
    parser.add_argument("--intervals", type=int, default=640)
    parser.add_argument("--early-dt", type=float, default=1.0)
    parser.add_argument("--late-dt", type=float, default=30.0)
    parser.add_argument("--transition-time", type=float, default=14400.0)
    parser.add_argument("--plateau-window", type=float, default=3600.0)
    parser.add_argument(
        "--plateau-mode",
        choices=("window-mean", "last-point"),
        default="window-mean",
    )
    parser.add_argument("--threshold", type=float, default=0.15)
    parser.add_argument("--max-time", type=float, default=604800.0)
    parser.add_argument("--skip-validation", action="store_true")
    parser.add_argument("--plots", action="store_true", help="计算结束后使用Matplotlib生成论文图")
    parser.add_argument("--figures-dir", type=package_path, default=None, help="图目录；默认在本次输出目录内的figures子目录")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    require_file(args.input)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    config = Q3Config(
        threshold_kg_kg=args.threshold,
        transition_time_s=args.transition_time,
        plateau_window_s=args.plateau_window,
        plateau_mode=args.plateau_mode,
        early_dt_s=args.early_dt,
        late_dt_s=args.late_dt,
        max_time_s=args.max_time,
    )
    source = q2.read_boundary_data(args.input, config.transition_time_s)
    boundary = build_extended_boundary(source, config)
    print(
        "问题3主算例："
        f"N={args.intervals}, early_dt={config.early_dt_s:g}s, "
        f"late_dt={config.late_dt_s:g}s, "
        f"plateau T={boundary.plateau_temperature_c:.6f}°C, "
        f"plateau C={boundary.plateau_moisture_kg_kg:.8f}",
        flush=True,
    )
    main_solution = solve_long_drying(
        boundary, config, intervals=args.intervals, progress=True
    )
    print(
        "主算例完成："
        f"t_dry={main_solution.completion_time_s / SECONDS_PER_HOUR:.6f} h",
        flush=True,
    )
    # Save the main result first, so long validation runs do not delay Excel output.
    validation = {}
    write_main_outputs(
        args.output_dir, main_solution, boundary, config, validation
    )
    from question3_export_workbooks import export_workbooks
    from question3_collect_validation import collect_validation
    for path in export_workbooks(args.output_dir):
        print(f"已生成Excel：{path}", flush=True)
    collect_validation(args.output_dir)
    write_reproduction_info(args.output_dir, args.input)
    if not args.skip_validation:
        validation = run_validation(source, main_solution, config)
        (args.output_dir / "question3_validation.json").write_text(
            json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        summary_path = args.output_dir / "question3_summary.json"
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        summary["validation"] = validation
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        collect_validation(args.output_dir)
    if args.plots:
        from question3_plot_results import create_figures
        create_figures(args.output_dir, args.figures_dir or args.output_dir / "figures")
    payload = {
        "drying_completion_time_s": main_solution.completion_time_s,
        "drying_completion_time_h": (
            main_solution.completion_time_s / SECONDS_PER_HOUR
        ),
        "drying_completion_time_d": (
            main_solution.completion_time_s / (24.0 * SECONDS_PER_HOUR)
        ),
        "center_moisture_kg_kg": float(
            main_solution.completion_moisture_nodes_kg_kg[0]
        ),
        "surface_moisture_kg_kg": float(
            main_solution.completion_moisture_nodes_kg_kg[-1]
        ),
        "validation_cases": list(validation),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
