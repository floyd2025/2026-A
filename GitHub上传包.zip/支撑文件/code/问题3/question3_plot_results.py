"""Portable Q3 plots using Matplotlib only; no private figure-tool dependencies."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from q3_paths import package_path, require_file

ZH = True
COLORS = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7"]
STYLES = ["-", "--", "-.", ":", (0, (5, 2))]


def label(chinese: str, english: str) -> str:
    return chinese if ZH else english


def configure_style(language: str) -> None:
    global ZH
    fonts = {item.name for item in font_manager.fontManager.ttflist}
    candidates = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Source Han Sans SC", "PingFang SC", "WenQuanYi Micro Hei"]
    selected = next((name for name in candidates if name in fonts), None)
    if language == "zh" and not selected:
        raise ValueError("未找到中文字体，请安装Noto Sans CJK SC，或使用--language en。")
    ZH = language == "zh" or (language == "auto" and selected is not None)
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [selected, "DejaVu Sans"] if ZH else ["DejaVu Sans"],
        "axes.unicode_minus": False,
        "font.size": 10,
        "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "pdf.fonttype": 42, "svg.fonttype": "path",
        "figure.constrained_layout.use": True,
    })


def read_numeric_csv(path: Path) -> dict[str, np.ndarray]:
    with require_file(path).open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError(f"CSV没有数据：{path.name}")
    return {key: np.array([float(row[key]) for row in rows]) for key in rows[0]}


def style_axes(ax) -> None:
    ax.grid(alpha=0.25, linewidth=0.6)
    ax.set_axisbelow(True)


def save_figure(fig, out: Path, name: str, manifest: list, dpi: int, formats: tuple) -> None:
    fig.canvas.draw()
    files = []
    for extension in formats:
        path = out / f"{name}.{extension}"
        fig.savefig(path, dpi=dpi, bbox_inches="tight", facecolor="white")
        files.append(path.name)
    manifest.append({"name": name, "files": files, "dpi_for_raster": dpi})
    plt.close(fig)


def create_figures(data_dir: Path, output_dir: Path, language: str = "auto",
                   dpi: int = 600, formats: tuple = ("png", "pdf", "svg", "tiff")) -> list:
    data_dir, output_dir = Path(data_dir), Path(output_dir)
    configure_style(language)
    summary = json.loads(require_file(data_dir / "question3_summary.json").read_text(encoding="utf-8-sig"))
    boundary = read_numeric_csv(data_dir / "question3_boundary.csv")
    history = read_numeric_csv(data_dir / "question3_plot_history.csv")
    profiles = read_numeric_csv(data_dir / "question3_radial_profiles.csv")
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = []

    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), sharex=True)
    transition_h = summary["boundary_extension"]["attachment_end_time_s"] / 3600
    for ax, key, ylabel, title, color in (
        (axes[0], "ambient_temperature_c", label("外界温度 / °C", "Ambient temperature / °C"), label("(a) 温度边界", "(a) Temperature boundary"), COLORS[3]),
        (axes[1], "ambient_moisture_kg_kg", label("外界水分浓度 / (kg/kg)", "Ambient moisture / (kg/kg)"), label("(b) 水分边界", "(b) Moisture boundary"), COLORS[0]),
    ):
        ax.plot(boundary["time_h"], boundary[key], color=color)
        ax.axvline(transition_h, color="0.4", linestyle="--", linewidth=0.8)
        ax.set(xlabel=label("时间 / h", "Time / h"), ylabel=ylabel, title=title)
        style_axes(ax)
    save_figure(fig, output_dir, "q3_boundary_extension", manifest, dpi, formats)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    for i, (key, radius) in enumerate([
        ("moisture_r0_kg_kg", 0), ("moisture_r0.5_kg_kg", 0.5),
        ("moisture_r1.0_kg_kg", 1), ("moisture_r1.5_kg_kg", 1.5), ("moisture_r2.0_kg_kg", 2),
    ]):
        ax.plot(history["time_h"], history[key], color=COLORS[i], linestyle=STYLES[i], label=f"r = {radius:g} cm")
    threshold = summary["main_result"]["threshold_kg_kg"]
    end_h = summary["main_result"]["drying_completion_time_h"]
    ax.axhline(threshold, color="0.3", linestyle="--", linewidth=0.9, label=label("终止阈值", "Threshold"))
    ax.axvline(end_h, color="0.5", linestyle=":", linewidth=0.9)
    ax.set(xlabel=label("时间 / h", "Time / h"), ylabel="C / (kg/kg)",
           title=label(f"含水率随时间变化（终止时间 {end_h:.4f} h）", f"Moisture history (completion: {end_h:.4f} h)"),
           xlim=(0, end_h * 1.03), ylim=(0, max(history["moisture_r0_kg_kg"]) * 1.05))
    ax.legend(ncol=2)
    style_axes(ax)
    save_figure(fig, output_dir, "q3_moisture_history", manifest, dpi, formats)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    times = np.unique(profiles["time_h"])
    for i, time_h in enumerate(times):
        mask = np.isclose(profiles["time_h"], time_h, rtol=0, atol=1e-8)
        name = label("终止时刻", "Completion") if i == len(times)-1 else f"{time_h:g} h"
        ax.plot(profiles["radius_cm"][mask], profiles["moisture_kg_kg"][mask],
                color=COLORS[i % len(COLORS)], linestyle=STYLES[i % len(STYLES)],
                marker="o", markersize=3, markevery=3, label=name)
    ax.axhline(threshold, color="0.4", linestyle="--", linewidth=0.9)
    ax.set(xlabel=label("到中心距离 / cm", "Distance from center / cm"), ylabel="C / (kg/kg)",
           title=label("不同时刻的径向含水率", "Radial moisture profiles"), xlim=(0, 2))
    ax.legend(ncol=2)
    style_axes(ax)
    save_figure(fig, output_dir, "q3_radial_moisture_profiles", manifest, dpi, formats)

    validation_path = data_dir / "question3_validation_final.json"
    validation = json.loads(validation_path.read_text(encoding="utf-8-sig")) if validation_path.is_file() else {}
    if validation.get("status") == "complete":
        convergence = read_numeric_csv(data_dir / "question3_completion_convergence.csv")
        fig, axes = plt.subplots(1, 2, figsize=(10, 4.3))
        x, y = convergence["intervals"], convergence["completion_time_h"]
        axes[0].plot(x, y, "o-", color=COLORS[0])
        axes[0].set_xscale("log", base=2)
        axes[0].set_xticks(x, [str(int(n)) for n in x])
        axes[0].set(xlabel=label("空间区间数 N", "Spatial intervals N"),
                    ylabel=label("终止时间 / h", "Completion time / h"),
                    title=label("(a) 空间网格比较", "(a) Spatial refinement"))
        values, names = [], []
        temporal = validation.get("temporal_sensitivity_n640")
        if temporal:
            values.append(temporal["relative_difference_percent"])
            names.append("dt 60/30 s\nN=640")
        cases = validation["boundary_extension_sensitivity_n80"]
        for key, name in (
            ("boundary_N80_last30min_vs_last1h", label("末30/60 min\nN=80", "Last 30/60 min\nN=80")),
            ("boundary_N80_lastpoint_vs_last1h", label("末点/60 min\nN=80", "Last point/60 min\nN=80")),
        ):
            values.append(cases[key]["completion_time_relative_difference_percent"])
            names.append(name)
        positions = np.arange(len(values))
        axes[1].bar(positions, values, color=COLORS[:len(values)], width=0.55)
        axes[1].set_xticks(positions, names)
        axes[1].set(ylabel=label("终止时间相对差 / %", "Relative completion-time difference / %"),
                    title=label("(b) 时间步与边界延拓", "(b) Time step and boundary extension"))
        axes[1].set_ylim(0, max(max(values) * 1.25, 1e-8))
        for pos, value in zip(positions, values):
            axes[1].text(pos, value, f"{value:.4f}", ha="center", va="bottom", fontsize=9)
        for ax in axes:
            style_axes(ax)
        save_figure(fig, output_dir, "q3_numerical_validation", manifest, dpi, formats)

    info = {"renderer": "matplotlib", "language": "zh" if ZH else "en", "figures": manifest,
            "validation_figure_generated": validation.get("status") == "complete"}
    (output_dir / "figure_manifest.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"已生成 {len(manifest)} 张图：{output_dir}", flush=True)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Q3论文图：只需Matplotlib，不依赖私人辅助目录")
    parser.add_argument("--data-dir", default="results")
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--language", choices=("auto", "zh", "en"), default="auto")
    parser.add_argument("--dpi", type=int, default=600)
    parser.add_argument("--formats", nargs="+", choices=("png", "pdf", "svg", "tiff"), default=["png", "pdf", "svg", "tiff"])
    args = parser.parse_args()
    if args.dpi <= 0:
        parser.error("--dpi必须为正")
    data_dir = package_path(args.data_dir)
    create_figures(data_dir, package_path(args.output_dir) if args.output_dir else data_dir / "figures",
                   args.language, args.dpi, tuple(args.formats))


if __name__ == "__main__":
    main()

