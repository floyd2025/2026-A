"""Portable paths shared by the Q3 command-line tools."""
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent


def package_path(value: str | Path) -> Path:
    """Relative CLI paths are relative to this package, not the terminal cwd."""
    path = Path(value).expanduser()
    return (path if path.is_absolute() else PACKAGE_DIR / path).resolve()


def require_file(path: Path) -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"找不到文件：{path}。请检查输入参数或先运行主求解器。")
    return path


def write_reproduction_info(output_dir: Path, input_path: Path) -> None:
    """Record versions and hashes without embedding the author's machine paths."""
    import hashlib
    import json
    import platform
    from importlib.metadata import version, PackageNotFoundError
    packages = {}
    for name in ("numpy", "openpyxl", "matplotlib", "Pillow"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    info = {
        "python": platform.python_version(), "platform": platform.system(),
        "packages": packages, "input_file": input_path.name,
        "input_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
        "source_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(PACKAGE_DIR.glob("*.py"))
        },
        "path_policy": "Default and relative CLI paths resolve against the package directory.",
    }
    (output_dir / "reproduction_info.json").write_text(
        json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8"
    )
