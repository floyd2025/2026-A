# 中药材热风烘干过程的传热传质建模与分析

本项目整理了数学建模论文、问题 1–4 的 Python 求解程序、输入附件及正式结果。模型涉及圆柱径向传热传质、有限体积离散、后向欧拉时间推进、变物性温湿耦合及收缩区域计算。

## 文件结构

| 位置 | 内容 |
| --- | --- |
| `论文/main.pdf` | 已有论文阅读版，包含正文与代码附录 |
| `论文/main.tex`、`cumcmthesis.cls`、`cumcm2026.sty` | LaTeX 源码与模板 |
| `论文/figures/` | 论文使用的六张 PDF 插图 |
| `论文/code/` | 论文附录引用的代码快照，编译论文时需要 |
| `支撑文件/code/问题1/` | 问题 1 求解、交叉验证、绘图及附件 |
| `支撑文件/code/问题2/` | 问题 2 附件，程序位于 `代码/` 子目录 |
| `支撑文件/code/问题3/` | 问题 3 长时间烘干模型、结果导出及附件 |
| `支撑文件/code/问题4/` | 问题 4 收缩模型、一键运行入口及两个附件 |
| `支撑文件/results/` | 原项目提供的 `result1.xlsx` 至 `result4.xlsx` 正式结果 |
| `支撑文件/ai声明/` | 原项目的 AI 工具使用说明及其 LaTeX 源码 |

`论文/code/` 和 `支撑文件/code/` 有部分相同文件，这是为了保留论文附录引用和各问题程序的依赖。实际运行优先使用 `支撑文件/code/`。

## Python 环境与运行

建议使用 Python 3.10 或更新版本。在仓库根目录安装依赖：

```bash
python -m pip install -r requirements.txt
```

各问题的主要运行入口如下。完整计算和加密验证可能耗时较长。

```bash
python "支撑文件/code/问题1/question1_fvm_backward_euler.py"
python "支撑文件/code/问题2/代码/question2_coupled_fvm.py"
python "支撑文件/code/问题3/question3_long_drying_fvm.py"
python "支撑文件/code/问题4/run_question4_all.py"
```

可以先给求解脚本加上 `--help` 查看参数；问题 4 支持 `--dry-run` 查看将执行的命令，支持 `--main-only` 仅运行主模型。

问题 2 的 Python 求解器主要输出 CSV、NPZ 和 JSON。现成的正式 Excel 在 `支撑文件/results/`。`build_question2_workbooks.mjs` 是依赖 `@oai/artifact-tool` 和既定 `outputs/` 目录结构的辅助导出脚本，不属于普通 Python 环境的必要步骤。

论文绘图脚本 `论文/code/figures/generate_paper_figures.py` 需要指定结构的中间数值数据，当前文件夹没有包含其全部输入，不能直接运行重建全部插图。已生成的六张插图保留在 `论文/figures/`。本次整理没有重新求解模型或核验论文数值结论。

## 编译论文

安装包含中文字体和所需宏包的 TeX 环境，在 `论文/` 目录运行：

```bash
xelatex main.tex
xelatex main.tex
```

参考文献直接写在 `thebibliography` 中；保留 `code/` 和 `figures/` 的相对位置。AI 使用说明可在 `支撑文件/ai声明/` 单独用 XeLaTeX 编译。

## 文件与隐私约定

这份副本已清空论文源码的学校、报名号、队员和指导教师字段，移除 PDF 文档元数据、Excel 作者和自定义属性、本机路径与打印机配置。Excel 单元格、公式和样式保持原有内容。

编译日志、IDE 配置、字节码缓存、临时脚本和运行输出目录没有收录。`.gitignore` 只允许当前已检查的文件；新增文件需检查后再加入白名单。该规则不能阻止浏览器手工上传，也不会自动检查或清理已跟踪文件的后续修改。重新运行程序生成的文件仍可能含本机路径，上传前应再次检查。

模板原有声明和论文文献引用予以保留。本次整理没有新增开源许可证。
