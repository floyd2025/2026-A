# 论文文件

`main.pdf` 为现有论文阅读版；`main.tex` 为对应源码。使用 XeLaTeX，在本目录执行 `xelatex main.tex` 两次。编译时需要保留 `figures/`、`code/`、`cumcmthesis.cls` 和 `cumcm2026.sty`。

源码中的学校、报名号、队员和指导教师字段已置空。当前使用 `withoutpreface`，不生成身份信息页。

`code/` 是论文附录所引用的代码快照；可运行程序、输入附件、结果和 AI 使用说明见仓库根目录的 `支撑文件/`。使用方式与已知限制见根目录 README。
