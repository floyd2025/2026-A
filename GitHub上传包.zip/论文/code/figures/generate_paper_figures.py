#!/usr/bin/env python3
"""根据问题1—4的最终数值结果，重绘评审要求的论文图。

输出：PDF、SVG、600 dpi PNG/TIFF、灰度预览、QA预览和图件清单。
本脚本只做后处理，不重新求解或修改任何模型参数。
"""

from __future__ import annotations

import argparse
import csv
import json
import warnings
from pathlib import Path

import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from openpyxl import load_workbook
from PIL import Image


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_PROJECT_ROOT = SCRIPT_DIR.parents[1]

COLORS = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7"]
LINE_STYLES = ["-", "--", "-.", ":", (0, (5, 2))]
MARKERS = ["o", "s", "^", "D", "v"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="重绘评审要求的论文图")
    parser.add_argument(
        "--project-root",
        type=Path,
        default=DEFAULT_PROJECT_ROOT,
        help="包含outputs目录的项目根目录",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "figures",
        help="图片输出目录",
    )
    return parser.parse_args()


def configure_style() -> dict[str, str]:
    available = {entry.name for entry in font_manager.fontManager.ttflist}
    preferred = [
        "Noto Serif CJK SC",
        "Source Han Serif SC",
        "SimSun",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Microsoft YaHei",
        "SimHei",
    ]
    selected = next((name for name in preferred if name in available), None)
    if selected is None:
        raise RuntimeError(
            "未检测到中文字体。请安装Noto Serif CJK SC、宋体或微软雅黑后重试。"
        )
    mpl.rcParams.update(
        {
            "font.family": selected,
            "mathtext.fontset": "stix",
            "axes.unicode_minus": False,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "figure.constrained_layout.use": True,
            "font.size": 8.5,
            "axes.labelsize": 9,
            "axes.titlesize": 9.5,
            "axes.titleweight": "semibold",
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 7.7,
            "axes.linewidth": 0.8,
            "lines.linewidth": 1.35,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    return {"font": selected, "palette": "Okabe-Ito", "raster_dpi": "600"}


def style_axis(ax: plt.Axes, grid_axis: str = "both") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis=grid_axis, color="#D6D6D6", linewidth=0.5, alpha=0.65)
    ax.tick_params(direction="out", length=3.0, width=0.7)
    ax.margins(x=0.015)


def read_csv_numeric(path: Path) -> dict[str, np.ndarray]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"数据文件为空：{path}")
    result: dict[str, np.ndarray] = {}
    for key in rows[0]:
        result[key] = np.asarray(
            [float(row[key]) if row[key].strip() else np.nan for row in rows],
            dtype=float,
        )
    return result


def read_q1_workbook(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    workbook = load_workbook(path, data_only=True, read_only=True)
    sheets = workbook.worksheets[:2]
    parsed: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for sheet in sheets:
        rows = list(sheet.iter_rows(values_only=True))
        radii_cm = np.asarray(rows[0][1:], dtype=float)
        times_s = np.asarray([row[0] for row in rows[1:]], dtype=float)
        field = np.asarray([row[1:] for row in rows[1:]], dtype=float)
        parsed.append((times_s, radii_cm, field))
    workbook.close()
    if not np.array_equal(parsed[0][0], parsed[1][0]):
        raise ValueError("问题1温度和水分工作表的时间索引不一致")
    if not np.array_equal(parsed[0][1], parsed[1][1]):
        raise ValueError("问题1温度和水分工作表的半径索引不一致")
    return parsed[0][0], parsed[0][1], parsed[0][2], parsed[1][2]


def export_figure(
    fig: plt.Figure,
    output_dir: Path,
    name: str,
    claim: str,
    axes_to_check: list[plt.Axes],
    manifest: list[dict],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    qa_dir = output_dir / "_qa_previews"
    qa_dir.mkdir(parents=True, exist_ok=True)

    missing = []
    for index, ax in enumerate(axes_to_check, start=1):
        shared_x_has_label = any(
            sibling.get_xlabel().strip()
            for sibling in ax.get_shared_x_axes().get_siblings(ax)
        )
        shared_y_has_label = any(
            sibling.get_ylabel().strip()
            for sibling in ax.get_shared_y_axes().get_siblings(ax)
        )
        if not ax.get_xlabel().strip() and not shared_x_has_label:
            missing.append(f"panel {index}: x label")
        if not ax.get_ylabel().strip() and not shared_y_has_label:
            missing.append(f"panel {index}: y label")
        if not ax.get_title().strip():
            missing.append(f"panel {index}: title")
    if missing:
        raise RuntimeError(f"{name}缺少必要文字：{', '.join(missing)}")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fig.canvas.draw()
    glyph_warnings = [str(item.message) for item in caught if "Glyph" in str(item.message)]
    if glyph_warnings:
        raise RuntimeError(f"{name}存在缺字：{glyph_warnings[:3]}")

    preview = qa_dir / f"{name}_preview.png"
    fig.savefig(preview, dpi=180, bbox_inches="tight", pad_inches=0.06)

    exported: list[str] = []
    for suffix in ("pdf", "svg", "png", "tiff"):
        path = output_dir / f"{name}.{suffix}"
        options: dict = {"bbox_inches": "tight", "pad_inches": 0.06}
        if suffix in {"png", "tiff"}:
            options["dpi"] = 600
        fig.savefig(path, **options)
        if not path.exists() or path.stat().st_size == 0:
            raise RuntimeError(f"图片导出失败：{path}")
        exported.append(str(path))

    png_path = output_dir / f"{name}.png"
    gray_path = output_dir / f"{name}_grayscale.png"
    with Image.open(png_path) as image:
        dpi = image.info.get("dpi", (0.0, 0.0))
        if min(float(dpi[0]), float(dpi[1])) < 590.0:
            raise RuntimeError(f"{png_path.name}的实际DPI不足600：{dpi}")
        image.convert("L").save(gray_path, dpi=(600, 600))

    manifest.append(
        {
            "name": name,
            "claim": claim,
            "preview": str(preview),
            "exported": exported,
            "grayscale": str(gray_path),
            "structural_qa": "PASS",
            "glyph_warnings": glyph_warnings,
        }
    )
    plt.close(fig)


def plot_boundary_inputs(
    q4_boundary: dict[str, np.ndarray], output_dir: Path, manifest: list[dict]
) -> None:
    time_h = q4_boundary["time_h"]
    mask = time_h <= 52.0
    time_h = time_h[mask]
    fig, axes = plt.subplots(3, 1, figsize=(6.7, 5.2), sharex=True)

    axes[0].plot(
        time_h,
        q4_boundary["radius_cm"][mask],
        color=COLORS[0],
        marker="o",
        markevery=max(1, len(time_h) // 35),
        ms=2.6,
    )
    axes[0].set_ylabel("半径 $R$ / cm")
    axes[0].set_title("(a) 附件2给出的收缩半径")
    axes[0].set_ylim(1.15, 2.05)

    axes[1].plot(
        time_h, q4_boundary["ambient_temperature_c"][mask], color=COLORS[3]
    )
    axes[1].set_ylabel("$T_\\infty$ / ℃")
    axes[1].set_title("(b) 烘房温度边界")
    axes[1].set_ylim(27.0, 51.0)

    axes[2].plot(
        time_h,
        q4_boundary["ambient_moisture_kg_kg"][mask],
        color=COLORS[2],
    )
    axes[2].set_xlabel("时间 $t$ / h")
    axes[2].set_ylabel("$C_\\infty$ / (kg/kg)")
    axes[2].set_title("(c) 空气水分边界")
    axes[2].set_ylim(0.0, 0.055)

    for ax in axes:
        ax.axvline(4.0, color="#666666", linestyle="--", linewidth=0.9)
        style_axis(ax)
    axes[0].annotate(
        "附件1结束，边界延拓开始",
        xy=(4.0, np.interp(4.0, time_h, q4_boundary["radius_cm"][mask])),
        xytext=(8.0, 1.72),
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": "#444444"},
        fontsize=8,
    )
    export_figure(
        fig,
        output_dir,
        "Fig1_boundary_inputs",
        "附件1边界在4 h后进入常值延拓，附件2半径继续收缩并逐渐稳定",
        list(axes),
        manifest,
    )


def plot_q1_profiles(
    times_s: np.ndarray,
    radii_cm: np.ndarray,
    temperature: np.ndarray,
    moisture: np.ndarray,
    output_dir: Path,
    manifest: list[dict],
) -> dict[str, float]:
    selected_times = [100.0, 600.0, 1200.0, 1800.0]
    indices = [int(np.argmin(np.abs(times_s - value))) for value in selected_times]
    fig, axes = plt.subplots(1, 2, figsize=(6.7, 2.75), sharex=True)
    for index, (time_s, row) in enumerate(zip(selected_times, indices)):
        common = {
            "color": COLORS[index],
            "linestyle": LINE_STYLES[index],
            "marker": MARKERS[index],
            "markevery": 4,
            "markersize": 3.0,
            "markerfacecolor": "white",
            "label": f"{int(time_s)} s",
        }
        axes[0].plot(radii_cm, temperature[row], **common)
        axes[1].plot(radii_cm, moisture[row], **common)

    axes[0].set_xlabel("半径 $r$ / cm")
    axes[0].set_ylabel("温度 $T$ / ℃")
    axes[0].set_title("(a) 温度径向剖面")
    axes[1].set_xlabel("半径 $r$ / cm")
    axes[1].set_ylabel("干基含水率 $C$ / (kg/kg)")
    axes[1].set_title("(b) 含水率径向剖面")
    for ax in axes:
        ax.set_xlim(0.0, 2.0)
        ax.set_xticks(np.arange(0.0, 2.01, 0.5))
        ax.legend(loc="best", ncol=2)
        style_axis(ax)
    export_figure(
        fig,
        output_dir,
        "Fig2_q1_radial_profiles",
        "问题1中温度和失水均由表及里传播，温度场的响应明显快于水分场",
        list(axes),
        manifest,
    )
    last = indices[-1]
    return {
        "temperature_center_1800_c": float(temperature[last, 0]),
        "temperature_surface_1800_c": float(temperature[last, -1]),
        "moisture_center_1800_kg_kg": float(moisture[last, 0]),
        "moisture_surface_1800_kg_kg": float(moisture[last, -1]),
    }


def plot_q2_heatmaps(npz_path: Path, output_dir: Path, manifest: list[dict]) -> None:
    data = np.load(npz_path)
    time_h = data["time_s"] / 3600.0
    radius_cm = data["radius_cm"]
    temperature = data["temperature_c"]
    moisture = data["moisture_kg_kg"]
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.85), sharex=True, sharey=True)

    mesh_t = axes[0].pcolormesh(
        time_h,
        radius_cm,
        temperature.T,
        shading="auto",
        cmap="cividis",
        vmin=float(np.nanmin(temperature)),
        vmax=float(np.nanmax(temperature)),
    )
    mesh_c = axes[1].pcolormesh(
        time_h,
        radius_cm,
        moisture.T,
        shading="auto",
        cmap="viridis_r",
        vmin=float(np.nanmin(moisture)),
        vmax=float(np.nanmax(moisture)),
    )
    axes[0].set_xlabel("时间 $t$ / h")
    axes[0].set_ylabel("半径 $r$ / cm")
    axes[0].set_title("(a) 温度场")
    axes[1].set_xlabel("时间 $t$ / h")
    axes[1].set_ylabel("半径 $r$ / cm")
    axes[1].set_title("(b) 含水率场")
    colorbar_t = fig.colorbar(mesh_t, ax=axes[0], pad=0.025)
    colorbar_t.set_label("温度 $T$ / ℃")
    colorbar_c = fig.colorbar(mesh_c, ax=axes[1], pad=0.025)
    colorbar_c.set_label("干基含水率 $C$ / (kg/kg)")
    for ax in axes:
        ax.set_xlim(0.0, 3.0)
        ax.set_ylim(0.0, 2.0)
        ax.grid(False)
        ax.tick_params(direction="out", length=3.0, width=0.7)
    export_figure(
        fig,
        output_dir,
        "Fig3_q2_temperature_moisture_fields",
        "问题2的3 h温湿场显示温度迅速均匀化，而低含水率区持续由表面向中心推进",
        list(axes),
        manifest,
    )


def plot_q3_history(
    history: dict[str, np.ndarray],
    summary: dict,
    output_dir: Path,
    manifest: list[dict],
) -> None:
    completion_h = float(summary["main_result"]["drying_completion_time_h"])
    time_h = history["time_h"]
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.85))
    series = [
        ("moisture_r0_kg_kg", "中心", COLORS[0], LINE_STYLES[0]),
        ("moisture_r1.0_kg_kg", "$r=1$ cm", COLORS[2], LINE_STYLES[2]),
        ("moisture_r2.0_kg_kg", "表面", COLORS[3], LINE_STYLES[3]),
    ]
    for key, label, color, line_style in series:
        axes[0].plot(time_h, history[key], label=label, color=color, linestyle=line_style)
    axes[0].axhline(0.15, color="#111111", linestyle="--", linewidth=0.9, label="阈值0.15")
    axes[0].axvline(completion_h, color="#777777", linestyle=":", linewidth=0.9)
    axes[0].set_xlabel("时间 $t$ / h")
    axes[0].set_ylabel("干基含水率 $C$ / (kg/kg)")
    axes[0].set_title("(a) 典型径向位置的全程变化")
    axes[0].set_xlim(0.0, completion_h * 1.02)
    axes[0].set_ylim(0.0, 2.65)
    axes[0].legend(loc="upper right", ncol=2)
    style_axis(axes[0])

    mask = time_h >= 40.0
    axes[1].plot(
        time_h[mask],
        history["maximum_moisture_kg_kg"][mask],
        color=COLORS[0],
        label="全域最大含水率（中心）",
    )
    axes[1].axhline(0.15, color="#111111", linestyle="--", linewidth=0.9, label="阈值0.15")
    axes[1].axvline(completion_h, color="#777777", linestyle=":", linewidth=0.9)
    axes[1].scatter([completion_h], [0.15], color=COLORS[3], s=28, zorder=4)
    axes[1].annotate(
        f"全域达标：{completion_h:.2f} h",
        xy=(completion_h, 0.15),
        xytext=(-92, 45),
        textcoords="offset points",
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": "#444444"},
        fontsize=8,
    )
    axes[1].set_xlabel("时间 $t$ / h")
    axes[1].set_ylabel("全域最大含水率 / (kg/kg)")
    axes[1].set_title("(b) 终止事件局部放大")
    axes[1].set_xlim(40.0, completion_h * 1.01)
    axes[1].set_ylim(0.135, 0.255)
    axes[1].legend(loc="upper right")
    style_axis(axes[1])
    export_figure(
        fig,
        output_dir,
        "Fig4_q3_moisture_history",
        "中心含水率下降最慢，并在57.56 h最后达到0.15，因而控制问题3终点",
        list(axes),
        manifest,
    )


def plot_q4_mechanism(
    history: dict[str, np.ndarray],
    validation: dict,
    output_dir: Path,
    manifest: list[dict],
) -> dict[str, float]:
    time_h = history["time_h"]
    completion_h = float(time_h[-1])
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.9))
    for key, label, color, line_style in [
        ("moisture_center_kg_kg", "中心", COLORS[0], "-"),
        ("moisture_r1.0_kg_kg", "$r=1$ cm", COLORS[2], "-."),
        ("moisture_surface_kg_kg", "瞬时表面", COLORS[3], ":"),
    ]:
        axes[0].plot(time_h, history[key], label=label, color=color, linestyle=line_style)
    axes[0].axhline(0.15, color="#111111", linestyle="--", linewidth=0.9, label="阈值0.15")
    axes[0].axvline(completion_h, color="#777777", linestyle=":", linewidth=0.9)
    axes[0].annotate(
        f"{completion_h:.2f} h",
        xy=(completion_h, 0.15),
        xytext=(-78, 42),
        textcoords="offset points",
        arrowprops={"arrowstyle": "->", "lw": 0.8, "color": "#444444"},
        fontsize=8,
    )
    axes[0].set_xlabel("时间 $t$ / h")
    axes[0].set_ylabel("干基含水率 $C$ / (kg/kg)")
    axes[0].set_title("(a) 收缩药材典型位置含水率")
    axes[0].set_xlim(0.0, completion_h * 1.02)
    axes[0].set_ylim(0.0, 2.65)
    axes[0].legend(loc="upper right", ncol=2)
    style_axis(axes[0])

    comparison = validation["moving_boundary_necessity_n320"]
    dynamic_h = float(comparison["measured_radius_completion_time_h"])
    fixed_h = float(comparison["fixed_initial_radius_completion_time_h"])
    labels = ["动态半径", "固定2 cm"]
    values = [dynamic_h, fixed_h]
    for position, value, color, marker in zip(
        [0, 1], values, [COLORS[2], COLORS[3]], ["o", "s"]
    ):
        axes[1].vlines(position, 0.0, value, color=color, linewidth=2.2)
        axes[1].scatter(position, value, color=color, marker=marker, s=42, zorder=4)
        axes[1].annotate(
            f"{value:.2f} h",
            (position, value),
            xytext=(7 if position == 0 else 0, 7),
            textcoords="offset points",
            ha="left" if position == 0 else "center",
            fontsize=8,
        )
    axes[1].set_xticks([0, 1], labels)
    axes[1].set_ylabel("烘干结束时间 / h")
    axes[1].set_xlabel("同附录4参数下的半径处理")
    axes[1].set_title("(b) 同参数固定/动态半径对照（$N=320$）")
    axes[1].set_ylim(0.0, 142.0)
    style_axis(axes[1], grid_axis="y")

    export_figure(
        fig,
        output_dir,
        "Fig5_q4_moisture_and_radius_effect",
        "问题4由中心控制51.12 h终点；同参数对照表明收缩显著缩短扩散距离与烘干时长",
        list(axes),
        manifest,
    )
    return {
        "q4_completion_h": completion_h,
        "dynamic_radius_n320_h": dynamic_h,
        "fixed_radius_n320_h": fixed_h,
        "shortening_relative_to_fixed_percent": (1.0 - dynamic_h / fixed_h) * 100.0,
    }


def plot_q4_moisture_field(
    moisture: dict[str, np.ndarray],
    boundary: dict[str, np.ndarray],
    output_dir: Path,
    manifest: list[dict],
) -> None:
    radius_keys = [
        key for key in moisture if key.startswith("r_") and key.endswith("_cm")
    ]
    radii_cm = np.asarray([float(key[2:-3]) for key in radius_keys], dtype=float)
    values = np.column_stack([moisture[key] for key in radius_keys])
    time_h = moisture["time_s"] / 3600.0
    radius_curve = np.interp(time_h, boundary["time_h"], boundary["radius_cm"])

    fig, ax = plt.subplots(figsize=(6.7, 3.15))
    mesh = ax.pcolormesh(
        time_h,
        radii_cm,
        np.ma.masked_invalid(values.T),
        shading="auto",
        cmap="cividis",
        vmin=0.05,
        vmax=2.55,
    )
    ax.plot(
        time_h,
        radius_curve,
        color="white",
        linestyle="--",
        linewidth=1.35,
        label="瞬时外边界 $R(t)$",
    )
    ax.set_xlabel("时间 $t$ / h")
    ax.set_ylabel("物理半径 $r$ / cm")
    ax.set_title("收缩域内干基含水率的时空演化")
    ax.set_xlim(0.0, float(time_h[-1]))
    ax.set_ylim(0.0, 2.02)
    ax.legend(loc="upper right")
    ax.grid(False)
    colorbar = fig.colorbar(mesh, ax=ax, pad=0.025)
    colorbar.set_label("干基含水率 $C$ / (kg/kg)")
    export_figure(
        fig,
        output_dir,
        "Fig6_q4_moving_domain_moisture_field",
        "白色边界内的低含水率区由表及里推进，物理扩散距离随半径由2.0 cm缩至1.2 cm",
        [ax],
        manifest,
    )


def plot_q4_validation(
    convergence: dict[str, np.ndarray],
    validation: dict,
    output_dir: Path,
    manifest: list[dict],
) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.75))
    intervals = convergence["intervals"]
    completion = convergence["completion_time_h"]
    axes[0].plot(intervals, completion, color=COLORS[0], marker="o", markersize=4.5)
    axes[0].set_xscale("log", base=2)
    axes[0].set_xticks(intervals, [f"{int(value)}" for value in intervals])
    axes[0].set_xlabel("径向区间数 $N$")
    axes[0].set_ylabel("结束时间 / h")
    axes[0].set_title("(a) 空间收敛")
    axes[0].text(0.96, 0.91, "观测阶次 2.133", transform=axes[0].transAxes, ha="right")
    style_axis(axes[0])

    temporal = validation["temporal_convergence_n640"]
    time_steps = np.asarray([15.0, 30.0, 60.0])
    time_values = np.asarray(
        [
            temporal["completion_time_h_by_late_dt_s"][str(int(value))]
            for value in time_steps
        ]
    )
    axes[1].plot(time_steps, time_values, color=COLORS[1], marker="s", markersize=4.5)
    axes[1].set_xlabel("后期时间步长 / s")
    axes[1].set_ylabel("结束时间 / h")
    axes[1].set_title("(b) 时间收敛（$N=640$）")
    axes[1].text(0.05, 0.91, "观测阶次 1.000", transform=axes[1].transAxes)
    style_axis(axes[1])

    parameter = validation["borrowed_parameter_sensitivity"]
    boundary = validation["boundary_extension_sensitivity_n320"]
    sensitivity_values = np.asarray(
        [
            parameter["mass_transfer_n320"]["minus_20_percent_relative_change_percent"],
            parameter["mass_transfer_n320"]["plus_20_percent_relative_change_percent"],
            parameter["heat_transfer_n160"]["minus_20_percent_relative_change_percent"],
            parameter["heat_transfer_n160"]["plus_20_percent_relative_change_percent"],
            -boundary["relative_difference_percent"],
        ]
    )
    labels = ["$h_m$: -20%", "$h_m$: +20%", "$h$: -20%", "$h$: +20%", "边界末点"]
    positions = np.arange(len(labels))
    axes[2].axhline(0.0, color="#777777", linewidth=0.8)
    for index, (position, value) in enumerate(zip(positions, sensitivity_values)):
        axes[2].scatter(
            position,
            value,
            color=COLORS[index],
            marker=MARKERS[index],
            s=34,
            zorder=3,
        )
        axes[2].annotate(
            f"{value:+.2f}%",
            (position, value),
            xytext=(0, 7 if value >= 0 else -13),
            textcoords="offset points",
            ha="center",
            fontsize=7.2,
        )
    axes[2].set_xticks(positions, labels, rotation=25, ha="right")
    axes[2].set_xlabel("扰动情景")
    axes[2].set_ylabel("结束时间相对变化 / %")
    axes[2].set_title("(c) 参数与延拓敏感性")
    axes[2].set_ylim(-1.05, 1.62)
    style_axis(axes[2], grid_axis="y")

    export_figure(
        fig,
        output_dir,
        "Fig7_numerical_convergence_and_sensitivity",
        "空间和时间加密呈预期收敛，参数与边界延拓扰动的影响量级得到单独展示",
        list(axes),
        manifest,
    )


def main() -> int:
    args = parse_args()
    project_root = args.project_root.resolve()
    output_dir = args.output_dir.resolve()
    outputs = project_root / "outputs"
    required = {
        "q1": outputs / "result1.xlsx",
        "q2": outputs / "question2_package" / "figure_heatmaps.npz",
        "q3_history": outputs / "question3_final" / "question3_plot_history.csv",
        "q3_summary": outputs / "question3_final" / "question3_summary.json",
        "q4_boundary": outputs / "question4_final" / "question4_boundary_and_radius.csv",
        "q4_history": outputs / "question4_final" / "question4_plot_history.csv",
        "q4_moisture": outputs / "question4_final" / "result4_moisture.csv",
        "q4_convergence": outputs / "question4_final" / "question4_completion_convergence.csv",
        "q4_validation": outputs / "question4_final" / "question4_validation_final.json",
    }
    missing = [str(path) for path in required.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("缺少绘图数据：\n" + "\n".join(missing))

    style = configure_style()
    manifest: list[dict] = []
    times_s, radii_cm, temperature, moisture = read_q1_workbook(required["q1"])
    q4_boundary = read_csv_numeric(required["q4_boundary"])
    q3_history = read_csv_numeric(required["q3_history"])
    q4_history = read_csv_numeric(required["q4_history"])
    q4_moisture = read_csv_numeric(required["q4_moisture"])
    q4_convergence = read_csv_numeric(required["q4_convergence"])
    q3_summary = json.loads(required["q3_summary"].read_text(encoding="utf-8"))
    q4_validation = json.loads(required["q4_validation"].read_text(encoding="utf-8"))

    plot_boundary_inputs(q4_boundary, output_dir, manifest)
    q1_values = plot_q1_profiles(
        times_s, radii_cm, temperature, moisture, output_dir, manifest
    )
    plot_q2_heatmaps(required["q2"], output_dir, manifest)
    plot_q3_history(q3_history, q3_summary, output_dir, manifest)
    q4_values = plot_q4_mechanism(q4_history, q4_validation, output_dir, manifest)
    plot_q4_moisture_field(q4_moisture, q4_boundary, output_dir, manifest)
    plot_q4_validation(q4_convergence, q4_validation, output_dir, manifest)

    payload = {
        "style": style,
        "project_root": str(project_root),
        "source_files": {key: str(value) for key, value in required.items()},
        "figures": manifest,
        "key_values": {**q1_values, **q4_values},
        "figure_count": len(manifest),
        "qa_summary": {
            "structural_failures": sum(
                item["structural_qa"] != "PASS" for item in manifest
            ),
            "glyph_warning_count": sum(len(item["glyph_warnings"]) for item in manifest),
            "visual_review": "pending AI review of PNG previews",
        },
    }
    (output_dir / "figure_manifest.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload["key_values"], ensure_ascii=False, indent=2))
    print(f"已生成{len(manifest)}张论文图：{output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
